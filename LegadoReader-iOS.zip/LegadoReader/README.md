# 留白阅读 · LegadoReader（iOS 原生客户端）

一个用 SwiftUI 写的 iOS 小说阅读 App，连接你自己部署的 [kanshu-web（留白 · Legado Web）](https://github.com/PeterFile/kanshu-web) 服务端。书架、搜索、目录、正文、阅读进度都在原生界面里完成，书源规则全部交给服务端执行。

- 部署目标：iOS 16.0+（iPhone / iPad）
- 工程：`LegadoReader.xcodeproj`，Schema `LegadoReader`
- Bundle ID：`com.liubai.reader`（可自行修改）
- 语言：Swift 5 + SwiftUI，阅读正文用 `UITextView`（TextKit 1）

---

## 一、为什么需要服务端

kanshu-web 的书源规则（CSS / XPath / JSONPath / 正则 / Rhino JS）运行在独立的 **Java 规则核心**（JDK 17，内部网关 `127.0.0.1:18123`）里，这部分无法在 iOS 上运行。

所以本 App 的定位是**原生客户端**：

```
iPhone / iPad (本 App)
        │  HTTPS / HTTP，Cookie 会话
        ▼
kanshu-web 服务端（Node + SQLite）
        │
        ▼
Java 规则核心  ──►  各个书源网站
```

App 不抓网页、不存书源规则，只负责「好看地读」。好处是进度、书架、书源与网页版完全一致，多端可接续。

---

## 二、先跑起服务端

### 方式 A：Docker（推荐）

```bash
git clone https://github.com/PeterFile/kanshu-web.git
cd kanshu-web
# 按仓库里的 docker-compose 启动，默认映射 3001 端口
docker compose up -d
```

### 方式 B：本机 Node

```bash
git clone https://github.com/PeterFile/kanshu-web.git
cd kanshu-web
npm install
npm run dev        # 开发模式，5173 代理到 3001
# 或 npm start      # 生产模式，直接监听 3001
```

需要 **Node 18+** 与 **JDK 17**（规则核心依赖）。

### 关键配置：LEGADO_PUBLIC_ORIGIN（最容易踩的坑）

服务端对所有 `/api` 请求做同源校验：**Host 必须是回环地址，或者已经写进 `LEGADO_PUBLIC_ORIGIN` 的地址**，否则一律 `403`。手机通过局域网访问时，Host 是 `192.168.x.x:3001`，必须提前登记：

```ini
# .env
LEGADO_PUBLIC_ORIGIN=http://192.168.1.20:3001
```

- 多个地址用英文逗号分隔，且必须是**纯 origin**（协议 + 主机 + 端口，不带路径）。
- 用域名或反代时写 `https://read.example.com`。
- 改完重启服务端。

App 侧如果收到 403，登录页会直接提示「请确认服务端已配置 LEGADO_PUBLIC_ORIGIN」。

### 初始账号

首次启动会在 `data/bootstrap-admin.txt` 里生成管理员账号密码，用它登录网页端，再导入书源 JSON。**密码要求 12–256 位**。

导入书源后，App 的搜索就能看到结果了。

---

## 三、在 Mac 上构建 App

> 有 Mac / 只有 Windows / 租云 Mac / TestFlight 四条安装路线的完整步骤，见 **[INSTALL-IOS.md](INSTALL-IOS.md)**。下面是短的 Mac 路线。

1. 把整个 `LegadoReader` 文件夹拷贝到 Mac。
2. 双击 `LegadoReader.xcodeproj`（Xcode 15 / 16 打开）。
3. 选中 `LegadoReader` Target → **Signing & Capabilities**：
   - 勾选 *Automatically manage signing*；
   - 选择你的 Apple ID Team；
   - 如果 Bundle ID 冲突，把 `com.liubai.reader` 改成自己的（如 `com.yourname.legado`）。
4. 连接 iPhone（iOS 16+），选中真机，⌘R 运行。
   - 首次运行需在 iPhone 上「设置 → 通用 → VPN与设备管理」信任你的开发者证书。
5. 打开 App，填写：
   - 服务器地址：`http://192.168.1.20:3001`
   - 用户名 / 密码：`data/bootstrap-admin.txt` 里的账号

### 关于明文 HTTP

App 的 `Info.plist` 打开了 `NSAllowsArbitraryLoads`，以便直连局域网 `http://`。这只适合自用 / 内网。若要长期在外网使用，建议在服务端前面加 HTTPS 反代（Caddy / Nginx），App 里填 `https://` 地址即可。

iOS 14+ 访问局域网设备时可能弹出「本地网络」权限，允许即可（用途说明已写在 `NSLocalNetworkUsageDescription`）。

---

## 四、功能

| 模块 | 能力 |
| --- | --- |
| 登录 | 服务器地址 + 账号密码；Cookie 会话存 Keychain（手动管理 `legado_session`）；401 自动退回登录页 |
| 书架 | 3 列封面网格、最近阅读卡片、排序（最近阅读 / 书名）、只看在读、长按继续阅读 / 移出书架、下拉与右上角刷新 |
| 找书 | 服务端**流式**搜索（NDJSON 逐源返回），实时进度与「停止」；按书名 + 作者合并多书源结果；可按单一书源搜索；失败书源可查看原因 |
| 详情 | 书籍信息、简介展开、前 8 章预览、全部目录、加入书架、继续阅读定位到上次进度 |
| 阅读 | 原生滚动阅读（UITextView，TextKit 1）；上下章切换；章内位置按**原文 UTF-16 字符偏移**记录，与网页版一致；切章 / 退出自动保存，滚动 2.5 秒防抖保存；预取下一章；点击中央呼出 / 收起工具栏 |
| 排版 | 字号 13–30、行距、段距、字距、宋 / 楷 / 黑三体、暖纸 / 素白 / 青竹 / 夜读四主题、首行缩进，改动即时生效且保留位置 |
| 我的 | 账号信息、服务器地址修改（自动清登录态）、连通性测试、阅读排版入口、开源项目链接、退出登录 |

细节：

- 卷标题章节（`isVolume`）会被自动跳过，不会停在只有标题没有正文的一章。
- 书籍对象里的未知字段（例如书源规则变量 `variable`）会被原样保存并在请求中原样回传，保证「搜索 → 详情 → 正文」链路不被客户端截断。
- 进度协议：`durChapterIndex` + `durChapterPos`（原文 UTF-16 偏移）；换源导致 `sourceRevision` 变化时，旧进度会被服务端拒绝（409），App 会提示刷新。

---

## 五、目录结构

```
LegadoReader/
├── LegadoReader.xcodeproj          # 工程（含共享 Scheme）
├── INSTALL-IOS.md                  # 装到 iPhone 的四条路线
├── .github/workflows/build-ios-ipa.yml  # GitHub Actions 出未签名 ipa（Windows 也能装）
├── LegadoReader/
│   ├── LegadoReaderApp.swift       # @main、RootView、启动页、TabView
│   ├── Info.plist                  # ATS、本地网络、图标、方向
│   ├── Assets.xcassets             # AppIcon（1024）、AccentColor
│   ├── Core/
│   │   ├── Models.swift            # Book 等模型，保留未知字段
│   │   ├── APIClient.swift         # /api 封装、NDJSON 流式搜索、错误文案
│   │   ├── AppSession.swift        # 登录态与地址
│   │   └── CookieStore.swift       # Keychain 会话 Cookie
│   ├── Support/
│   │   ├── Theme.swift             # 配色、阅读主题、字体、排版设置
│   │   └── Primitives.swift        # 卡片、按钮、错误条、Toast
│   └── Features/
│       ├── Auth/LoginView.swift
│       ├── Shelf/ShelfView.swift
│       ├── Search/SearchView.swift
│       ├── Detail/BookDetailView.swift
│       ├── Reader/ReaderView.swift · ReaderController.swift
│       │        · ChapterTextView.swift · ChapterListView.swift
│       │        · ReaderSettingsSheet.swift
│       └── Settings/SettingsView.swift
└── tools/
    ├── generate_xcodeproj.py       # 重新生成工程文件（如需改动文件清单）
    └── make_icon.ps1               # 用 System.Drawing 重画 AppIcon（Windows）
```

---

## 六、对接的接口

| 用途 | 接口 |
| --- | --- |
| 健康检查 / 当前账号 | `GET /api/health`、`GET /api/auth/me` |
| 登录 / 登出 | `POST /api/auth/login`、`POST /api/auth/logout` |
| 书架 | `GET /api/shelf`、`POST /api/shelf`、`DELETE /api/shelf` |
| 书源摘要 | `GET /api/sources?summary=1` |
| 书籍详情 | `POST /api/book/details` |
| 流式搜索 | `GET /api/search/stream?key=&media=text&page=1[&source=]`（NDJSON） |
| 目录 | `GET /api/chapters?url=&cached=1` |
| 正文 | `GET /api/content?url=&index=&expectedOrigin=&sourceRevision=&expectedChapterUrl=` |
| 进度 | `POST /api/progress` |

请求头：`Accept: application/json`，写请求 `Content-Type: application/json`，会话用 `Cookie: legado_session=...`，可选 `X-Legado-User-Id`。原生 App 不发送 `Origin`，因此不受浏览器跨站限制，但服务端仍要求 Host 在 `LEGADO_PUBLIC_ORIGIN` 白名单内。

---

## 七、已知限制

- **不含书源引擎**：没有服务端就只能浏览界面，搜不到书。这是有意为之。
- **仅文字小说**：搜索固定 `media=text`；漫画（`BookContent.pages`）模型已保留但未做 UI。
- **不做本地缓存**：正文缓存只在内存里（当前章节 + 下一章预取），冷启动需联网。
- **不读 EPUB / 本地文件**：只读服务端书源结果。
- **未在 Xcode 中编译验证**：本工程由脚本生成 pbxproj，源码经静态检查，但首次在 Mac 上打开可能需要按提示微调（例如签名 Team、Bundle ID）。
- 若 `.statusBar(hidden:)` 在较新 SDK 上报弃用警告，不影响编译；可换成 `.persistentSystemOverlays(.hidden)`。

---

## 八、许可

服务端 [kanshu-web](https://github.com/PeterFile/kanshu-web) 采用 **GPL-3.0**。本 App 是独立实现的客户端，通过 HTTP API 与之通信，不包含其源代码。若你要把两者打包分发，请遵守 GPL-3.0 的相应义务（提供源代码、保留许可声明等）。
