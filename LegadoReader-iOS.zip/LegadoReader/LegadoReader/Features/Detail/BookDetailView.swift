import SwiftUI

struct BookDetailView: View {
    let book: Book

    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    /// 书源列表里每家源的「共多少章 / 最新一章」，滚到才探测。
    @ObservedObject private var chapterProbe = SourceChapterProbe.shared

    @State private var detail: BookDetailsResult?
    @State private var shelfBook: Book?
    @State private var chapters: [Chapter] = []
    @State private var isLoading = true
    @State private var isSaving = false
    @State private var errorMessage: String?
    @State private var toastText: String?
    @State private var readingBook: Book?
    @State private var startIndex: Int?
    @State private var showAllChapters = false
    @State private var introExpanded = false
    @State private var showAllSources = false

    var body: some View {
        ZStack {
            PaperBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if isLoading {
                        ProgressView("正在读取书籍详情…")
                            .tint(Palette.accent)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 60)
                    } else {
                        header
                        if !sourceCandidates.isEmpty {
                            sourceBar
                        }
                        if let errorMessage {
                            ErrorBanner(message: errorMessage)
                        }
                        actionRow
                        if let summary = detail?.book.intro, !summary.isEmpty {
                            introSection(summary)
                        }
                        chapterSection
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 32)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
        .toast($toastText)
        .sheet(isPresented: $showAllChapters) {
            ChapterListView(chapters: chapters, currentIndex: nil) { index in
                showAllChapters = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    Task { await startReading(at: index) }
                }
            }
        }
        .fullScreenCover(item: $readingBook) { target in
            ReaderView(
                book: target,
                api: session.api,
                chapters: target.bookUrl == (detail?.book.bookUrl ?? "") ? chapters : [],
                startChapterIndex: startIndex
            )
        }
    }

    // MARK: - 头部

    private var displayBook: Book {
        detail?.book ?? book
    }

    private var header: some View {
        HStack(alignment: .top, spacing: 16) {
            BookCoverView(book: displayBook, coverURL: session.api.resolve(displayBook.coverUrl))
                .frame(width: 104)
            VStack(alignment: .leading, spacing: 6) {
                Text(displayBook.name)
                    .font(.system(size: 21, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.ink)
                    .fixedSize(horizontal: false, vertical: true)
                Text(displayBook.author.isEmpty ? "佚名" : displayBook.author)
                    .font(.subheadline)
                    .foregroundStyle(Palette.secondaryInk)
                if let kind = displayBook.kind, !kind.isEmpty {
                    Text(kind)
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(2)
                }
                HStack(spacing: 8) {
                    metaChip(icon: "books.vertical", text: "\(chapters.count) 章")
                    if let originName = displayBook.originName, !originName.isEmpty {
                        metaChip(icon: "antenna.radiowaves.left.and.right", text: originName)
                    }
                }
                .padding(.top, 2)
                if shelfBook != nil {
                    Label("已在书架", systemImage: "checkmark.circle.fill")
                        .font(.caption)
                        .foregroundStyle(Palette.accent)
                }
            }
            Spacer(minLength: 0)
        }
    }

    private func metaChip(icon: String, text: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 9))
            Text(text).font(.system(size: 10))
        }
        .foregroundStyle(Palette.secondaryInk)
        .padding(.horizontal, 7)
        .padding(.vertical, 3)
        .background(Capsule().fill(Palette.hairline.opacity(0.35)))
        .lineLimit(1)
    }

    // MARK: - 书源一排

    /// 当前源 + 服务端聚合的其他源 + 上次精确搜索命中的源，换过的置底。
    private var sourceCandidates: [Book] {
        var list: [Book] = [displayBook]
        var seen: Set<String> = [displayBook.bookUrl]

        for variant in (book.sourceVariants ?? []) + (detail?.book.sourceVariants ?? []) {
            guard !variant.bookUrl.isEmpty, !seen.contains(variant.bookUrl) else { continue }
            seen.insert(variant.bookUrl)
            list.append(variant)
        }
        for hit in ExactSourceMemo.shared.books(for: book.name) {
            guard !hit.bookUrl.isEmpty, !seen.contains(hit.bookUrl) else { continue }
            seen.insert(hit.bookUrl)
            list.append(hit)
        }

        let used = SourceSwitchHistory.shared.used(bookName: book.name)
        return list.sorted { lhs, rhs in
            if lhs.bookUrl == displayBook.bookUrl { return true }
            if rhs.bookUrl == displayBook.bookUrl { return false }
            let leftUsed = used.contains(lhs.bookUrl)
            let rightUsed = used.contains(rhs.bookUrl)
            // 换过的源始终置底。
            if leftUsed != rightUsed { return !leftUsed }
            // 其余按正文字数从多到少，没有字数就按章数估。
            if lhs.sourceWeight != rhs.sourceWeight { return lhs.sourceWeight > rhs.sourceWeight }
            return sourceLabel(lhs).localizedStandardCompare(sourceLabel(rhs)) == .orderedAscending
        }
    }

    private func sourceLabel(_ candidate: Book) -> String {
        if let name = candidate.originName, !name.isEmpty { return name }
        if let host = URL(string: candidate.origin)?.host, !host.isEmpty { return host }
        return candidate.origin.isEmpty ? "未知来源" : candidate.origin
    }

    private var visibleSources: [Book] {
        showAllSources ? sourceCandidates : Array(sourceCandidates.prefix(3))
    }

    private var sourceBar: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Text("书源")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                Text("\(sourceCandidates.count) 个")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
                Spacer(minLength: 6)
                Text("点一个直接读")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
            VStack(spacing: 6) {
                ForEach(visibleSources, id: \.bookUrl) { candidate in
                    Button {
                        Task { await read(source: candidate) }
                    } label: {
                        sourceRow(candidate)
                    }
                    .buttonStyle(.plain)
                }
            }
            if sourceCandidates.count > 3 {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { showAllSources.toggle() }
                } label: {
                    HStack(spacing: 4) {
                        Text(showAllSources ? "收起书源" : "展开其余 \(sourceCandidates.count - 3) 个书源（顺便读章数）")
                        Image(systemName: showAllSources ? "chevron.up" : "chevron.down")
                    }
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(Palette.accent)
                }
                .buttonStyle(.plain)
            }
        }
        .onAppear { chapterProbe.load(visibleSources, api: session.api) }
        .onChange(of: showAllSources) { _ in chapterProbe.load(visibleSources, api: session.api) }
    }

    /// 竖排一行一个书源：左边源名和状态，右边总章数和最新一章。
    private func sourceRow(_ candidate: Book) -> some View {
        let isCurrent = candidate.bookUrl == displayBook.bookUrl
        let used = SourceSwitchHistory.shared.used(bookName: book.name).contains(candidate.bookUrl)
        let stat = chapterProbe.stats[candidate.bookUrl]
        let total = stat?.total ?? candidate.totalChapterNum
        let latest = stat?.lastChapter ?? candidate.lastChapterHint
        let chapterText: String = {
            if let total, total > 0 { return "共 \(total) 章" }
            if stat == nil { return "读取目录中…" }
            return "章数未知"
        }()
        return HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 4) {
                    if isCurrent {
                        Image(systemName: "book.fill")
                            .font(.system(size: 10))
                    }
                    Text(sourceLabel(candidate))
                        .font(.system(size: 13, weight: .medium))
                        .lineLimit(1)
                }
                HStack(spacing: 5) {
                    Text(isCurrent ? "当前" : (used ? "换过" : "未用"))
                        .font(.system(size: 9))
                    Text(chapterText)
                        .font(.system(size: 9))
                }
                .foregroundStyle(Palette.secondaryInk)
            }
            Spacer(minLength: 6)
            if !latest.isEmpty {
                Text("最新「\(latest)」")
                    .font(.system(size: 10))
                    .foregroundStyle(Palette.secondaryInk.opacity(0.9))
                    .lineLimit(1)
                    .frame(maxWidth: 150, alignment: .trailing)
            }
            Image(systemName: "chevron.right")
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(Palette.secondaryInk.opacity(0.5))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(isCurrent ? Palette.accent.opacity(0.14) : Color.white.opacity(0.8))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .stroke(Palette.hairline.opacity(isCurrent ? 0.0 : 0.5), lineWidth: 0.6)
        )
        .foregroundStyle(isCurrent ? Palette.accent : Palette.ink)
    }

    // MARK: - 操作

    private var actionRow: some View {
        VStack(spacing: 10) {
            Button {
                Task { await startReading(at: nil) }
            } label: {
                HStack(spacing: 8) {
                    if isSaving {
                        ProgressView().tint(.white).scaleEffect(0.8)
                    } else {
                        Image(systemName: "book.fill")
                    }
                    Text(readingTitle)
                }
            }
            .buttonStyle(PrimaryButtonStyle(isEnabled: !isSaving))
            .disabled(isSaving)

            if shelfBook == nil {
                Button {
                    Task { await addToShelf() }
                } label: {
                    Label("加入书架", systemImage: "plus")
                }
                .buttonStyle(SecondaryButtonStyle())
                .disabled(isSaving)
            }
        }
    }

    private var readingTitle: String {
        if let index = shelfBook?.durChapterIndex, index > 0 {
            return "继续阅读 · 第 \(index + 1) 章"
        }
        if let first = chapters.first(where: { !$0.isTitleOnly }) {
            return "开始阅读 · \(first.title)"
        }
        return "开始阅读"
    }

    // MARK: - 简介

    private func introSection(_ text: String) -> some View {
        Card(padding: 14) {
            VStack(alignment: .leading, spacing: 8) {
                Text("简介")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.secondaryInk)
                Text(text)
                    .font(.system(size: 14))
                    .foregroundStyle(Palette.ink)
                    .lineSpacing(5)
                    .lineLimit(introExpanded ? nil : 6)
                    .fixedSize(horizontal: false, vertical: true)
                Button(introExpanded ? "收起" : "展开全部") {
                    withAnimation { introExpanded.toggle() }
                }
                .font(.caption.weight(.medium))
                .foregroundStyle(Palette.accent)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    // MARK: - 目录

    private var chapterSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("目录")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                Text("\(chapters.count) 章")
                    .font(.caption)
                    .foregroundStyle(Palette.secondaryInk)
                Spacer()
                if chapters.count > 8 {
                    Button("全部目录") { showAllChapters = true }
                        .font(.caption.weight(.medium))
                        .foregroundStyle(Palette.accent)
                }
            }
            if chapters.isEmpty {
                Text(detail?.chaptersError ?? "目录暂时没有加载出来，可以稍后重试。")
                    .font(.footnote)
                    .foregroundStyle(Palette.secondaryInk)
                    .padding(.vertical, 8)
            } else {
                VStack(spacing: 0) {
                    ForEach(chapters.prefix(8)) { chapter in
                        Button {
                            Task { await startReading(at: chapter.index) }
                        } label: {
                            HStack(spacing: 10) {
                                Text(chapter.title)
                                    .font(.system(size: 14))
                                    .foregroundStyle(Palette.ink)
                                    .lineLimit(1)
                                Spacer(minLength: 0)
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundStyle(Palette.secondaryInk.opacity(0.5))
                            }
                            .padding(.vertical, 11)
                            .padding(.horizontal, 14)
                        }
                        .buttonStyle(.plain)
                        if chapter.index != chapters.prefix(8).last?.index {
                            Divider().padding(.leading, 14)
                        }
                    }
                }
                .background(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.white.opacity(0.72))
                )
            }
        }
    }

    // MARK: - 行为

    private func load() async {
        isLoading = detail == nil
        do {
            let result = try await session.api.bookDetails(book)
            detail = result
            chapters = result.chapters
            if let chaptersError = result.chaptersError, !chaptersError.isEmpty {
                errorMessage = chaptersError
            }
            let shelf = try? await session.api.shelf()
            shelfBook = shelf?.first {
                $0.bookUrl == result.book.bookUrl
                    || ($0.name == result.book.name && $0.author == result.book.author)
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func addToShelf() async {
        guard let detail else { return }
        isSaving = true
        do {
            let saved = try await session.api.saveBook(detail.book)
            shelfBook = saved
            toastText = "已加入书架"
        } catch {
            errorMessage = error.localizedDescription
        }
        isSaving = false
    }

    /// 点某个书源直接切到该源阅读：只做一次「记进可阅读」，不进书架，
    /// 目录交给阅读器自己加载，少跑一轮详情就不卡了。
    private func read(source candidate: Book) async {
        guard !isSaving else { return }
        if candidate.bookUrl == displayBook.bookUrl {
            await startReading(at: nil)
            return
        }
        isSaving = true
        defer { isSaving = false }
        do {
            let prepared = try await session.api.prepareReading(candidate)
            SourceSwitchHistory.shared.record(bookName: book.name, sourceURL: candidate.bookUrl)
            startIndex = nil
            readingBook = prepared
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func startReading(at index: Int?) async {
        guard let detail else { return }
        isSaving = true
        defer { isSaving = false }

        var resolved: Book?
        if let shelfBook {
            resolved = shelfBook
        } else {
            do {
                // 只看不收藏：进「可阅读」但不占书架，书架要多一本得在阅读器里点「加入书架」。
                let prepared = try await session.api.prepareReading(detail.book)
                resolved = prepared
            } catch {
                errorMessage = error.localizedDescription
                return
            }
        }
        guard let target = resolved else { return }
        startIndex = index
        readingBook = target
    }
}
