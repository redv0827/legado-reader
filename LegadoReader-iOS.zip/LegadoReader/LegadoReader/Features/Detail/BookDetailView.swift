import SwiftUI

struct BookDetailView: View {
    let book: Book

    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    @State private var detail: BookDetailsResult?
    @State private var shelfBook: Book?
    @State private var chapters: [Chapter] = []
    @State private var isLoading = true
    @State private var isSaving = false
    @State private var errorMessage: String?
    @State private var toastText: String?
    @State private var readingBook: Book?
    @State private var startIndex: Int?
    @State private var showAllChapters = false
    @State private var introExpanded = false

    var body: some View {
        ZStack {
            PaperBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if isLoading {
                        ProgressView("正在读取书籍详情…")
                            .tint(Palette.accent)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 60)
                    } else {
                        header
                        if let errorMessage {
                            ErrorBanner(message: errorMessage)
                        }
                        actionRow
                        if let summary = detail?.book.intro, !summary.isEmpty {
                            introSection(summary)
                        }
                        chapterSection
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 32)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
        .toast($toastText)
        .sheet(isPresented: $showAllChapters) {
            ChapterListView(chapters: chapters, currentIndex: nil) { index in
                showAllChapters = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    Task { await startReading(at: index) }
                }
            }
        }
        .fullScreenCover(item: $readingBook) { saved in
            ReaderView(book: saved, api: session.api, chapters: chapters, startChapterIndex: startIndex)
        }
    }

    // MARK: - 头部

    private var displayBook: Book {
        detail?.book ?? book
    }

    private var header: some View {
        HStack(alignment: .top, spacing: 16) {
            BookCoverView(book: displayBook, coverURL: session.api.resolve(displayBook.coverUrl))
                .frame(width: 104)
            VStack(alignment: .leading, spacing: 6) {
                Text(displayBook.name)
                    .font(.system(size: 21, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.ink)
                    .fixedSize(horizontal: false, vertical: true)
                Text(displayBook.author.isEmpty ? "佚名" : displayBook.author)
                    .font(.subheadline)
                    .foregroundStyle(Palette.secondaryInk)
                if let kind = displayBook.kind, !kind.isEmpty {
                    Text(kind)
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(2)
                }
                HStack(spacing: 8) {
                    metaChip(icon: "books.vertical", text: "\(chapters.count) 章")
                    if let originName = displayBook.originName, !originName.isEmpty {
                        metaChip(icon: "antenna.radiowaves.left.and.right", text: originName)
                    }
                }
                .padding(.top, 2)
                if shelfBook != nil {
                    Label("已在书架", systemImage: "checkmark.circle.fill")
                        .font(.caption)
                        .foregroundStyle(Palette.accent)
                }
            }
            Spacer(minLength: 0)
        }
    }

    private func metaChip(icon: String, text: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 9))
            Text(text).font(.system(size: 10))
        }
        .foregroundStyle(Palette.secondaryInk)
        .padding(.horizontal, 7)
        .padding(.vertical, 3)
        .background(Capsule().fill(Palette.hairline.opacity(0.35)))
        .lineLimit(1)
    }

    // MARK: - 操作

    private var actionRow: some View {
        VStack(spacing: 10) {
            Button {
                Task { await startReading(at: nil) }
            } label: {
                HStack(spacing: 8) {
                    if isSaving {
                        ProgressView().tint(.white).scaleEffect(0.8)
                    } else {
                        Image(systemName: "book.fill")
                    }
                    Text(readingTitle)
                }
            }
            .buttonStyle(PrimaryButtonStyle(isEnabled: !isSaving))
            .disabled(isSaving)

            if shelfBook == nil {
                Button {
                    Task { await addToShelf() }
                } label: {
                    Label("加入书架", systemImage: "plus")
                }
                .buttonStyle(SecondaryButtonStyle())
                .disabled(isSaving)
            }
        }
    }

    private var readingTitle: String {
        if let index = shelfBook?.durChapterIndex, index > 0 {
            return "继续阅读 · 第 \(index + 1) 章"
        }
        if let first = chapters.first(where: { !$0.isTitleOnly }) {
            return "开始阅读 · \(first.title)"
        }
        return "开始阅读"
    }

    // MARK: - 简介

    private func introSection(_ text: String) -> some View {
        Card(padding: 14) {
            VStack(alignment: .leading, spacing: 8) {
                Text("简介")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.secondaryInk)
                Text(text)
                    .font(.system(size: 14))
                    .foregroundStyle(Palette.ink)
                    .lineSpacing(5)
                    .lineLimit(introExpanded ? nil : 6)
                    .fixedSize(horizontal: false, vertical: true)
                Button(introExpanded ? "收起" : "展开全部") {
                    withAnimation { introExpanded.toggle() }
                }
                .font(.caption.weight(.medium))
                .foregroundStyle(Palette.accent)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    // MARK: - 目录

    private var chapterSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("目录")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                Text("\(chapters.count) 章")
                    .font(.caption)
                    .foregroundStyle(Palette.secondaryInk)
                Spacer()
                if chapters.count > 8 {
                    Button("全部目录") { showAllChapters = true }
                        .font(.caption.weight(.medium))
                        .foregroundStyle(Palette.accent)
                }
            }
            if chapters.isEmpty {
                Text(detail?.chaptersError ?? "目录暂时没有加载出来，可以稍后重试。")
                    .font(.footnote)
                    .foregroundStyle(Palette.secondaryInk)
                    .padding(.vertical, 8)
            } else {
                VStack(spacing: 0) {
                    ForEach(chapters.prefix(8)) { chapter in
                        Button {
                            Task { await startReading(at: chapter.index) }
                        } label: {
                            HStack(spacing: 10) {
                                Text(chapter.title)
                                    .font(.system(size: 14))
                                    .foregroundStyle(Palette.ink)
                                    .lineLimit(1)
                                Spacer(minLength: 0)
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundStyle(Palette.secondaryInk.opacity(0.5))
                            }
                            .padding(.vertical, 11)
                            .padding(.horizontal, 14)
                        }
                        .buttonStyle(.plain)
                        if chapter.index != chapters.prefix(8).last?.index {
                            Divider().padding(.leading, 14)
                        }
                    }
                }
                .background(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.white.opacity(0.72))
                )
            }
        }
    }

    // MARK: - 行为

    private func load() async {
        isLoading = detail == nil
        do {
            let result = try await session.api.bookDetails(book)
            detail = result
            chapters = result.chapters
            if let chaptersError = result.chaptersError, !chaptersError.isEmpty {
                errorMessage = chaptersError
            }
            let shelf = try? await session.api.shelf()
            shelfBook = shelf?.first {
                $0.bookUrl == result.book.bookUrl
                    || ($0.name == result.book.name && $0.author == result.book.author)
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func addToShelf() async {
        guard let detail else { return }
        isSaving = true
        do {
            let saved = try await session.api.saveBook(detail.book)
            shelfBook = saved
            toastText = "已加入书架"
        } catch {
            errorMessage = error.localizedDescription
        }
        isSaving = false
    }

    private func startReading(at index: Int?) async {
        guard let detail else { return }
        isSaving = true
        defer { isSaving = false }

        var resolved: Book?
        if let shelfBook {
            resolved = shelfBook
        } else {
            do {
                let saved = try await session.api.saveBook(detail.book)
                shelfBook = saved
                resolved = saved
            } catch {
                errorMessage = error.localizedDescription
                return
            }
        }
        guard let target = resolved else { return }
        startIndex = index
        readingBook = target
    }
}
