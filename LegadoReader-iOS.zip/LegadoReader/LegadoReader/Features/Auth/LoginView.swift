import SwiftUI

struct LoginView: View {
    @EnvironmentObject private var session: AppSession

    @State private var username = ""
    @State private var password = ""
    @State private var isBusy = false
    @State private var errorMessage: String?
    @State private var showHelp = false
    @FocusState private var focus: Field?

    private enum Field: Hashable {
        case address
        case username
        case password
    }

    var body: some View {
        ZStack {
            PaperBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    connectionCard
                    if let banner = errorMessage ?? session.lastError {
                        ErrorBanner(message: banner)
                    }
                    signInButton
                    helpCard
                }
                .padding(.horizontal, 20)
                .padding(.top, 36)
                .padding(.bottom, 40)
            }
            .scrollDismissesKeyboard(.interactively)
        }
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 14) {
            SealMark(size: 56)
            VStack(alignment: .leading, spacing: 4) {
                Text("留白")
                    .font(.system(size: 28, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.ink)
                Text("Legado 阅读 · 原生 iOS 客户端")
                    .font(.footnote)
                    .foregroundStyle(Palette.secondaryInk)
            }
            Spacer()
        }
        .padding(.bottom, 6)
    }

    private var connectionCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 14) {
                Text("连接你的阅读服务")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                Text("App 自身不抓取网站，书籍搜索和正文由你部署的留白·Legado Web 服务执行。")
                    .font(.footnote)
                    .foregroundStyle(Palette.secondaryInk)
                    .fixedSize(horizontal: false, vertical: true)

                VStack(alignment: .leading, spacing: 6) {
                    fieldLabel("服务器地址")
                    TextField("http://192.168.1.20:3001", text: $session.serverAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .textContentType(.URL)
                        .focused($focus, equals: .address)
                        .submitLabel(.next)
                        .onSubmit { focus = .username }
                        .inputField()
                }

                VStack(alignment: .leading, spacing: 6) {
                    fieldLabel("用户名")
                    TextField("登录账号", text: $username)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textContentType(.username)
                        .focused($focus, equals: .username)
                        .submitLabel(.next)
                        .onSubmit { focus = .password }
                        .inputField()
                }

                VStack(alignment: .leading, spacing: 6) {
                    fieldLabel("密码")
                    SecureField("至少 12 位", text: $password)
                        .textContentType(.password)
                        .focused($focus, equals: .password)
                        .submitLabel(.go)
                        .onSubmit(signIn)
                        .inputField()
                }
            }
        }
    }

    private func fieldLabel(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 13, weight: .medium))
            .foregroundStyle(Palette.secondaryInk)
    }

    private var signInButton: some View {
        Button(action: signIn) {
            HStack(spacing: 8) {
                if isBusy {
                    ProgressView()
                        .tint(.white)
                        .scaleEffect(0.8)
                }
                Text(isBusy ? "正在连接…" : "登录阅读")
            }
        }
        .buttonStyle(PrimaryButtonStyle(isEnabled: canSubmit && !isBusy))
        .disabled(!canSubmit || isBusy)
    }

    private var canSubmit: Bool {
        !username.trimmingCharacters(in: .whitespaces).isEmpty
            && !password.isEmpty
            && !session.serverAddress.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private var helpCard: some View {
        Card {
            DisclosureGroup(isExpanded: $showHelp) {
                VStack(alignment: .leading, spacing: 10) {
                    helpStep("1", "在电脑、NAS 或 VPS 部署 kanshu-web（Docker 或本机 npm run dev），默认端口 3001。")
                    helpStep("2", "把服务端 .env 的 LEGADO_PUBLIC_ORIGIN 设为 App 要访问的地址，例如 http://192.168.1.20:3001，否则会被 403 拒绝。")
                    helpStep("3", "首次启动的账号密码在 data/bootstrap-admin.txt，用它登录后可导入书源。")
                    helpStep("4", "导入书源 JSON 后，回到 App 搜索即可看到书籍。")
                    Link(destination: URL(string: "https://github.com/PeterFile/kanshu-web")!) {
                        HStack(spacing: 6) {
                            Image(systemName: "link")
                            Text("查看服务端开源项目")
                        }
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(Palette.accent)
                    }
                    .padding(.top, 2)
                }
                .padding(.top, 10)
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "questionmark.circle")
                        .foregroundStyle(Palette.accent)
                    Text("还没有服务器？")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                }
            }
            .tint(Palette.secondaryInk)
        }
    }

    private func helpStep(_ index: String, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text(index)
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 18, height: 18)
                .background(Circle().fill(Palette.accent.opacity(0.85)))
            Text(text)
                .font(.footnote)
                .foregroundStyle(Palette.secondaryInk)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func signIn() {
        guard canSubmit, !isBusy else { return }
        focus = nil
        isBusy = true
        errorMessage = nil
        let account = username.trimmingCharacters(in: .whitespaces)
        Task { @MainActor in
            do {
                try await session.login(username: account, password: password)
                password = ""
            } catch {
                errorMessage = error.localizedDescription
            }
            isBusy = false
        }
    }
}
