import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var session: AppSession

    @State private var readingSettings = ReadingSettings.load()
    @StateObject private var stats = ReadingStatsStore.shared
    @State private var showReadingSettings = false
    @State private var showSourceHealth = false
    @State private var showServerEditor = false
    @State private var showLogoutConfirm = false
    @State private var serverDraft = ""
    @State private var isHealthy: Bool?
    @State private var isChecking = false
    @State private var showChangelog = false
    @State private var showReadingHistory = false
    @State private var showReadingStats = false
    @State private var showStorage = false

    /// 来自 Info.plist，构建脚本写入的版本号。
    private var versionText: String {
        let info = Bundle.main.infoDictionary
        let short = info?["CFBundleShortVersionString"] as? String ?? "1.11"
        let build = info?["CFBundleVersion"] as? String ?? "13"
        return "\(short) · build \(build)"
    }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 18) {
                        accountCard
                        serviceCard
                        adminCard
                        readingCard
                        readingHistoryCard
                        readingStatsCard
                        storageCard
                        aboutCard
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("我的")
            .task { await checkHealth() }
            .sheet(isPresented: $showReadingSettings) {
                ReaderSettingsSheet(
                    settings: Binding(
                        get: { readingSettings },
                        set: { newValue in
                            readingSettings = newValue
                            newValue.save()
                        }
                    )
                )
            }
            .sheet(isPresented: $showServerEditor) { serverEditor }
            .sheet(isPresented: $showSourceHealth) { SourceHealthView() }
            .sheet(isPresented: $showChangelog) { ChangelogView(version: versionText) }
            .sheet(isPresented: $showReadingHistory) { ReadingHistoryView() }
            .sheet(isPresented: $showReadingStats) { ReadingStatsView() }
            .sheet(isPresented: $showStorage) { StorageView() }
            .confirmationDialog("确定退出登录？", isPresented: $showLogoutConfirm, titleVisibility: .visible) {
                Button("退出登录", role: .destructive) {
                    Task { await session.logout() }
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("退出后需要重新输入账号密码，书架数据仍保存在服务端。")
            }
        }
    }

    // MARK: - 账号

    private var accountCard: some View {
        Card {
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .fill(Palette.accent.opacity(0.12))
                    Text(String((session.user?.username ?? "?").prefix(1)).uppercased())
                        .font(.system(size: 20, weight: .semibold, design: .serif))
                        .foregroundStyle(Palette.accent)
                }
                .frame(width: 54, height: 54)

                VStack(alignment: .leading, spacing: 4) {
                    Text(session.user?.username ?? "未登录")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    HStack(spacing: 6) {
                        Text((session.user?.isAdmin ?? false) ? "超级管理员" : "普通用户")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(Palette.accent)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Palette.accent.opacity(0.1)))
                        Text("留白 · Legado Web")
                            .font(.system(size: 10))
                            .foregroundStyle(Palette.secondaryInk)
                    }
                }
                Spacer(minLength: 0)
            }
        }
    }

    // MARK: - 服务

    private var serviceCard: some View {
        Card(padding: 0) {
            VStack(spacing: 0) {
                row(icon: "server.rack", title: "服务器地址", detail: session.serverAddress) {
                    serverDraft = session.serverAddress
                    showServerEditor = true
                }
                Divider().padding(.leading, 52)
                HStack(spacing: 12) {
                    rowIcon("bolt.horizontal.circle")
                    VStack(alignment: .leading, spacing: 2) {
                        Text("连接状态")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(Palette.ink)
                        Text(healthText)
                            .font(.caption)
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    Spacer()
                    if isChecking {
                        ProgressView().tint(Palette.accent).scaleEffect(0.8)
                    } else {
                        Button("测试") { Task { await checkHealth() } }
                            .font(.caption.weight(.medium))
                            .foregroundStyle(Palette.accent)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
        }
    }

    private var healthText: String {
        guard let isHealthy else { return "尚未检测" }
        return isHealthy ? "服务端可访问，书源由它执行" : "无法连接，请检查地址与网络"
    }

    // MARK: - 书源（管理员）

    private var adminCard: some View {
        Card(padding: 0) {
            row(icon: "books.vertical", title: "书源管理", detail: "巡检失效 · 测速 · 启停与删除") {
                showSourceHealth = true
            }
        }
    }

    // MARK: - 阅读

    private var readingCard: some View {
        Card(padding: 0) {
            row(icon: "textformat", title: "阅读排版", detail: "\(readingSettings.fontKind.title) · \(Int(readingSettings.fontSize))pt · \(readingSettings.theme.title)") {
                showReadingSettings = true
            }
        }
    }

    // MARK: - 阅读记录

    private var readingHistoryCard: some View {
        Card(padding: 0) {
            row(icon: "clock.arrow.circlepath", title: "阅读记录", detail: "最近读过的书 · 读到第几章") {
                showReadingHistory = true
            }
        }
    }

    // MARK: - 阅读统计

    private var readingStatsCard: some View {
        Card(padding: 0) {
            row(
                icon: "chart.bar.xaxis",
                title: "阅读统计",
                detail: "本周 \(ReadingDuration.compact(stats.seconds(inLastDays: 7))) · 读过 \(stats.bookCount) 本"
            ) {
                showReadingStats = true
            }
        }
    }

    // MARK: - 存储空间

    private var storageCard: some View {
        Card(padding: 0) {
            row(icon: "internaldrive", title: "存储空间", detail: "缓存占用 · 一键清理") {
                showStorage = true
            }
        }
    }

    // MARK: - 关于

    private var aboutCard: some View {
        Card(padding: 0) {
            VStack(spacing: 0) {
                Button {
                    showChangelog = true
                } label: {
                    HStack(spacing: 12) {
                        rowIcon("info.circle")
                        VStack(alignment: .leading, spacing: 2) {
                            Text("关于留白阅读")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundStyle(Palette.ink)
                            Text("版本 \(versionText)")
                                .font(.caption)
                                .foregroundStyle(Palette.secondaryInk)
                        }
                        Spacer(minLength: 8)
                        Text("更新记录")
                            .font(.caption)
                            .foregroundStyle(Palette.accent)
                        Image(systemName: "chevron.right")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(Palette.secondaryInk.opacity(0.6))
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                Divider().padding(.leading, 52)

                Link(destination: URL(string: "https://github.com/PeterFile/kanshu-web")!) {
                    HStack(spacing: 12) {
                        rowIcon("chevron.left.forwardslash.chevron.right")
                        Text("服务端开源项目（GPL-3.0）")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(Palette.ink)
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.caption)
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }

                Divider().padding(.leading, 52)

                Button {
                    showLogoutConfirm = true
                } label: {
                    HStack(spacing: 12) {
                        rowIcon("rectangle.portrait.and.arrow.right")
                        Text("退出登录")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(Palette.accent)
                        Spacer()
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func rowIcon(_ name: String) -> some View {
        Image(systemName: name)
            .font(.system(size: 16))
            .foregroundStyle(Palette.accent)
            .frame(width: 24, height: 24)
    }

    private func row(icon: String, title: String, detail: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                rowIcon(icon)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(Palette.ink)
                    Text(detail)
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Palette.secondaryInk.opacity(0.6))
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: - 服务器编辑

    private var serverEditor: some View {
        NavigationStack {
            Form {
                Section("服务器地址") {
                    TextField("http://192.168.1.20:3001", text: $serverDraft)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                }
                Section {
                    Text("修改地址会退出当前登录。请确认服务端的 LEGADO_PUBLIC_ORIGIN 已包含新地址，否则请求会被拒绝。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Section {
                    Button("保存并重新登录") {
                        showServerEditor = false
                        session.switchServer(serverDraft)
                    }
                    .foregroundStyle(Palette.accent)
                }
            }
            .navigationTitle("修改服务器")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { showServerEditor = false }
                }
            }
        }
        .presentationDetents([.medium])
    }

    // MARK: - 行为

    private func checkHealth() async {
        isChecking = true
        do {
            try await session.api.health()
            isHealthy = true
        } catch {
            isHealthy = false
        }
        isChecking = false
    }
}

// MARK: - 阅读记录

private struct ReadingHistoryView: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    @State private var books: [Book] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    private var history: [Book] {
        books
            .filter { ($0.lastReadTime ?? 0) > 0 }
            .sorted { ($0.lastReadTime ?? 0) > ($1.lastReadTime ?? 0) }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 12) {
                        if isLoading {
                            ProgressView().padding(.vertical, 40)
                        } else if let errorMessage {
                            ErrorBanner(message: errorMessage)
                        } else if history.isEmpty {
                            EmptyStateView(
                                icon: "clock",
                                title: "还没有阅读记录",
                                message: "在书架打开一本书读几章，这里就会按最近阅读排出记录。"
                            )
                        } else {
                            Text("共 \(history.count) 本 · 按最近阅读排序")
                                .font(.caption2)
                                .foregroundStyle(Palette.secondaryInk)
                                .frame(maxWidth: .infinity, alignment: .leading)

                            Card(padding: 0) {
                                VStack(spacing: 0) {
                                    ForEach(history) { book in
                                        NavigationLink(value: book) {
                                            historyRow(book)
                                        }
                                        .buttonStyle(.plain)
                                        if book.id != history.last?.id {
                                            Divider().padding(.leading, 14)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("阅读记录")
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(for: Book.self) { book in
                BookDetailView(book: book)
            }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
            }
            .task { await load() }
        }
    }

    private func historyRow(_ book: Book) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Text(book.name)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(1)
                if book.mediaType == "image" || book.mediaType == "comic" {
                    Text("漫画")
                        .font(.system(size: 9, weight: .medium))
                        .foregroundStyle(Palette.secondaryInk)
                        .padding(.horizontal, 5)
                        .padding(.vertical, 1)
                        .background(Capsule().fill(Palette.secondaryInk.opacity(0.10)))
                }
                Spacer(minLength: 6)
                Text(book.lastReadText)
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }

            Text(book.durChapterTitle ?? "未开始阅读")
                .font(.caption)
                .foregroundStyle(Palette.secondaryInk)
                .lineLimit(1)

            if let total = book.totalChapterNum, total > 0 {
                ProgressView(value: book.progressFraction)
                    .tint(Palette.accent)
                Text("第 \((book.durChapterIndex ?? 0) + 1) / \(total) 章")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .contentShape(Rectangle())
    }

    private func load() async {
        isLoading = true
        do {
            books = try await session.api.shelf()
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}

// MARK: - 更新记录

private struct ChangelogView: View {
    var version: String
    @Environment(\.dismiss) private var dismiss

    private struct Entry: Identifiable {
        var version: String
        var date: String
        var items: [String]
        var id: String { version }
    }

    private let entries: [Entry] = [
        Entry(
            version: "1.26",
            date: "2026-11-28",
            items: [
                "书源检测提速：探活并发 20 → 40、超时压到 3 秒，搜索验证并发 8 → 14，单源 12 秒无数据就断开、总时长 20 秒封顶",
                "检测每跑完一批就存一次缓存，中途退出、被打断都不会白跑",
                "书源管理新增「只探活（快）」开关：只发一次首页请求，几十秒就能把失联站点筛出来",
                "新增「关闭劣质源」：一键把检测失败的源按本地开关表关掉，不发请求也不进搜索结果，服务端一个字节都不动",
                "检测结果按「响应速度 + 简介字数」分出优质与可用两档：优质源（响应 ≤1.5 秒、简介 ≥120 字）在列表里带「优质」标签、单独成组，顶部统计分开计数",
            ]
        ),
        Entry(
            version: "1.25",
            date: "2026-11-28",
            items: [
                "书架长按任意一本书直接进入多选，并自动勾上这一本，不用再点右上角「选择」；多选底部新增「详情」",
                "段首缩进、段尾缩进改成可调：「格式」里两个滑杆，0–6 字、0.5 字一步，字号变了缩进跟着折算",
                "左右页边距可以拖到 0，正文能贴到接近屏幕边缘，四边都能单独调",
                "书架卡片显示每本书累计读了多少分钟（网格、列表、本地书都显示），过 1 小时自动换算成「X 小时 Y 分」",
                "阅读时长纯本地记录，切后台或锁屏就停止计时，删书时连带清掉这本书的时长",
                "书架卡片显示书源的真实封面：接口没带封面的书，进书架时自动补抓一次并记到本地，抓到就换成图，抓不到继续用文字封面",
                "去掉书架顶部「继续阅读」大卡片：点书架里的书已经能直接接着读，这个入口是重复的",
                "中文避头尾：逗号句号这类标点不会再掉到行首，开引号开括号也不会孤零零留在行尾",
                "阅读器「…」菜单新增「下载整本」：逐章把整本存到手机，断网、地铁里也能一路读，顶部有进度和取消",
                "支持音量键翻页：按大下一页、按小上一页，音量自动拨回原位，不影响实际音量",
                "目录右下角加了「当前章」按钮，两千多章的书一键回到在读位置",
                "读到最后一章时书架上的百分比换成「已读完」",
                "换书源之后自动清掉旧书源留下的离线正文和封面缓存，不再白占空间",
                "「我的」新增阅读统计：累计时长、今天、本周、日均，还有近 7 天的柱状图",
                "存储空间新增「整本离线」：列出下载过的书和占用，可以逐本清、也能全部清"
            ]
        ),
        Entry(
            version: "1.24",
            date: "2026-11-27",
            items: [
                "书架新增多选管理：进多选态后点书勾选，顶部全选/取消全选，底部可一键置顶、取消置顶或批量删除",
                "置顶的书排在书架最前（服务端书架和本地 TXT 都支持），封面右上角有图钉角标",
                "置顶记录存在手机本地（liubai-shelf-pins.json），重启和换源都还在；单本也可以长按直接置顶",
                "加入/移出书架后书架立刻更新：阅读器和详情页一改完就通知书架重拉，不用再手动点刷新",
                "书架每次切进来也会自动重拉一次，别的地方改了书架这里也是最新的",
                "下一章预取：打开章节先备好下一章，读到本章 60% 再把后面一章也拉好（始终领先 2 章），翻章不转圈；预取失败会自动重试，最多 3 次",
                "预取按章独立进行，读得快也互不打断；WiFi 和数据下都会预取"
            ]
        ),
        Entry(
            version: "1.23",
            date: "2026-11-27",
            items: [
                "继续搜索改成只补没搜过的书源：记下本轮已经出过结果的书源，每次点继续往后推 40 个，不会再把全部书源重跑",
                "阅读器顶栏收进「…」菜单：换源、加入/移出书架、目录都在里面，书名和章节名不再被按钮挤掉",
                "移出书架会先把读到第几章的位置存下来再重建，回来还是同一章",
                "书架新增列表视图：一行一本，带阅读进度和正在读的章节名，和网格视图可在排序菜单里切换",
                "详情页默认只读前 3 个源的章数，点「展开其余」才批量读，点书源更不卡"
            ]
        ),
        Entry(
            version: "1.22",
            date: "2026-11-27",
            items: [
                "搜索详情点「开始阅读」只记成可阅读，不再自动占书架；书架要多一本必须自己点「加入书架」",
                "阅读器顶部按钮常显：不在书架是可点的「加入书架」，在书架变成「移出书架」，移出后仍能接着读这本",
                "是否在书架按服务端书架列表实际比对，不再依赖书对象上的本地字段",
                "书架点书直接进正文，不再绕详情页；要换源或看简介用长按菜单里的「书籍详情」",
                "搜索只保留书名一字不差的结果，模糊命中不再显示；预算法改成精确书源堆到 40 家、或扫过 200 家还没增长就自动停"
            ]
        ),
        Entry(
            version: "1.20",
            date: "2026-11-27",
            items: [
                "点书源不再卡：详情页不再预先抓全部目录，只做一次「记进可阅读」直接进正文，章数探测降到 2 并发并延后 0.9 秒让位",
                "阅读器顶部「换源」旁边新增「加入书架」：点了才真正进书架，从书架点进来就是当前这个书源，直接看正文",
                "书源排序改成正文字数最多的置顶，没有字数就按章数估，换过的源仍然置底"
            ]
        ),
        Entry(
            version: "1.19",
            date: "2026-11-27",
            items: [
                "继续搜索改成真正接着上次进度：已搜完的书源直接命中服务端 30 分钟缓存、秒回，只重新检索没搜过的源",
                "修掉上一个版本 resume 参数无效、点继续等于从头搜一遍的问题",
                "修掉详情页点书源进入阅读报「未在书架找到此书」——现在会先记进可阅读再打开",
                "详情页书源栏改成竖排，一行一个源，显示这家源共多少章和最新一章的章节名",
                "搜索结果里每个书源的下面也标出总章数和最新一章"
            ]
        ),
        Entry(
            version: "1.17",
            date: "2026-11-27",
            items: [
                "修复书源一排只显示 1 个：精确搜索的源会被逐个记录，不再被最后一条覆盖",
                "从搜索结果点书进详情时，直接把这本书的全部来源一起带过去，不依赖缓存时效",
                "换过的源只是排到列表后面，不会被移出或清空"
            ]
        ),
        Entry(
            version: "1.16",
            date: "2026-11-27",
            items: [
                "书籍详情页顶部新增「书源」一排：精确搜索命中的书源直接列出来，点一个就切到该源开始读",
                "当前源固定在最前，换过的源排在后面；每个源标了当前 / 换过 / 未用和章数",
                "点其他源会先取那家源的目录再进阅读器，取不到会给出提示"
            ]
        ),
        Entry(
            version: "1.15",
            date: "2026-11-27",
            items: [
                "书源开关改成本地生效：不用管理员权限，「全部启用 / 全部停用」和单个开关点了就记住",
                "搜索只按本地开关过滤，你关掉的源不再出现在结果里",
                "精确搜索命中的书源自动记 1 小时（最多 20 个书名），进详情换源就能看到上次搜到的源",
                "换源面板把换过的书源自动置底，优先显示还没换过的",
                "新增「存储空间」：查看网络缓存、检测缓存、搜索备忘的占用，支持单项清理和一键清理"
            ]
        ),
        Entry(
            version: "1.14",
            date: "2026-11-27",
            items: [
                "书源检测改成两级：先探站点连通性（20 并发、4 秒超时），连不通直接判失联，不再浪费搜索",
                "只对连通的源跑搜索验证，并发从 3 提到 8",
                "检测结果缓存 24 小时，只测新增或过期的源；右上菜单可清空缓存",
                "「站点失联」与「规则失效」分开标注，一眼看出该换源还是等站点恢复",
                "书源管理新增分组全选：小说 / 漫画各自「全部启用」「全部停用」一键开关"
            ]
        ),
        Entry(
            version: "1.13",
            date: "2026-11-27",
            items: [
                "搜索结果分成「精确（N）」与「模糊（M）」两段，括号里是书源条数",
                "精确 = 书名与关键词一字不差，排在模糊前面，不限条数",
                "精确累计到 100 条、或模糊累计到 500 条时自动暂停搜索，已返回结果全部保留",
                "搜索关键词在发起时锁定，中途改输入框不会打乱分区"
            ]
        ),
        Entry(
            version: "1.12",
            date: "2026-11-27",
            items: [
                "「我的」与「找书」的书源管理入口不再依赖管理员身份判断，所有账号都能进入",
                "角色判断兼容 admin / ADMIN / administrator / superadmin 等写法",
                "服务端若是普通账号权限，页面自动切为只读：可检测、可看优质/劣质，并明确提示哪些操作需要管理员",
                "搜索激活时导航栏会隐藏，退出搜索即可看到「找书」右上角的书源入口"
            ]
        ),
        Entry(
            version: "1.11",
            date: "2026-11-27",
            items: [
                "找书页新增「书源管理」入口，检测、添加、去重集中在一页",
                "书源检测改为随机取一本全网常见的长篇小说（如斗破苍穹），逐个书源搜索验证",
                "报错、搜不到、或返回简介字数过少，直接判为劣质",
                "书源按「优质 / 劣质 / 未检测」分组，并区分小说与漫画书源",
                "支持粘贴 Legado 书源 JSON 导入，规则字段原样保存",
                "支持按书源名称一键去重，同名保留已启用且 URL 更短的那条",
                "「我的」新增阅读记录：按最近阅读排序，显示读到第几章与进度",
                "找书页新增最近搜索：最多保留 20 条，可逐条删除，重复词自动置顶",
                "设置页显示版本号与更新记录"
            ]
        ),
        Entry(
            version: "1.10",
            date: "2026-11-26",
            items: [
                "滑动翻页读到章节末尾自动进入下一章",
                "书源巡检、测速、启停、恢复与删除",
                "目录与正文加载体验优化"
            ]
        ),
        Entry(
            version: "1.9",
            date: "2026-11-20",
            items: [
                "漫画书源与图片阅读支持",
                "阅读中一键切换书源"
            ]
        )
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        Card {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("留白阅读")
                                    .font(.system(size: 17, weight: .semibold, design: .serif))
                                    .foregroundStyle(Palette.ink)
                                Text("当前版本 \(version)")
                                    .font(.caption)
                                    .foregroundStyle(Palette.secondaryInk)
                                Text("原生 iOS 客户端 · 书源规则由服务端 Java 核心执行")
                                    .font(.caption)
                                    .foregroundStyle(Palette.secondaryInk)
                            }
                        }

                        ForEach(entries) { entry in
                            Card {
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack(spacing: 8) {
                                        Text("v\(entry.version)")
                                            .font(.system(size: 14, weight: .semibold))
                                            .foregroundStyle(Palette.accent)
                                        Text(entry.date)
                                            .font(.caption2)
                                            .foregroundStyle(Palette.secondaryInk)
                                        Spacer()
                                    }
                                    ForEach(Array(entry.items.enumerated()), id: \.offset) { _, item in
                                        HStack(alignment: .top, spacing: 6) {
                                            Text("·")
                                                .font(.caption)
                                                .foregroundStyle(Palette.accent)
                                            Text(item)
                                                .font(.system(size: 12))
                                                .foregroundStyle(Palette.ink)
                                                .fixedSize(horizontal: false, vertical: true)
                                            Spacer(minLength: 0)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("更新记录")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
            }
        }
    }
}
