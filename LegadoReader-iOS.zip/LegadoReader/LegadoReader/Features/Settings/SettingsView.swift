import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var session: AppSession

    @State private var readingSettings = ReadingSettings.load()
    @State private var showReadingSettings = false
    @State private var showServerEditor = false
    @State private var showLogoutConfirm = false
    @State private var serverDraft = ""
    @State private var isHealthy: Bool?
    @State private var isChecking = false

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 18) {
                        accountCard
                        serviceCard
                        readingCard
                        aboutCard
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("我的")
            .task { await checkHealth() }
            .sheet(isPresented: $showReadingSettings) {
                ReaderSettingsSheet(
                    settings: Binding(
                        get: { readingSettings },
                        set: { newValue in
                            readingSettings = newValue
                            newValue.save()
                        }
                    )
                )
            }
            .sheet(isPresented: $showServerEditor) { serverEditor }
            .confirmationDialog("确定退出登录？", isPresented: $showLogoutConfirm, titleVisibility: .visible) {
                Button("退出登录", role: .destructive) {
                    Task { await session.logout() }
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("退出后需要重新输入账号密码，书架数据仍保存在服务端。")
            }
        }
    }

    // MARK: - 账号

    private var accountCard: some View {
        Card {
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .fill(Palette.accent.opacity(0.12))
                    Text(String((session.user?.username ?? "?").prefix(1)).uppercased())
                        .font(.system(size: 20, weight: .semibold, design: .serif))
                        .foregroundStyle(Palette.accent)
                }
                .frame(width: 54, height: 54)

                VStack(alignment: .leading, spacing: 4) {
                    Text(session.user?.username ?? "未登录")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    HStack(spacing: 6) {
                        Text((session.user?.isAdmin ?? false) ? "超级管理员" : "普通用户")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(Palette.accent)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Palette.accent.opacity(0.1)))
                        Text("留白 · Legado Web")
                            .font(.system(size: 10))
                            .foregroundStyle(Palette.secondaryInk)
                    }
                }
                Spacer(minLength: 0)
            }
        }
    }

    // MARK: - 服务

    private var serviceCard: some View {
        Card(padding: 0) {
            VStack(spacing: 0) {
                row(icon: "server.rack", title: "服务器地址", detail: session.serverAddress) {
                    serverDraft = session.serverAddress
                    showServerEditor = true
                }
                Divider().padding(.leading, 52)
                HStack(spacing: 12) {
                    rowIcon("bolt.horizontal.circle")
                    VStack(alignment: .leading, spacing: 2) {
                        Text("连接状态")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(Palette.ink)
                        Text(healthText)
                            .font(.caption)
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    Spacer()
                    if isChecking {
                        ProgressView().tint(Palette.accent).scaleEffect(0.8)
                    } else {
                        Button("测试") { Task { await checkHealth() } }
                            .font(.caption.weight(.medium))
                            .foregroundStyle(Palette.accent)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
        }
    }

    private var healthText: String {
        guard let isHealthy else { return "尚未检测" }
        return isHealthy ? "服务端可访问，书源由它执行" : "无法连接，请检查地址与网络"
    }

    // MARK: - 阅读

    private var readingCard: some View {
        Card(padding: 0) {
            row(icon: "textformat", title: "阅读排版", detail: "\(readingSettings.fontKind.title) · \(Int(readingSettings.fontSize))pt · \(readingSettings.theme.title)") {
                showReadingSettings = true
            }
        }
    }

    // MARK: - 关于

    private var aboutCard: some View {
        Card(padding: 0) {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    rowIcon("info.circle")
                    VStack(alignment: .leading, spacing: 2) {
                        Text("关于留白阅读")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(Palette.ink)
                        Text("原生 iOS 客户端 · 书源规则由服务端 Java 核心执行")
                            .font(.caption)
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    Spacer()
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)

                Divider().padding(.leading, 52)

                Link(destination: URL(string: "https://github.com/PeterFile/kanshu-web")!) {
                    HStack(spacing: 12) {
                        rowIcon("chevron.left.forwardslash.chevron.right")
                        Text("服务端开源项目（GPL-3.0）")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(Palette.ink)
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.caption)
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }

                Divider().padding(.leading, 52)

                Button {
                    showLogoutConfirm = true
                } label: {
                    HStack(spacing: 12) {
                        rowIcon("rectangle.portrait.and.arrow.right")
                        Text("退出登录")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(Palette.accent)
                        Spacer()
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func rowIcon(_ name: String) -> some View {
        Image(systemName: name)
            .font(.system(size: 16))
            .foregroundStyle(Palette.accent)
            .frame(width: 24, height: 24)
    }

    private func row(icon: String, title: String, detail: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                rowIcon(icon)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(Palette.ink)
                    Text(detail)
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Palette.secondaryInk.opacity(0.6))
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: - 服务器编辑

    private var serverEditor: some View {
        NavigationStack {
            Form {
                Section("服务器地址") {
                    TextField("http://192.168.1.20:3001", text: $serverDraft)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                }
                Section {
                    Text("修改地址会退出当前登录。请确认服务端的 LEGADO_PUBLIC_ORIGIN 已包含新地址，否则请求会被拒绝。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Section {
                    Button("保存并重新登录") {
                        showServerEditor = false
                        session.switchServer(serverDraft)
                    }
                    .foregroundStyle(Palette.accent)
                }
            }
            .navigationTitle("修改服务器")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { showServerEditor = false }
                }
            }
        }
        .presentationDetents([.medium])
    }

    // MARK: - 行为

    private func checkHealth() async {
        isChecking = true
        do {
            try await session.api.health()
            isHealthy = true
        } catch {
            isHealthy = false
        }
        isChecking = false
    }
}
