import SwiftUI

/// 存储空间：展示本应用产生的本地缓存与数据，并支持单项清理。
struct StorageView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var toast: String?
    @State private var tick = 0

    private let probeCacheKey = "liubai.sourceProbeCache"
    private let searchHistoryKey = "liubai.searchHistory"

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 14) {
                        totalCard
                        cacheCard
                        offlineCard
                        dataCard
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("存储空间")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
            }
            .overlay(alignment: .bottom) {
                if let toast {
                    Text(toast)
                        .font(.caption)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(Capsule().fill(Palette.ink.opacity(0.86)))
                        .foregroundStyle(.white)
                        .padding(.bottom, 26)
                        .transition(.opacity)
                }
            }
        }
    }

    // MARK: - 卡片

    private var totalCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 6) {
                Text("本应用占用")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                Text(format(totalBytes))
                    .font(.system(size: 26, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.accent)
                Text("含网络缓存、检测缓存、搜索备忘与本地开关记录")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var cacheCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Text("缓存")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.ink)

                entryRow(
                    "网络请求缓存",
                    detail: format(networkBytes),
                    action: "清理"
                ) {
                    URLCache.shared.removeAllCachedResponses()
                    toast = "网络缓存已清理"
                    tick += 1
                }

                entryRow(
                    "书源检测结果",
                    detail: "\(format(probeCacheBytes)) · 24 小时有效",
                    action: "清理"
                ) {
                    UserDefaults.standard.removeObject(forKey: probeCacheKey)
                    toast = "检测缓存已清理"
                    tick += 1
                }

                entryRow(
                    "精确搜索书源备忘",
                    detail: "\(ExactSourceMemo.shared.count) 条 · \(format(ExactSourceMemo.shared.fileSize))",
                    action: "清理"
                ) {
                    ExactSourceMemo.shared.clear()
                    toast = "搜索备忘已清理"
                    tick += 1
                }

                entryRow(
                    "换源记录（重置排序）",
                    detail: format(SourceSwitchHistory.shared.fileSize),
                    action: "清理"
                ) {
                    SourceSwitchHistory.shared.clear()
                    toast = "换源记录已清理"
                    tick += 1
                }

                entryRow(
                    "搜索历史",
                    detail: "\(searchHistoryCount) 条",
                    action: "清理"
                ) {
                    UserDefaults.standard.removeObject(forKey: searchHistoryKey)
                    toast = "搜索历史已清理"
                    tick += 1
                }

                Button {
                    clearAllCache()
                } label: {
                    Text("一键清理全部缓存")
                        .font(.system(size: 13, weight: .medium))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(
                            RoundedRectangle(cornerRadius: 9, style: .continuous)
                                .fill(Palette.accent.opacity(0.13))
                        )
                        .foregroundStyle(Palette.accent)
                }
                .buttonStyle(.plain)
                .padding(.top, 2)
            }
        }
    }

    // MARK: - 整本离线

    private var offlineBooks: [OfflineStore.Summary] {
        _ = tick
        return OfflineStore.shared.summaries()
    }

    private var offlineBytes: Int64 {
        offlineBooks.reduce(0) { $0 + $1.bytes }
    }

    private var offlineCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("整本离线")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer(minLength: 0)
                    Text("\(offlineBooks.count) 本 · \(format(offlineBytes))")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                }

                if offlineBooks.isEmpty {
                    Text("还没有整本下载的书。阅读器右上「…」菜单里点「下载整本」，下完断网也能一路读。")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    ForEach(offlineBooks) { book in
                        entryRow(
                            book.name,
                            detail: "\(book.chapterCount) 章 · \(format(book.bytes))",
                            action: "清理"
                        ) {
                            OfflineStore.shared.clear(bookURL: book.bookUrl)
                            toast = "已清理《\(book.name)》的离线正文"
                            tick += 1
                        }
                    }

                    Button {
                        OfflineStore.shared.clearAll()
                        toast = "离线正文已全部清理"
                        tick += 1
                    } label: {
                        Text("全部清理")
                            .font(.system(size: 13, weight: .medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(
                                RoundedRectangle(cornerRadius: 9, style: .continuous)
                                    .fill(Palette.accent.opacity(0.13))
                            )
                            .foregroundStyle(Palette.accent)
                    }
                    .buttonStyle(.plain)
                    .padding(.top, 2)
                }
            }
        }
    }

    private var dataCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Text("本地数据")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.ink)

                entryRow(
                    "书源开关覆盖",
                    detail: "\(SourcePrefs.shared.overrideCount) 个 · \(format(SourcePrefs.shared.fileSize))",
                    action: "恢复服务端"
                ) {
                    SourcePrefs.shared.clear()
                    toast = "书源开关已恢复为服务端设定"
                    tick += 1
                }

                Text("开关覆盖记录你在书源管理里手动改过的源，恢复后全部跟随服务端设定。")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .id(tick)
    }

    private func entryRow(
        _ title: String,
        detail: String,
        action: String,
        perform: @escaping () -> Void
    ) -> some View {
        HStack(alignment: .center, spacing: 8) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 13))
                    .foregroundStyle(Palette.ink)
                Text(detail)
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
            Spacer(minLength: 6)
            Button(action: perform) {
                Text(action)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(Palette.accent)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(Palette.accent.opacity(0.10)))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - 数据

    private var totalBytes: Int64 {
        _ = tick
        return networkBytes + probeCacheBytes + ExactSourceMemo.shared.fileSize
            + SourceSwitchHistory.shared.fileSize + SourcePrefs.shared.fileSize
    }

    private var networkBytes: Int64 {
        Int64(URLCache.shared.currentDiskUsage) + Int64(URLCache.shared.currentMemoryUsage)
    }

    private var probeCacheBytes: Int64 {
        Int64(UserDefaults.standard.data(forKey: probeCacheKey)?.count ?? 0)
    }

    private var searchHistoryCount: Int {
        (UserDefaults.standard.array(forKey: searchHistoryKey) as? [String])?.count ?? 0
    }

    private func clearAllCache() {
        URLCache.shared.removeAllCachedResponses()
        UserDefaults.standard.removeObject(forKey: probeCacheKey)
        UserDefaults.standard.removeObject(forKey: searchHistoryKey)
        ExactSourceMemo.shared.clear()
        SourceSwitchHistory.shared.clear()
        toast = "缓存已全部清理，书源开关记录保留"
        tick += 1
    }

    private func format(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useKB, .useMB]
        formatter.countStyle = .file
        return formatter.string(fromByteCount: max(bytes, 0))
    }
}
