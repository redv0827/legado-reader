import SwiftUI

/// 阅读统计：累计时长、今天/本周/日均，再加一条近 7 天的小柱状图，最后按书列明细。
struct ReadingStatsView: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss
    @StateObject private var stats = ReadingStatsStore.shared

    /// 旧记录里可能只有 key 没有书名，就用书架/本地书的名字补上。
    @State private var shelfNames: [String: String] = [:]
    @State private var localNames: [String: String] = [:]

    private static let shortDayFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "M/d"
        return formatter
    }()

    private var weekDays: [(date: Date, seconds: Double)] { stats.recentDays(7) }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 14) {
                        heroCard
                        summaryCard
                        barsCard
                        perBookCard
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("阅读统计")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
            }
            .task { await loadTitles() }
        }
    }

    /// 统计表里只存 key 时，用书架和本地库的书名兜底。
    private func loadTitles() async {
        var localMap: [String: String] = [:]
        for book in LocalBookStore.shared.all() {
            localMap[ReadingStatsStore.key(localID: book.id)] = book.title
        }
        localNames = localMap
        do {
            let books = try await session.api.shelf()
            var shelfMap: [String: String] = [:]
            for book in books {
                shelfMap[ReadingStatsStore.key(bookURL: book.bookUrl)] = book.name
            }
            shelfNames = shelfMap
        } catch {
            // 没网/没登录时就用已记下的书名，明细照样能显示。
        }
    }

    private func title(for key: String) -> String {
        if let name = stats.name(for: key) { return name }
        if let name = localNames[key] ?? shelfNames[key], !name.isEmpty { return name }
        return key.hasPrefix("local:") ? "本地书籍" : "已移出书架的书"
    }

    private var rankedKeys: [String] { stats.rankedKeys }

    private var peakSeconds: Double {
        max(rankedKeys.map { stats.seconds(for: $0) }.max() ?? 0, 60)
    }

    // MARK: - 卡片

    private var heroCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 6) {
                Text("累计阅读")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                Text(ReadingDuration.compact(stats.totalSeconds))
                    .font(.system(size: 30, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.accent)
                Text("读过 \(stats.bookCount) 本 · 只记在这台手机上")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var summaryCard: some View {
        Card {
            HStack(spacing: 0) {
                cell("今天", ReadingDuration.compact(stats.todaySeconds))
                divider
                cell("本周", ReadingDuration.compact(stats.seconds(inLastDays: 7)))
                divider
                cell("日均", ReadingDuration.compact(stats.averagePerDay(inLastDays: 7)))
            }
        }
    }

    private var barsCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Text("近 7 天")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                HStack(alignment: .bottom, spacing: 10) {
                    ForEach(weekDays.indices, id: \.self) { index in
                        bar(weekDays[index])
                    }
                }
                .frame(height: 100)
            }
        }
    }

    // MARK: - 部件

    /// 按书统计：每本书一行，书名 + 累计时长（分钟/小时），下面一条相对长度的细进度条。
    private var perBookCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 6) {
                    Text("按书统计")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer(minLength: 6)
                    if !rankedKeys.isEmpty {
                        Text("共 \(rankedKeys.count) 本")
                            .font(.system(size: 10))
                            .foregroundStyle(Palette.secondaryInk)
                    }
                }
                if rankedKeys.isEmpty {
                    Text("还没读到半分钟，读一会儿这里就会按书列出每本读了多久")
                        .font(.system(size: 12))
                        .foregroundStyle(Palette.secondaryInk)
                        .fixedSize(horizontal: false, vertical: true)
                } else {
                    VStack(alignment: .leading, spacing: 11) {
                        ForEach(rankedKeys, id: \.self) { key in
                            bookRow(key)
                        }
                    }
                }
            }
        }
    }

    private func bookRow(_ key: String) -> some View {
        let seconds = stats.seconds(for: key)
        let ratio = min(1, max(0, seconds / peakSeconds))
        return VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 8) {
                Text(title(for: key))
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(1)
                Spacer(minLength: 8)
                Text(ReadingDuration.detail(seconds))
                    .font(.system(size: 12, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.accent)
                    .lineLimit(1)
                    .layoutPriority(1)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Palette.hairline.opacity(0.55))
                    Capsule()
                        .fill(Palette.accent.opacity(0.45))
                        .frame(width: max(3, geo.size.width * ratio))
                }
            }
            .frame(height: 3)
        }
    }

    private func cell(_ title: String, _ value: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 17, weight: .semibold, design: .serif))
                .foregroundStyle(Palette.ink)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(title)
                .font(.system(size: 11))
                .foregroundStyle(Palette.secondaryInk)
        }
        .frame(maxWidth: .infinity)
    }

    private var divider: some View {
        Rectangle()
            .fill(Palette.hairline)
            .frame(width: 1, height: 28)
    }

    private func bar(_ day: (date: Date, seconds: Double)) -> some View {
        let peak = max(weekDays.map { $0.seconds }.max() ?? 0, 60)
        let ratio = min(1, max(0, day.seconds / peak))
        return VStack(spacing: 6) {
            Spacer(minLength: 0)
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(Palette.accent.opacity(day.seconds > 0 ? 0.55 : 0.14))
                .frame(height: max(6, 76 * ratio))
            Text(Self.shortDayFormatter.string(from: day.date))
                .font(.system(size: 9))
                .foregroundStyle(Palette.secondaryInk)
        }
    }
}
