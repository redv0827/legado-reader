import SwiftUI

/// 阅读统计：累计时长、今天/本周/日均，再加一条近 7 天的小柱状图。
struct ReadingStatsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var stats = ReadingStatsStore.shared

    private static let shortDayFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "M/d"
        return formatter
    }()

    private var weekDays: [(date: Date, seconds: Double)] { stats.recentDays(7) }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 14) {
                        heroCard
                        summaryCard
                        barsCard
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("阅读统计")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }

    // MARK: - 卡片

    private var heroCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 6) {
                Text("累计阅读")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                Text(ReadingDuration.compact(stats.totalSeconds))
                    .font(.system(size: 30, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.accent)
                Text("读过 \(stats.bookCount) 本 · 只记在这台手机上")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var summaryCard: some View {
        Card {
            HStack(spacing: 0) {
                cell("今天", ReadingDuration.compact(stats.todaySeconds))
                divider
                cell("本周", ReadingDuration.compact(stats.seconds(inLastDays: 7)))
                divider
                cell("日均", ReadingDuration.compact(stats.averagePerDay(inLastDays: 7)))
            }
        }
    }

    private var barsCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Text("近 7 天")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(Palette.ink)
                HStack(alignment: .bottom, spacing: 10) {
                    ForEach(weekDays.indices, id: \.self) { index in
                        bar(weekDays[index])
                    }
                }
                .frame(height: 100)
            }
        }
    }

    // MARK: - 部件

    private func cell(_ title: String, _ value: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 17, weight: .semibold, design: .serif))
                .foregroundStyle(Palette.ink)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(title)
                .font(.system(size: 11))
                .foregroundStyle(Palette.secondaryInk)
        }
        .frame(maxWidth: .infinity)
    }

    private var divider: some View {
        Rectangle()
            .fill(Palette.hairline)
            .frame(width: 1, height: 28)
    }

    private func bar(_ day: (date: Date, seconds: Double)) -> some View {
        let peak = max(weekDays.map { $0.seconds }.max() ?? 0, 60)
        let ratio = min(1, max(0, day.seconds / peak))
        return VStack(spacing: 6) {
            Spacer(minLength: 0)
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(Palette.accent.opacity(day.seconds > 0 ? 0.55 : 0.14))
                .frame(height: max(6, 76 * ratio))
            Text(Self.shortDayFormatter.string(from: day.date))
                .font(.system(size: 9))
                .foregroundStyle(Palette.secondaryInk)
        }
    }
}
