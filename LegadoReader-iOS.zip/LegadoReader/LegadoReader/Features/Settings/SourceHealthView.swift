import SwiftUI

// MARK: - 书源巡检与管理

/// 仅管理员可见：服务端失效巡检 + 客户端手动测速，支持启用/停用、删除，
/// 高速且无错误的书源标为「优质」并加星标区分。
struct SourceHealthView: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    @State private var status: SourceHealthStatus?
    @State private var fullSources: [BookSource]?
    @State private var speed: [String: SpeedProbe] = [:]
    @State private var isLoading = false
    @State private var isScanning = false
    @State private var isProbing = false
    @State private var errorMessage: String?
    @State private var scanProgress: (checked: Int, total: Int)?
    @State private var toastText: String?
    @State private var pendingDelete: SourceHealthSource?

    private var sources: [SourceHealthSource] { status?.sources ?? [] }
    private var premiumCount: Int { sources.filter { grade(of: $0) == .premium }.count }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 14) {
                        scanCard
                        if let errorMessage {
                            ErrorBanner(message: errorMessage)
                        }
                        summaryCard
                        sourceList
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("书源管理")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
            }
            .task { await load() }
            .toast($toastText)
            .confirmationDialog(
                "删除书源",
                isPresented: Binding(
                    get: { pendingDelete != nil },
                    set: { if !$0 { pendingDelete = nil } }
                ),
                titleVisibility: .visible
            ) {
                Button("删除「\(pendingDelete?.name ?? "")」", role: .destructive) {
                    Task { await confirmDelete() }
                }
                Button("取消", role: .cancel) { pendingDelete = nil }
            } message: {
                Text("删除后搜索与换源将不再使用该书源，且不可恢复。")
            }
        }
    }

    // MARK: - 卡片

    private var scanCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Label("书源巡检", systemImage: "stethoscope")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    Button {
                        Task { await scan() }
                    } label: {
                        if isScanning {
                            ProgressView().scaleEffect(0.8)
                        } else {
                            Text("开始巡检")
                                .font(.caption.weight(.medium))
                        }
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(Palette.accent)
                    .disabled(isScanning)
                }

                if isScanning, let progress = scanProgress {
                    ProgressView(
                        value: progress.total > 0 ? Double(progress.checked) / Double(progress.total) : 0
                    )
                    .tint(Palette.accent)
                    Text("正在检查 \(progress.checked)/\(progress.total) 个书源…")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                } else if let finished = status?.lastFinishedAt {
                    Text("上次巡检：\(Self.timeText(finished)) · 检查 \(status?.checked ?? 0)/\(status?.total ?? 0) 个")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    Text("尚未巡检。巡检会逐个探测书源是否失效，连续失败会自动归档。")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                }

                if let lastError = status?.lastError, !lastError.isEmpty {
                    Text(lastError)
                        .font(.caption)
                        .foregroundStyle(Palette.accent)
                        .lineLimit(2)
                }
            }
        }
    }

    private var summaryCard: some View {
        Card {
            VStack(spacing: 12) {
                HStack {
                    stat("总数", sources.count)
                    stat("已启用", sources.filter { $0.enabled == true }.count)
                    stat("已失效", sources.filter { $0.isArchived }.count)
                    stat("优质", premiumCount)
                }
                Button {
                    Task { await probeAll() }
                } label: {
                    HStack(spacing: 8) {
                        if isProbing {
                            ProgressView().scaleEffect(0.8)
                        } else {
                            Image(systemName: "speedometer")
                        }
                        Text(isProbing ? "正在测速…" : "全部测速")
                            .font(.system(size: 14, weight: .medium))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(Palette.accent.opacity(0.10))
                    )
                    .foregroundStyle(Palette.accent)
                }
                .buttonStyle(.plain)
                .disabled(isProbing)

                Text("测速用巡检关键词逐个探测书源响应耗时，越快越优先；优质 = 可访问 + 速度快。")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
        }
    }

    private var sourceList: some View {
        VStack(alignment: .leading, spacing: 10) {
            if isLoading {
                ProgressView().frame(maxWidth: .infinity).padding(.vertical, 30)
            } else if sources.isEmpty {
                EmptyStateView(icon: "books.vertical", title: "没有书源", message: "请先在服务端导入书源。")
            } else {
                Card(padding: 0) {
                    VStack(spacing: 0) {
                        ForEach(sources) { source in
                            sourceRow(source)
                            if source.id != sources.last?.id {
                                Divider().padding(.leading, 44)
                            }
                        }
                    }
                }
            }
        }
    }

    private func stat(_ title: String, _ value: Int) -> some View {
        VStack(spacing: 2) {
            Text("\(value)")
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Text(title)
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - 单行

    private func sourceRow(_ source: SourceHealthSource) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .top, spacing: 10) {
                gradeIcon(source)
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(source.name)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(Palette.ink)
                            .lineLimit(1)
                        if grade(of: source) == .premium {
                            Label("优质", systemImage: "star.fill")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(Color(red: 0.82, green: 0.58, blue: 0.08))
                        }
                    }
                    Text(source.url)
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
                Spacer(minLength: 4)
                Toggle("", isOn: Binding(
                    get: { source.enabled ?? false },
                    set: { enabled in toggleEnabled(source, to: enabled) }
                ))
                .labelsHidden()
                .tint(Palette.accent)
                .scaleEffect(0.82)
                .disabled(source.isArchived)
            }

            HStack(spacing: 8) {
                gradeText(source)
                Spacer(minLength: 8)
                if source.isArchived {
                    Button("恢复") {
                        Task { await restore(source) }
                    }
                    .font(.caption.weight(.medium))
                    .buttonStyle(.plain)
                    .foregroundStyle(Palette.accent)
                } else {
                    Button("测速") {
                        Task { await probeOne(source) }
                    }
                    .font(.caption.weight(.medium))
                    .buttonStyle(.plain)
                    .foregroundStyle(Palette.accent)

                    Button {
                        pendingDelete = source
                    } label: {
                        Image(systemName: "trash")
                            .font(.caption)
                            .foregroundStyle(Palette.accent)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }

    private func gradeIcon(_ source: SourceHealthSource) -> some View {
        Image(systemName: grade(of: source).icon)
            .font(.system(size: 17))
            .foregroundStyle(grade(of: source).color)
            .frame(width: 22, height: 22)
    }

    private func gradeText(_ source: SourceHealthSource) -> some View {
        HStack(spacing: 6) {
            Text(grade(of: source).label)
                .font(.caption)
                .foregroundStyle(grade(of: source).color)
            if let probe = speed[source.url], let ms = probe.milliseconds {
                Text(String(format: "%.0f ms", ms))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(Palette.secondaryInk)
            }
            if let failures = source.health?.consecutiveFailures, failures > 0, !source.isArchived {
                Text("连续失败 \(failures) 次")
                    .font(.caption2)
                    .foregroundStyle(Palette.secondaryInk)
            }
        }
    }

    // MARK: - 分级

    private enum SourceGrade {
        case premium, normal, slow, broken, archived

        var icon: String {
            switch self {
            case .premium: return "star.fill"
            case .normal: return "checkmark.circle.fill"
            case .slow: return "tortoise.fill"
            case .broken: return "xmark.circle.fill"
            case .archived: return "archivebox.fill"
            }
        }

        var label: String {
            switch self {
            case .premium: return "高速优质"
            case .normal: return "正常"
            case .slow: return "低速"
            case .broken: return "无效/超时"
            case .archived: return "已失效归档"
            }
        }

        var color: Color {
            switch self {
            case .premium: return Color(red: 0.82, green: 0.58, blue: 0.08)
            case .normal: return Color(red: 0.20, green: 0.55, blue: 0.32)
            case .slow: return Color(red: 0.82, green: 0.50, blue: 0.12)
            case .broken: return Palette.accent
            case .archived: return Palette.secondaryInk
            }
        }
    }

    private func grade(of source: SourceHealthSource) -> SourceGrade {
        if source.isArchived { return .archived }
        guard let probe = speed[source.url] else { return .normal }
        if probe.error != nil { return .broken }
        guard let ms = probe.milliseconds else { return .normal }
        return ms <= 1500 ? .premium : .slow
    }

    // MARK: - 行为

    private func load() async {
        isLoading = true
        errorMessage = nil
        do {
            async let health = session.api.sourceHealthStatus()
            async let sources = session.api.fullSources()
            status = try await health
            fullSources = try await sources
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func scan() async {
        isScanning = true
        errorMessage = nil
        scanProgress = nil
        do {
            var current = try await session.api.sourceHealthScan()
            status = current
            var waited = 0
            while current.running == true, waited < 90 {
                try await Task.sleep(nanoseconds: 1_500_000_000)
                current = try await session.api.sourceHealthStatus()
                status = current
                scanProgress = (current.checked ?? 0, current.total ?? 0)
                waited += 2
            }
            status = current
            fullSources = try? await session.api.fullSources()
            toastText = "巡检完成：\(current.checked ?? 0)/\(current.total ?? 0) 个书源已检查"
        } catch {
            errorMessage = error.localizedDescription
        }
        isScanning = false
        scanProgress = nil
    }

    private func probeAll() async {
        let targets = sources.filter { $0.enabled == true && !$0.isArchived }
        guard !targets.isEmpty else { return }
        isProbing = true
        errorMessage = nil
        speed = [:]
        for chunk in targets.chunked(into: 3) {
            await withTaskGroup(of: (String, Double?, String?).self) { group in
                for source in chunk {
                    group.addTask {
                        let result = await session.api.probeSource(url: source.url)
                        return (source.url, result.milliseconds, result.error)
                    }
                }
                for await (url, ms, err) in group {
                    speed[url] = SpeedProbe(milliseconds: ms, error: err)
                }
            }
        }
        isProbing = false
    }

    private func probeOne(_ source: SourceHealthSource) async {
        let result = await session.api.probeSource(url: source.url)
        speed[source.url] = SpeedProbe(milliseconds: result.milliseconds, error: result.error)
    }

    private func toggleEnabled(_ source: SourceHealthSource, to enabled: Bool) {
        Task {
            do {
                try await saveEnabled(source, enabled: enabled)
                toastText = enabled ? "已启用 \(source.name)" : "已停用 \(source.name)"
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func saveEnabled(_ source: SourceHealthSource, enabled: Bool) async throws {
        if var full = fullSources?.first(where: { $0.bookSourceUrl == source.url }) {
            full.enabled = enabled
            fullSources = try await session.api.saveSources([full])
        } else {
            let minimal = BookSource(bookSourceUrl: source.url, bookSourceName: source.name, enabled: enabled)
            fullSources = try await session.api.saveSources([minimal])
        }
        status = try? await session.api.sourceHealthStatus()
    }

    private func restore(_ source: SourceHealthSource) async {
        do {
            status = try await session.api.sourceHealthRestore(url: source.url)
            fullSources = try? await session.api.fullSources()
            toastText = "已恢复 \(source.name)"
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func confirmDelete() async {
        guard let source = pendingDelete else { return }
        pendingDelete = nil
        do {
            fullSources = try await session.api.deleteSources([source.url])
            status = try? await session.api.sourceHealthStatus()
            speed[source.url] = nil
            toastText = "已删除 \(source.name)"
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private static func timeText(_ epochMs: Double) -> String {
        let date = Date(timeIntervalSince1970: epochMs / 1000)
        let formatter = RelativeDateTimeFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.unitsStyle = .short
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

// MARK: - 辅助

private struct SpeedProbe {
    var milliseconds: Double?
    var error: String?
}

private extension Array {
    func chunked(into size: Int) -> [[Element]] {
        guard size > 0 else { return [self] }
        var result: [[Element]] = []
        var index = startIndex
        while index < endIndex {
            let end = Swift.min(index + size, endIndex)
            result.append(Array(self[index..<end]))
            index = end
        }
        return result
    }
}
