import SwiftUI

// MARK: - 书源管理
//
// 一页解决书源的全部维护：随机书目逐源检测、优质/劣质分流、
// 小说与漫画分组、导入、去重、启停、测速与删除。

struct SourceHealthView: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    @State private var fullSources: [BookSource] = []
    @State private var healthMap: [String: SourceHealthRecord] = [:]
    @State private var serverStatus: SourceHealthStatus?
    @State private var outcomes: [String: SourceProbeOutcome] = [:]
    /// 每个结果真正的产生时间，决定 24 小时缓存何时过期；不能靠「保存时刻」推算。
    @State private var outcomeTimes: [String: Double] = [:]
    @State private var filter: MediaFilter = .all
    @State private var probeKeyword = "斗破苍穹"
    @State private var isLoading = false
    @State private var isReadOnly = false

    @State private var isChecking = false
    /// 快速模式：只探活，不跑搜索验证。
    @State private var quickOnly = false
    @State private var checkDone = 0
    @State private var checkTotal = 0
    @State private var checkPhase = ""
    @State private var singleProbing: Set<String> = []

    @State private var isScanningServer = false
    @State private var errorMessage: String?
    @State private var toastText: String?
    @State private var pendingDelete: BookSource?
    @State private var showAdd = false
    @State private var showDedupe = false

    /// 各站点基本都收录的长篇，随机取一本作为检测样本。
    private static let probePool = [
        "斗破苍穹", "完美世界", "遮天", "凡人修仙传",
        "武动乾坤", "大主宰", "圣墟", "赘婿"
    ]

    private static let cacheKey = "liubai.sourceProbeCache"
    private static let cacheTTL: Double = 24 * 3600

    /// 检测结果缓存：24 小时内不重复测同一个书源。
    private struct ProbeCache: Codable {
        var savedAt: Double
        var milliseconds: Double?
        var error: String?
        var bookCount: Int
        var introLength: Int
    }

    // MARK: - 派生数据

    private var visibleSources: [BookSource] {
        switch filter {
        case .all: return fullSources
        case .text: return fullSources.filter { $0.mediaKind == .text }
        case .comic: return fullSources.filter { $0.mediaKind == .comic }
        }
    }

    private func isArchived(_ source: BookSource) -> Bool {
        healthMap[source.bookSourceUrl]?.archived ?? false
    }

    /// 优质：检测通过且响应快、简介长；可用：检测通过但不出众。
    /// 劣质：检测失败，或已被服务端归档。
    /// 其余为未检测。
    private var poorSources: [BookSource] {
        visibleSources.filter { source in
            guard let outcome = outcomes[source.bookSourceUrl] else {
                return isArchived(source)
            }
            return !outcome.isUsable || isArchived(source)
        }
    }

    /// 优质：响应够快、简介够长的那一档，按响应时间从快到慢排。
    private var topSources: [BookSource] {
        visibleSources
            .filter { outcomes[$0.bookSourceUrl]?.isPremium == true }
            .sorted {
                (outcomes[$0.bookSourceUrl]?.milliseconds ?? .infinity)
                    < (outcomes[$1.bookSourceUrl]?.milliseconds ?? .infinity)
            }
    }

    /// 可用：检测通过，但响应或简介不算突出。
    private var goodSources: [BookSource] {
        visibleSources.filter { source in
            guard let outcome = outcomes[source.bookSourceUrl] else { return false }
            return outcome.isUsable && !outcome.isPremium
        }
    }

    private func isTopSource(_ source: BookSource) -> Bool {
        outcomes[source.bookSourceUrl]?.isPremium == true
    }

    /// 「关闭劣质源」实际能关掉的个数：已归档的源不算。
    private var closablePoorCount: Int {
        poorSources.filter { $0.enabled && !isArchived($0) }.count
    }

    private var untestedSources: [BookSource] {
        visibleSources.filter { source in
            outcomes[source.bookSourceUrl] == nil && !isArchived(source)
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 14) {
                        if isReadOnly {
                            readonlyCard
                        }
                        checkCard
                        if let errorMessage {
                            ErrorBanner(message: errorMessage)
                        }
                        statsCard
                        filterBar
                        bulkBar
                        sections
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("书源管理")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    if !isReadOnly {
                        Menu {
                            Button {
                                showAdd = true
                            } label: {
                                Label("添加书源", systemImage: "plus.circle")
                            }
                            Button {
                                showDedupe = true
                            } label: {
                                Label("书源去重", systemImage: "square.on.square.dashed")
                            }
                            Divider()
                            Button {
                                Task { await scanOnServer() }
                            } label: {
                                Label("服务端失效巡检", systemImage: "stethoscope")
                            }
                            Button {
                                clearCache()
                            } label: {
                                Label("清空检测缓存", systemImage: "arrow.counterclockwise")
                            }
                        } label: {
                            Image(systemName: "ellipsis.circle")
                                .foregroundStyle(Palette.ink)
                        }
                    }
                }
            }
            .task { await load() }
            .toast($toastText)
            .sheet(isPresented: $showAdd) {
                AddSourceSheet { saved in
                    fullSources = saved
                    outcomes = [:]
                    toastText = "书源已导入，共 \(saved.count) 个"
                }
            }
            .sheet(isPresented: $showDedupe) {
                // 已归档的源不参与判重，否则它可能被当成「保留那条」，把正常的同名源关掉。
                DedupeSheet(sources: fullSources.filter { !isArchived($0) }) { removedURLs in
                    let removed = Set(removedURLs)
                    SourcePrefs.shared.set(false, for: removedURLs)
                    for index in fullSources.indices where removed.contains(fullSources[index].bookSourceUrl) {
                        fullSources[index].enabled = false
                    }
                    toastText = "已关闭 \(removedURLs.count) 个重复书源（本地生效，可随时开回来）"
                }
            }
            .confirmationDialog(
                "关闭书源",
                isPresented: Binding(
                    get: { pendingDelete != nil },
                    set: { if !$0 { pendingDelete = nil } }
                ),
                titleVisibility: .visible
            ) {
                Button("关闭「\(pendingDelete?.bookSourceName ?? "")」") {
                    confirmDelete()
                }
                Button("取消", role: .cancel) { pendingDelete = nil }
            } message: {
                Text("关闭后搜索与换源都不再使用它，只影响这台手机，随时可以在列表里把开关打开恢复。")
            }
        }
    }

    // MARK: - 检测卡片

    private var readonlyCard: some View {
        Card {
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "lock.fill")
                    .font(.caption)
                    .foregroundStyle(Palette.accent)
                Text("当前账号只读：书源开关改在本机保存，搜索只按本地开关过滤；导入、删除、编辑规则仍需要管理员账号。")
                    .font(.caption)
                    .foregroundStyle(Palette.secondaryInk)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
        }
    }

    private var checkCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 6) {
                    Label("书源检测", systemImage: "checkmark.shield")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    if isChecking {
                        ProgressView().scaleEffect(0.8)
                    } else {
                        Button {
                            Task { await startCheck() }
                        } label: {
                            Text("开始检测")
                                .font(.caption.weight(.medium))
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(Palette.accent)
                        .disabled(visibleSources.isEmpty)
                    }
                }

                HStack(spacing: 6) {
                    Image(systemName: "dice")
                        .font(.caption)
                        .foregroundStyle(Palette.accent)
                    Text("本次样本：\(probeKeyword)")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    Button("换一本") {
                        probeKeyword = Self.probePool.randomElement() ?? "斗破苍穹"
                    }
                    .font(.caption)
                    .buttonStyle(.plain)
                    .foregroundStyle(Palette.accent)
                }

                if isChecking {
                    ProgressView(
                        value: checkTotal > 0 ? Double(checkDone) / Double(checkTotal) : 0
                    )
                    .tint(Palette.accent)
                    Text("\(checkPhase) \(checkDone)/\(checkTotal)")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    Text("先探站点连通性，连不通直接判失联；再对连通的源搜索这本书，搜不到或简介字数过少判劣质，响应快且简介字数多的标为优质。结果缓存 24 小时。")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                        .fixedSize(horizontal: false, vertical: true)
                }

                HStack(spacing: 10) {
                    Text("优质 \(topSources.count) · 可用 \(goodSources.count) · 劣质 \(poorSources.count) · 未检测 \(untestedSources.count)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                    Spacer()
                    if isScanningServer {
                        ProgressView().scaleEffect(0.7)
                    }
                }
            }
        }
    }

    // MARK: - 概览与筛选

    private var statsCard: some View {
        Card {
            HStack {
                stat("总数", fullSources.count)
                stat("小说", fullSources.filter { $0.mediaKind == .text }.count)
                stat("漫画", fullSources.filter { $0.mediaKind == .comic }.count)
                stat("已启用", fullSources.filter { $0.enabled }.count)
            }
        }
    }

    private func stat(_ title: String, _ value: Int) -> some View {
        VStack(spacing: 2) {
            Text("\(value)")
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Text(title)
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
        }
        .frame(maxWidth: .infinity)
    }

    private var filterBar: some View {
        Picker("类型", selection: $filter) {
            ForEach(MediaFilter.allCases) { item in
                Text(item.title).tag(item)
            }
        }
        .pickerStyle(.segmented)
    }

    // MARK: - 分组全选

    private var bulkBar: some View {
        Card {
            VStack(spacing: 9) {
                HStack(spacing: 6) {
                    Text("\(filter.title)书源")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Text("\(visibleSources.count) 个")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                    Spacer()
                    Text("已启用 \(visibleSources.filter { $0.enabled }.count)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                }

                Toggle(isOn: $quickOnly) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("只探活（快）")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(Palette.ink)
                        Text("只发一次首页请求，不跑搜索验证，几十秒就能筛掉死站")
                            .font(.system(size: 10))
                            .foregroundStyle(Palette.secondaryInk)
                    }
                }
                .tint(Palette.accent)

                HStack(spacing: 10) {
                    bulkButton("全部启用", icon: "checkmark.circle", enabled: true)
                    bulkButton("全部停用", icon: "pause.circle", enabled: false)
                }

                Button {
                    disablePoorSources()
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "xmark.circle")
                        Text("关闭劣质源（\(closablePoorCount) 个）")
                            .font(.system(size: 13, weight: .medium))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background(
                        RoundedRectangle(cornerRadius: 9, style: .continuous)
                            .fill(Palette.accent.opacity(0.07))
                    )
                    .foregroundStyle(closablePoorCount == 0 ? Palette.secondaryInk : Palette.accent)
                }
                .buttonStyle(.plain)
                .disabled(closablePoorCount == 0)
            }
        }
    }

    private func bulkButton(_ title: String, icon: String, enabled: Bool) -> some View {
        Button {
            setAll(enabled)
        } label: {
            HStack(spacing: 6) {
                Image(systemName: icon)
                Text(title)
                    .font(.system(size: 13, weight: .medium))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 9)
            .background(
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(Palette.accent.opacity(enabled ? 0.13 : 0.07))
            )
            .foregroundStyle(Palette.accent)
        }
        .buttonStyle(.plain)
        .disabled(isChecking || isLoading)
    }

    /// 把当前筛选类型下的书源一键启用 / 停用（写本地覆盖表，不需要管理员）。
    private func setAll(_ enabled: Bool) {
        let targets = visibleSources.filter { !isArchived($0) && $0.enabled != enabled }
        guard !targets.isEmpty else {
            toastText = "\(filter.title)书源已经是\(enabled ? "全部启用" : "全部停用")"
            return
        }
        let urls = targets.map { $0.bookSourceUrl }
        SourcePrefs.shared.set(enabled, for: urls)
        for url in urls {
            if let index = fullSources.firstIndex(where: { $0.bookSourceUrl == url }) {
                fullSources[index].enabled = enabled
            }
        }
        toastText = "\(filter.title)书源已\(enabled ? "全部启用" : "全部停用")（\(urls.count) 个，本地生效）"
    }

    // MARK: - 分组列表

    @ViewBuilder
    private var sections: some View {
        if isLoading {
            ProgressView().frame(maxWidth: .infinity).padding(.vertical, 30)
        } else if fullSources.isEmpty {
            EmptyStateView(
                icon: "books.vertical",
                title: "还没有书源",
                message: "点右上角菜单「添加书源」，粘贴 Legado 书源 JSON 即可导入。"
            )
        } else if visibleSources.isEmpty {
            EmptyStateView(
                icon: "tray",
                title: "这一类没有书源",
                message: "换个类型筛选看看，或添加对应书源。"
            )
        } else {
            section(
                title: "优质书源",
                subtitle: "响应 ≤1.5 秒、简介 ≥120 字",
                icon: "star.fill",
                tint: Color(red: 0.82, green: 0.58, blue: 0.08),
                sources: topSources
            )
            section(
                title: "可用书源",
                subtitle: "检测通过，响应或简介不算突出",
                icon: "checkmark.seal.fill",
                tint: Color(red: 0.20, green: 0.55, blue: 0.32),
                sources: goodSources
            )
            section(
                title: "劣质书源",
                subtitle: "报错、搜不到或字数不足，建议停用或删除",
                icon: "exclamationmark.triangle.fill",
                tint: Palette.accent,
                sources: poorSources
            )
            section(
                title: "未检测",
                subtitle: "点上方「开始检测」逐源判断质量",
                icon: "questionmark.circle",
                tint: Palette.secondaryInk,
                sources: untestedSources
            )
        }
    }

    /// 一键关闭「检测为劣质」的源：只写本地覆盖表，服务端一个字节都不动。
    private func disablePoorSources() {
        let urls = poorSources.filter { $0.enabled && !isArchived($0) }.map { $0.bookSourceUrl }
        guard !urls.isEmpty else {
            toastText = "当前筛选下没有已启用的劣质书源"
            return
        }
        SourcePrefs.shared.set(false, for: urls)
        for index in fullSources.indices where urls.contains(fullSources[index].bookSourceUrl) {
            fullSources[index].enabled = false
        }
        toastText = "已关闭 \(urls.count) 个劣质书源（本地生效，服务端没动）"
    }

    @ViewBuilder
    private func section(
        title: String,
        subtitle: String,
        icon: String,
        tint: Color,
        sources: [BookSource]
    ) -> some View {
        if !sources.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: icon)
                        .font(.caption)
                        .foregroundStyle(tint)
                    Text("\(title)（\(sources.count)）")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    Text(subtitle)
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                }
                .padding(.horizontal, 2)

                Card(padding: 0) {
                    VStack(spacing: 0) {
                        ForEach(sources) { source in
                            sourceRow(source)
                            if source.id != sources.last?.id {
                                Divider().padding(.leading, 14)
                            }
                        }
                    }
                }
            }
        }
    }

    private func sourceRow(_ source: BookSource) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: source.mediaKind.icon)
                    .font(.system(size: 15))
                    .foregroundStyle(source.mediaKind == .comic ? Palette.accent : Palette.secondaryInk)
                    .frame(width: 20, height: 20)

                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(source.bookSourceName)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(Palette.ink)
                            .lineLimit(1)

                        if isTopSource(source) {
                            Text("优质")
                                .font(.system(size: 9, weight: .semibold))
                                .foregroundStyle(Color(red: 0.70, green: 0.48, blue: 0.05))
                                .padding(.horizontal, 5)
                                .padding(.vertical, 1)
                                .background(Capsule().fill(Color(red: 0.82, green: 0.58, blue: 0.08).opacity(0.16)))
                        }

                        Text(source.mediaKind.title)
                            .font(.system(size: 9, weight: .medium))
                            .foregroundStyle(Palette.secondaryInk)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1)
                            .background(Capsule().fill(Palette.secondaryInk.opacity(0.10)))

                        if let group = source.bookSourceGroup, !group.isEmpty {
                            Text(group)
                                .font(.system(size: 9, weight: .medium))
                                .foregroundStyle(Palette.accent)
                                .padding(.horizontal, 5)
                                .padding(.vertical, 1)
                                .background(Capsule().fill(Palette.accent.opacity(0.10)))
                                .lineLimit(1)
                        }
                    }

                    Text(source.bookSourceUrl)
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Spacer(minLength: 4)

                if isArchived(source) {
                    Text(source.enabled ? "已启用" : "已停用")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(
                            source.enabled
                                ? Color(red: 0.20, green: 0.55, blue: 0.32)
                                : Palette.secondaryInk
                        )
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Capsule().fill(Palette.secondaryInk.opacity(0.10)))
                } else {
                    Toggle("", isOn: Binding(
                        get: { source.enabled },
                        set: { value in setEnabled(source, value) }
                    ))
                    .labelsHidden()
                    .tint(Palette.accent)
                    .scaleEffect(0.82)
                }
            }

            HStack(spacing: 8) {
                statusText(source)
                Spacer(minLength: 8)
                if isArchived(source) {
                    Text("已失效归档")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    Button {
                        Task { await probeOne(source) }
                    } label: {
                        if singleProbing.contains(source.bookSourceUrl) {
                            ProgressView().scaleEffect(0.7)
                        } else {
                            Text("检测")
                                .font(.caption.weight(.medium))
                                .foregroundStyle(Palette.accent)
                        }
                    }
                    .buttonStyle(.plain)

                    if !isReadOnly {
                        Button {
                            pendingDelete = source
                        } label: {
                            Image(systemName: "eye.slash")
                                .font(.caption)
                                .foregroundStyle(Palette.accent)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }

    @ViewBuilder
    private func statusText(_ source: BookSource) -> some View {
        if let outcome = outcomes[source.bookSourceUrl] {
            if let reason = outcome.failReason {
                Text(reason)
                    .font(.caption)
                    .foregroundStyle(Palette.accent)
                    .lineLimit(1)
                    .truncationMode(.middle)
            } else {
                HStack(spacing: 6) {
                    Text(outcome.isPremium ? "优质" : "可用")
                        .font(.caption)
                        .foregroundStyle(
                            outcome.isPremium
                                ? Color(red: 0.70, green: 0.48, blue: 0.05)
                                : Color(red: 0.20, green: 0.55, blue: 0.32)
                        )
                    if let ms = outcome.milliseconds {
                        Text(String(format: "%.0f ms", ms))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    Text("命中 \(outcome.bookCount)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                }
            }
        } else if let failures = healthMap[source.bookSourceUrl]?.consecutiveFailures, failures > 0 {
            Text("服务端连续失败 \(failures) 次")
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
        } else {
            Text("尚未检测")
                .font(.caption)
                .foregroundStyle(Palette.secondaryInk)
        }
    }

    // MARK: - 行为

    private func loadCache() -> [String: SourceProbeOutcome] {
        guard let data = UserDefaults.standard.data(forKey: Self.cacheKey),
              let stored = try? JSONDecoder().decode([String: ProbeCache].self, from: data) else {
            return [:]
        }
        let now = Date().timeIntervalSince1970
        var result: [String: SourceProbeOutcome] = [:]
        for (url, entry) in stored where now - entry.savedAt < Self.cacheTTL {
            result[url] = SourceProbeOutcome(
                milliseconds: entry.milliseconds,
                error: entry.error,
                bookCount: entry.bookCount,
                introLength: entry.introLength
            )
            outcomeTimes[url] = entry.savedAt
        }
        return result
    }

    private func saveCache() {
        let now = Date().timeIntervalSince1970
        var stored: [String: ProbeCache] = [:]
        for (url, outcome) in outcomes {
            // 用结果本身的产生时间，而不是这次保存的时间，否则每批保存都会把过期时间往后推。
            stored[url] = ProbeCache(
                savedAt: outcomeTimes[url] ?? now,
                milliseconds: outcome.milliseconds,
                error: outcome.error,
                bookCount: outcome.bookCount,
                introLength: outcome.introLength
            )
        }
        if let data = try? JSONEncoder().encode(stored) {
            UserDefaults.standard.set(data, forKey: Self.cacheKey)
        }
    }

    private func clearCache() {
        UserDefaults.standard.removeObject(forKey: Self.cacheKey)
        outcomes = [:]
        outcomeTimes = [:]
        toastText = "检测结果缓存已清空"
    }

    private func load() async {
        isLoading = true
        errorMessage = nil
        outcomes = loadCache()
        do {
            fullSources = try await session.api.fullSources()
            isReadOnly = false
        } catch {
            // 普通账号拿不到完整书源（含规则），退回摘要接口做只读展示。
            if let summary = try? await session.api.sources() {
                fullSources = summary.map { item in
                    BookSource(
                        bookSourceUrl: item.bookSourceUrl,
                        bookSourceName: item.bookSourceName,
                        bookSourceGroup: item.bookSourceGroup,
                        enabled: item.enabled ?? true,
                        bookSourceType: item.bookSourceType
                    )
                }
                isReadOnly = true
            } else {
                errorMessage = error.localizedDescription
            }
        }
        applyLocalOverrides()
        if let status = try? await session.api.sourceHealthStatus() {
            serverStatus = status
            var map: [String: SourceHealthRecord] = [:]
            for item in status.sources ?? [] {
                if let health = item.health { map[item.url] = health }
            }
            healthMap = map
        }
        isLoading = false
    }

    /// 把本地开关覆盖套回服务端读到的书源上。
    private func applyLocalOverrides() {
        for index in fullSources.indices {
            let url = fullSources[index].bookSourceUrl
            if let overlay = SourcePrefs.shared.overlay(for: url) {
                fullSources[index].enabled = overlay
            }
        }
    }

    private func startCheck() async {
        guard !isChecking else { return }

        // 只测没有近期结果的源，24 小时内的缓存直接沿用。
        let pending = visibleSources.filter { !isArchived($0) && outcomes[$0.bookSourceUrl] == nil }
        guard !pending.isEmpty else {
            toastText = "书源都有 24 小时内的检测结果，需重测请先清空缓存"
            return
        }

        probeKeyword = Self.probePool.randomElement() ?? "斗破苍穹"
        let keyword = probeKeyword
        isChecking = true
        errorMessage = nil

        // 阶段一：站点探活，连不通的直接判失联，不再浪费搜索
        checkPhase = "探活"
        checkDone = 0
        checkTotal = pending.count
        var alive: [BookSource] = []

        for chunk in pending.chunked(into: 40) {
            await withTaskGroup(of: (BookSource, Bool, Double?, String?).self) { group in
                for source in chunk {
                    group.addTask {
                        // 探活只是发个 GET，超时压到 3 秒，别让长尾站拖时间。
                        let result = await session.api.probeReachability(source.bookSourceUrl, timeout: 3)
                        return (source, result.ok, result.milliseconds, result.error)
                    }
                }
                for await (source, ok, ms, err) in group {
                    if ok {
                        alive.append(source)
                    } else {
                        outcomes[source.bookSourceUrl] = SourceProbeOutcome(
                            milliseconds: ms,
                            error: "站点失联：\(err ?? "无法连接")",
                            bookCount: 0,
                            introLength: 0
                        )
                        outcomeTimes[source.bookSourceUrl] = Date().timeIntervalSince1970
                    }
                    checkDone += 1
                }
            }
            // 每批落一次缓存，中途退出也不白跑。
            saveCache()
        }

        // 阶段二：只对连通的源跑一次搜索验证；快速模式跳过这步，只筛死站。
        if !alive.isEmpty, !quickOnly {
            checkPhase = "搜索"
            checkDone = 0
            checkTotal = alive.count
            for chunk in alive.chunked(into: 14) {
                await withTaskGroup(of: (String, SourceProbeOutcome).self) { group in
                    for source in chunk {
                        group.addTask {
                            let outcome = await session.api.probeSource(
                                url: source.bookSourceUrl,
                                keyword: keyword,
                                media: source.mediaKind.searchMedia
                            )
                            return (source.bookSourceUrl, outcome)
                        }
                    }
                    for await (url, outcome) in group {
                        outcomes[url] = outcome
                        outcomeTimes[url] = Date().timeIntervalSince1970
                        checkDone += 1
                    }
                }
                saveCache()
            }
        }

        isChecking = false
        checkPhase = ""
        saveCache()
        if quickOnly {
            toastText = "探活完成：连通 \(alive.count) 个，其余 \(pending.count - alive.count) 个判失联；连通的仍算未检测，跑完整检测才会分级"
        } else {
            let top = pending.filter { outcomes[$0.bookSourceUrl]?.isPremium == true }.count
            let usable = pending.filter { outcomes[$0.bookSourceUrl]?.isUsable == true }.count
            toastText = "检测完成：连通 \(alive.count) 个，优质 \(top) 个，可用 \(usable) 个，共 \(pending.count) 个"
        }
    }

    private func probeOne(_ source: BookSource) async {
        guard !singleProbing.contains(source.bookSourceUrl) else { return }
        singleProbing.insert(source.bookSourceUrl)
        let outcome = await session.api.probeSource(
            url: source.bookSourceUrl,
            keyword: probeKeyword,
            media: source.mediaKind.searchMedia
        )
        outcomes[source.bookSourceUrl] = outcome
        outcomeTimes[source.bookSourceUrl] = Date().timeIntervalSince1970
        saveCache()
        singleProbing.remove(source.bookSourceUrl)
    }

    /// 开关只写本地覆盖表，不需要管理员权限，也不会改动服务端书源。
    private func setEnabled(_ source: BookSource, _ value: Bool) {
        SourcePrefs.shared.set(value, for: [source.bookSourceUrl])
        if let index = fullSources.firstIndex(where: { $0.bookSourceUrl == source.bookSourceUrl }) {
            fullSources[index].enabled = value
        }
        toastText = value ? "已启用 \(source.bookSourceName)（本地）" : "已停用 \(source.bookSourceName)（本地）"
    }

    private func scanOnServer() async {
        isScanningServer = true
        errorMessage = nil
        do {
            var current = try await session.api.sourceHealthScan()
            serverStatus = current
            var waited = 0
            while current.running == true, waited < 90 {
                try await Task.sleep(nanoseconds: 1_500_000_000)
                current = try await session.api.sourceHealthStatus()
                serverStatus = current
                waited += 2
            }
            toastText = "服务端巡检完成：\(current.checked ?? 0)/\(current.total ?? 0) 个"
            await loadHealthOnly()
        } catch {
            errorMessage = error.localizedDescription
        }
        isScanningServer = false
    }

    private func loadHealthOnly() async {
        guard let status = try? await session.api.sourceHealthStatus() else { return }
        serverStatus = status
        var map: [String: SourceHealthRecord] = [:]
        for item in status.sources ?? [] {
            if let health = item.health { map[item.url] = health }
        }
        healthMap = map
    }

    private func confirmDelete() {
        guard let source = pendingDelete else { return }
        pendingDelete = nil
        // 普通账号没有超管权限，服务端删除必然 403；本地关掉开关即可达到同样效果：
        // 搜索不发请求、结果被过滤、换源也不会用它。服务端列表保持不变，随时能开回来。
        SourcePrefs.shared.set(false, for: [source.bookSourceUrl])
        if let index = fullSources.firstIndex(where: { $0.bookSourceUrl == source.bookSourceUrl }) {
            fullSources[index].enabled = false
        }
        toastText = "已关闭「\(source.bookSourceName)」（本地生效，可随时开回来）"
    }
}

// MARK: - 类型筛选

private enum MediaFilter: String, CaseIterable, Identifiable {
    case all, text, comic

    var id: String { rawValue }

    var title: String {
        switch self {
        case .all: return "全部"
        case .text: return "小说"
        case .comic: return "漫画"
        }
    }
}

// MARK: - 添加书源

private struct AddSourceSheet: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    var onSaved: ([BookSource]) -> Void

    @State private var text = ""
    @State private var isSaving = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                VStack(alignment: .leading, spacing: 12) {
                    Text("粘贴 Legado 书源 JSON")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Text("支持单个书源对象或 `[…]` 数组，规则字段会原样保存到服务端。")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)

                    TextEditor(text: $text)
                        .font(.system(size: 12, design: .monospaced))
                        .scrollContentBackground(.hidden)
                        .padding(8)
                        .frame(minHeight: 240)
                        .background(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(Color.white.opacity(0.75))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .stroke(Palette.secondaryInk.opacity(0.25), lineWidth: 1)
                        )

                    if let message {
                        Text(message)
                            .font(.caption)
                            .foregroundStyle(Palette.accent)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    Button {
                        Task { await save() }
                    } label: {
                        HStack(spacing: 8) {
                            if isSaving {
                                ProgressView().scaleEffect(0.8)
                            } else {
                                Image(systemName: "square.and.arrow.down")
                            }
                            Text(isSaving ? "正在导入…" : "导入书源")
                                .font(.system(size: 14, weight: .medium))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(Palette.accent.opacity(0.12))
                        )
                        .foregroundStyle(Palette.accent)
                    }
                    .buttonStyle(.plain)
                    .disabled(isSaving || text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    Spacer(minLength: 0)
                }
                .padding(20)
            }
            .navigationTitle("添加书源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }

    private func save() async {
        isSaving = true
        message = nil
        do {
            let parsed = try Self.parse(text)
            guard !parsed.isEmpty else {
                message = "没有解析到书源"
                isSaving = false
                return
            }
            let saved = try await session.api.saveSources(parsed)
            onSaved(saved)
            dismiss()
        } catch {
            message = error.localizedDescription
        }
        isSaving = false
    }

    /// 去掉代码块包裹后解析：先按数组，再按单个对象。
    static func parse(_ raw: String) throws -> [BookSource] {
        var cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleaned.hasPrefix("```") {
            cleaned = cleaned
                .replacingOccurrences(of: "```json", with: "")
                .replacingOccurrences(of: "```", with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        guard let data = cleaned.data(using: .utf8) else {
            throw ParseFailure("内容不是有效的 UTF-8 文本")
        }
        let decoder = JSONDecoder()
        if let list = try? decoder.decode([BookSource].self, from: data) {
            return list
        }
        if let single = try? decoder.decode(BookSource.self, from: data) {
            return [single]
        }
        throw ParseFailure("解析失败：请确认是 Legado 书源对象或数组，必须含 bookSourceUrl 与 bookSourceName")
    }

    struct ParseFailure: LocalizedError {
        var message: String
        init(_ message: String) { self.message = message }
        var errorDescription: String? { message }
    }
}

// MARK: - 书源去重

private struct DedupeSheet: View {
    @Environment(\.dismiss) private var dismiss

    var sources: [BookSource]
    var onRemoved: ([String]) -> Void

    private struct DuplicateGroup: Identifiable {
        var id: String
        var keep: BookSource
        var remove: [BookSource]
    }

    private var groups: [DuplicateGroup] {
        var byName: [String: [BookSource]] = [:]
        for source in sources {
            byName[Self.normalize(source.bookSourceName), default: []].append(source)
        }
        return byName.compactMap { key, list -> DuplicateGroup? in
            guard list.count > 1 else { return nil }
            let sorted = list.sorted { lhs, rhs in
                if lhs.enabled != rhs.enabled { return lhs.enabled }
                return lhs.bookSourceUrl.count < rhs.bookSourceUrl.count
            }
            return DuplicateGroup(id: key, keep: sorted[0], remove: Array(sorted.dropFirst()))
        }
        .sorted { $0.keep.bookSourceName < $1.keep.bookSourceName }
    }

    /// 还开着、需要关闭的重复源数量。
    private var closableCount: Int {
        groups.reduce(0) { $0 + $1.remove.filter { $0.enabled }.count }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 12) {
                        if groups.isEmpty {
                            EmptyStateView(
                                icon: "checkmark.seal",
                                title: "没有重复书源",
                                message: "同名书源只有一份，不需要清理。"
                            )
                        } else {
                            Card {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("按书源名称判重")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundStyle(Palette.ink)
                                    Text("同名书源保留一个：优先已启用，其次 URL 更短的。共 \(groups.count) 组，其中 \(closableCount) 个重复源还开着。关闭只影响这台手机：搜索不再请求它们、结果也会过滤掉，服务端列表不动，想恢复就把开关重新打开。")
                                        .font(.caption)
                                        .foregroundStyle(Palette.secondaryInk)
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                            }

                            ForEach(groups) { group in
                                Card(padding: 0) {
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack(spacing: 6) {
                                            Image(systemName: "square.on.square")
                                                .font(.caption)
                                                .foregroundStyle(Palette.accent)
                                            Text(group.keep.bookSourceName)
                                                .font(.system(size: 14, weight: .semibold))
                                                .foregroundStyle(Palette.ink)
                                            Spacer()
                                            Text("保留这条")
                                                .font(.caption2)
                                                .foregroundStyle(Color(red: 0.20, green: 0.55, blue: 0.32))
                                        }
                                        Text(group.keep.bookSourceUrl)
                                            .font(.system(size: 10))
                                            .foregroundStyle(Palette.secondaryInk)
                                            .lineLimit(1)
                                            .truncationMode(.middle)

                                        ForEach(group.remove) { item in
                                            HStack(spacing: 6) {
                                                Image(systemName: "minus.circle")
                                                    .font(.caption2)
                                                    .foregroundStyle(Palette.accent)
                                                Text(item.bookSourceUrl)
                                                    .font(.system(size: 10))
                                                    .foregroundStyle(Palette.secondaryInk)
                                                    .lineLimit(1)
                                                    .truncationMode(.middle)
                                            }
                                        }
                                    }
                                    .padding(14)
                                }
                            }

                            Button {
                                dedupe()
                            } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: "eye.slash")
                                    Text("关闭 \(closableCount) 个重复书源")
                                        .font(.system(size: 14, weight: .medium))
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 11)
                                .background(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .fill(Palette.accent.opacity(0.12))
                                )
                                .foregroundStyle(Palette.accent)
                            }
                            .buttonStyle(.plain)
                            .disabled(closableCount == 0)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("书源去重")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }

    private func dedupe() {
        // 不做服务端删除（普通账号会 403），只把多余的重复源写进本地开关表关掉。
        let urls = groups.flatMap { $0.remove.filter { $0.enabled }.map(\.bookSourceUrl) }
        guard !urls.isEmpty else { return }
        SourcePrefs.shared.set(false, for: urls)
        onRemoved(urls)
        dismiss()
    }

    /// 名称归一化：忽略空格、全角括号与大小写差异。
    static func normalize(_ name: String) -> String {
        name
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "　", with: "")
            .replacingOccurrences(of: "（", with: "(")
            .replacingOccurrences(of: "）", with: ")")
            .replacingOccurrences(of: "【", with: "[")
            .replacingOccurrences(of: "】", with: "]")
            .lowercased()
    }
}

// MARK: - 辅助

private extension Array {
    func chunked(into size: Int) -> [[Element]] {
        guard size > 0 else { return [self] }
        var result: [[Element]] = []
        var index = startIndex
        while index < endIndex {
            let end = Swift.min(index + size, endIndex)
            result.append(Array(self[index..<end]))
            index = end
        }
        return result
    }
}
