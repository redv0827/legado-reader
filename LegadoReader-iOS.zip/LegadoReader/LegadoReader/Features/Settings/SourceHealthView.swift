import SwiftUI

// MARK: - 书源管理
//
// 一页解决书源的全部维护：随机书目逐源检测、优质/劣质分流、
// 小说与漫画分组、导入、去重、启停、测速与删除。

struct SourceHealthView: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    @State private var fullSources: [BookSource] = []
    @State private var healthMap: [String: SourceHealthRecord] = [:]
    @State private var serverStatus: SourceHealthStatus?
    @State private var outcomes: [String: SourceProbeOutcome] = [:]
    @State private var filter: MediaFilter = .all
    @State private var probeKeyword = "斗破苍穹"
    @State private var isLoading = false

    @State private var isChecking = false
    @State private var checkDone = 0
    @State private var checkTotal = 0
    @State private var singleProbing: Set<String> = []

    @State private var isScanningServer = false
    @State private var errorMessage: String?
    @State private var toastText: String?
    @State private var pendingDelete: BookSource?
    @State private var showAdd = false
    @State private var showDedupe = false

    /// 各站点基本都收录的长篇，随机取一本作为检测样本。
    private static let probePool = [
        "斗破苍穹", "完美世界", "遮天", "凡人修仙传",
        "武动乾坤", "大主宰", "圣墟", "赘婿"
    ]

    // MARK: - 派生数据

    private var visibleSources: [BookSource] {
        switch filter {
        case .all: return fullSources
        case .text: return fullSources.filter { $0.mediaKind == .text }
        case .comic: return fullSources.filter { $0.mediaKind == .comic }
        }
    }

    private func isArchived(_ source: BookSource) -> Bool {
        healthMap[source.bookSourceUrl]?.archived ?? false
    }

    /// 优质：检测通过（有命中且简介字数够）。
    /// 劣质：检测失败，或已被服务端归档。
    /// 其余为未检测。
    private var premiumSources: [BookSource] {
        visibleSources.filter { outcomes[$0.bookSourceUrl]?.isUsable == true }
    }

    private var poorSources: [BookSource] {
        visibleSources.filter { source in
            guard let outcome = outcomes[source.bookSourceUrl] else {
                return isArchived(source)
            }
            return !outcome.isUsable || isArchived(source)
        }
    }

    private var untestedSources: [BookSource] {
        visibleSources.filter { source in
            outcomes[source.bookSourceUrl] == nil && !isArchived(source)
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 14) {
                        checkCard
                        if let errorMessage {
                            ErrorBanner(message: errorMessage)
                        }
                        statsCard
                        filterBar
                        sections
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("书源管理")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button {
                            showAdd = true
                        } label: {
                            Label("添加书源", systemImage: "plus.circle")
                        }
                        Button {
                            showDedupe = true
                        } label: {
                            Label("书源去重", systemImage: "square.on.square.dashed")
                        }
                        Divider()
                        Button {
                            Task { await scanOnServer() }
                        } label: {
                            Label("服务端失效巡检", systemImage: "stethoscope")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .foregroundStyle(Palette.ink)
                    }
                }
            }
            .task { await load() }
            .toast($toastText)
            .sheet(isPresented: $showAdd) {
                AddSourceSheet { saved in
                    fullSources = saved
                    outcomes = [:]
                    toastText = "书源已导入，共 \(saved.count) 个"
                }
            }
            .sheet(isPresented: $showDedupe) {
                DedupeSheet(sources: fullSources) { removedURLs in
                    let removed = Set(removedURLs)
                    fullSources.removeAll { removed.contains($0.bookSourceUrl) }
                    for url in removed {
                        outcomes[url] = nil
                        healthMap[url] = nil
                    }
                    toastText = "已清理 \(removedURLs.count) 个重复书源"
                }
            }
            .confirmationDialog(
                "删除书源",
                isPresented: Binding(
                    get: { pendingDelete != nil },
                    set: { if !$0 { pendingDelete = nil } }
                ),
                titleVisibility: .visible
            ) {
                Button("删除「\(pendingDelete?.bookSourceName ?? "")」", role: .destructive) {
                    Task { await confirmDelete() }
                }
                Button("取消", role: .cancel) { pendingDelete = nil }
            } message: {
                Text("删除后搜索与换源将不再使用该书源，且不可恢复。")
            }
        }
    }

    // MARK: - 检测卡片

    private var checkCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 6) {
                    Label("书源检测", systemImage: "checkmark.shield")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    if isChecking {
                        ProgressView().scaleEffect(0.8)
                    } else {
                        Button {
                            Task { await startCheck() }
                        } label: {
                            Text("开始检测")
                                .font(.caption.weight(.medium))
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(Palette.accent)
                        .disabled(visibleSources.isEmpty)
                    }
                }

                HStack(spacing: 6) {
                    Image(systemName: "dice")
                        .font(.caption)
                        .foregroundStyle(Palette.accent)
                    Text("本次样本：\(probeKeyword)")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    Button("换一本") {
                        probeKeyword = Self.probePool.randomElement() ?? "斗破苍穹"
                    }
                    .font(.caption)
                    .buttonStyle(.plain)
                    .foregroundStyle(Palette.accent)
                }

                if isChecking {
                    ProgressView(
                        value: checkTotal > 0 ? Double(checkDone) / Double(checkTotal) : 0
                    )
                    .tint(Palette.accent)
                    Text("正在检测 \(checkDone)/\(checkTotal) 个书源…")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    Text("逐个书源搜索这本书：报错、搜不到、或返回简介字数过少，直接判为劣质。")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                        .fixedSize(horizontal: false, vertical: true)
                }

                HStack(spacing: 10) {
                    Text("优质 \(premiumSources.count) · 劣质 \(poorSources.count) · 未检测 \(untestedSources.count)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                    Spacer()
                    if isScanningServer {
                        ProgressView().scaleEffect(0.7)
                    }
                }
            }
        }
    }

    // MARK: - 概览与筛选

    private var statsCard: some View {
        Card {
            HStack {
                stat("总数", fullSources.count)
                stat("小说", fullSources.filter { $0.mediaKind == .text }.count)
                stat("漫画", fullSources.filter { $0.mediaKind == .comic }.count)
                stat("已启用", fullSources.filter { $0.enabled }.count)
            }
        }
    }

    private func stat(_ title: String, _ value: Int) -> some View {
        VStack(spacing: 2) {
            Text("\(value)")
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Text(title)
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
        }
        .frame(maxWidth: .infinity)
    }

    private var filterBar: some View {
        Picker("类型", selection: $filter) {
            ForEach(MediaFilter.allCases) { item in
                Text(item.title).tag(item)
            }
        }
        .pickerStyle(.segmented)
    }

    // MARK: - 分组列表

    @ViewBuilder
    private var sections: some View {
        if isLoading {
            ProgressView().frame(maxWidth: .infinity).padding(.vertical, 30)
        } else if fullSources.isEmpty {
            EmptyStateView(
                icon: "books.vertical",
                title: "还没有书源",
                message: "点右上角菜单「添加书源」，粘贴 Legado 书源 JSON 即可导入。"
            )
        } else if visibleSources.isEmpty {
            EmptyStateView(
                icon: "tray",
                title: "这一类没有书源",
                message: "换个类型筛选看看，或添加对应书源。"
            )
        } else {
            section(
                title: "优质书源",
                subtitle: "检测通过，可直接用于搜索与换源",
                icon: "star.fill",
                tint: Color(red: 0.82, green: 0.58, blue: 0.08),
                sources: premiumSources
            )
            section(
                title: "劣质书源",
                subtitle: "报错、搜不到或字数不足，建议停用或删除",
                icon: "exclamationmark.triangle.fill",
                tint: Palette.accent,
                sources: poorSources
            )
            section(
                title: "未检测",
                subtitle: "点上方「开始检测」逐源判断质量",
                icon: "questionmark.circle",
                tint: Palette.secondaryInk,
                sources: untestedSources
            )
        }
    }

    @ViewBuilder
    private func section(
        title: String,
        subtitle: String,
        icon: String,
        tint: Color,
        sources: [BookSource]
    ) -> some View {
        if !sources.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: icon)
                        .font(.caption)
                        .foregroundStyle(tint)
                    Text("\(title)（\(sources.count)）")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    Text(subtitle)
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                }
                .padding(.horizontal, 2)

                Card(padding: 0) {
                    VStack(spacing: 0) {
                        ForEach(sources) { source in
                            sourceRow(source)
                            if source.id != sources.last?.id {
                                Divider().padding(.leading, 14)
                            }
                        }
                    }
                }
            }
        }
    }

    private func sourceRow(_ source: BookSource) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: source.mediaKind.icon)
                    .font(.system(size: 15))
                    .foregroundStyle(source.mediaKind == .comic ? Palette.accent : Palette.secondaryInk)
                    .frame(width: 20, height: 20)

                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(source.bookSourceName)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(Palette.ink)
                            .lineLimit(1)

                        Text(source.mediaKind.title)
                            .font(.system(size: 9, weight: .medium))
                            .foregroundStyle(Palette.secondaryInk)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1)
                            .background(Capsule().fill(Palette.secondaryInk.opacity(0.10)))

                        if let group = source.bookSourceGroup, !group.isEmpty {
                            Text(group)
                                .font(.system(size: 9, weight: .medium))
                                .foregroundStyle(Palette.accent)
                                .padding(.horizontal, 5)
                                .padding(.vertical, 1)
                                .background(Capsule().fill(Palette.accent.opacity(0.10)))
                                .lineLimit(1)
                        }
                    }

                    Text(source.bookSourceUrl)
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Spacer(minLength: 4)

                Toggle("", isOn: Binding(
                    get: { source.enabled },
                    set: { value in Task { await setEnabled(source, value) } }
                ))
                .labelsHidden()
                .tint(Palette.accent)
                .scaleEffect(0.82)
                .disabled(isArchived(source))
            }

            HStack(spacing: 8) {
                statusText(source)
                Spacer(minLength: 8)
                if isArchived(source) {
                    Text("已失效归档")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    Button {
                        Task { await probeOne(source) }
                    } label: {
                        if singleProbing.contains(source.bookSourceUrl) {
                            ProgressView().scaleEffect(0.7)
                        } else {
                            Text("检测")
                                .font(.caption.weight(.medium))
                                .foregroundStyle(Palette.accent)
                        }
                    }
                    .buttonStyle(.plain)

                    Button {
                        pendingDelete = source
                    } label: {
                        Image(systemName: "trash")
                            .font(.caption)
                            .foregroundStyle(Palette.accent)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }

    @ViewBuilder
    private func statusText(_ source: BookSource) -> some View {
        if let outcome = outcomes[source.bookSourceUrl] {
            if let reason = outcome.failReason {
                Text(reason)
                    .font(.caption)
                    .foregroundStyle(Palette.accent)
                    .lineLimit(1)
                    .truncationMode(.middle)
            } else {
                HStack(spacing: 6) {
                    Text("可用")
                        .font(.caption)
                        .foregroundStyle(Color(red: 0.20, green: 0.55, blue: 0.32))
                    if let ms = outcome.milliseconds {
                        Text(String(format: "%.0f ms", ms))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    Text("命中 \(outcome.bookCount)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                }
            }
        } else if let failures = healthMap[source.bookSourceUrl]?.consecutiveFailures, failures > 0 {
            Text("服务端连续失败 \(failures) 次")
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
        } else {
            Text("尚未检测")
                .font(.caption)
                .foregroundStyle(Palette.secondaryInk)
        }
    }

    // MARK: - 行为

    private func load() async {
        isLoading = true
        errorMessage = nil
        do {
            fullSources = try await session.api.fullSources()
        } catch {
            errorMessage = error.localizedDescription
        }
        if let status = try? await session.api.sourceHealthStatus() {
            serverStatus = status
            var map: [String: SourceHealthRecord] = [:]
            for item in status.sources ?? [] {
                if let health = item.health { map[item.url] = health }
            }
            healthMap = map
        }
        isLoading = false
    }

    private func startCheck() async {
        guard !isChecking else { return }
        let targets = visibleSources.filter { !isArchived($0) }
        guard !targets.isEmpty else { return }

        probeKeyword = Self.probePool.randomElement() ?? "斗破苍穹"
        let keyword = probeKeyword
        isChecking = true
        errorMessage = nil
        outcomes = [:]
        checkTotal = targets.count
        checkDone = 0

        for chunk in targets.chunked(into: 3) {
            await withTaskGroup(of: (String, SourceProbeOutcome).self) { group in
                for source in chunk {
                    group.addTask {
                        let outcome = await session.api.probeSource(
                            url: source.bookSourceUrl,
                            keyword: keyword,
                            media: source.mediaKind.searchMedia
                        )
                        return (source.bookSourceUrl, outcome)
                    }
                }
                for await (url, outcome) in group {
                    outcomes[url] = outcome
                    checkDone += 1
                }
            }
        }

        isChecking = false
        let premium = outcomes.values.filter { $0.isUsable }.count
        toastText = "检测完成：\(premium) 个可用，\(outcomes.count - premium) 个劣质"
    }

    private func probeOne(_ source: BookSource) async {
        guard !singleProbing.contains(source.bookSourceUrl) else { return }
        singleProbing.insert(source.bookSourceUrl)
        let outcome = await session.api.probeSource(
            url: source.bookSourceUrl,
            keyword: probeKeyword,
            media: source.mediaKind.searchMedia
        )
        outcomes[source.bookSourceUrl] = outcome
        singleProbing.remove(source.bookSourceUrl)
    }

    private func setEnabled(_ source: BookSource, _ value: Bool) async {
        var copy = source
        copy.enabled = value
        do {
            fullSources = try await session.api.saveSources([copy])
            toastText = value ? "已启用 \(source.bookSourceName)" : "已停用 \(source.bookSourceName)"
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func scanOnServer() async {
        isScanningServer = true
        errorMessage = nil
        do {
            var current = try await session.api.sourceHealthScan()
            serverStatus = current
            var waited = 0
            while current.running == true, waited < 90 {
                try await Task.sleep(nanoseconds: 1_500_000_000)
                current = try await session.api.sourceHealthStatus()
                serverStatus = current
                waited += 2
            }
            toastText = "服务端巡检完成：\(current.checked ?? 0)/\(current.total ?? 0) 个"
            await loadHealthOnly()
        } catch {
            errorMessage = error.localizedDescription
        }
        isScanningServer = false
    }

    private func loadHealthOnly() async {
        guard let status = try? await session.api.sourceHealthStatus() else { return }
        serverStatus = status
        var map: [String: SourceHealthRecord] = [:]
        for item in status.sources ?? [] {
            if let health = item.health { map[item.url] = health }
        }
        healthMap = map
    }

    private func confirmDelete() async {
        guard let source = pendingDelete else { return }
        pendingDelete = nil
        do {
            fullSources = try await session.api.deleteSources([source.bookSourceUrl])
            outcomes[source.bookSourceUrl] = nil
            healthMap[source.bookSourceUrl] = nil
            toastText = "已删除 \(source.bookSourceName)"
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - 类型筛选

private enum MediaFilter: String, CaseIterable, Identifiable {
    case all, text, comic

    var id: String { rawValue }

    var title: String {
        switch self {
        case .all: return "全部"
        case .text: return "小说"
        case .comic: return "漫画"
        }
    }
}

// MARK: - 添加书源

private struct AddSourceSheet: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    var onSaved: ([BookSource]) -> Void

    @State private var text = ""
    @State private var isSaving = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                VStack(alignment: .leading, spacing: 12) {
                    Text("粘贴 Legado 书源 JSON")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Text("支持单个书源对象或 `[…]` 数组，规则字段会原样保存到服务端。")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)

                    TextEditor(text: $text)
                        .font(.system(size: 12, design: .monospaced))
                        .scrollContentBackground(.hidden)
                        .padding(8)
                        .frame(minHeight: 240)
                        .background(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(Color.white.opacity(0.75))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .stroke(Palette.secondaryInk.opacity(0.25), lineWidth: 1)
                        )

                    if let message {
                        Text(message)
                            .font(.caption)
                            .foregroundStyle(Palette.accent)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    Button {
                        Task { await save() }
                    } label: {
                        HStack(spacing: 8) {
                            if isSaving {
                                ProgressView().scaleEffect(0.8)
                            } else {
                                Image(systemName: "square.and.arrow.down")
                            }
                            Text(isSaving ? "正在导入…" : "导入书源")
                                .font(.system(size: 14, weight: .medium))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(Palette.accent.opacity(0.12))
                        )
                        .foregroundStyle(Palette.accent)
                    }
                    .buttonStyle(.plain)
                    .disabled(isSaving || text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    Spacer(minLength: 0)
                }
                .padding(20)
            }
            .navigationTitle("添加书源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }

    private func save() async {
        isSaving = true
        message = nil
        do {
            let parsed = try Self.parse(text)
            guard !parsed.isEmpty else {
                message = "没有解析到书源"
                isSaving = false
                return
            }
            let saved = try await session.api.saveSources(parsed)
            onSaved(saved)
            dismiss()
        } catch {
            message = error.localizedDescription
        }
        isSaving = false
    }

    /// 去掉代码块包裹后解析：先按数组，再按单个对象。
    static func parse(_ raw: String) throws -> [BookSource] {
        var cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleaned.hasPrefix("```") {
            cleaned = cleaned
                .replacingOccurrences(of: "```json", with: "")
                .replacingOccurrences(of: "```", with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        guard let data = cleaned.data(using: .utf8) else {
            throw ParseFailure("内容不是有效的 UTF-8 文本")
        }
        let decoder = JSONDecoder()
        if let list = try? decoder.decode([BookSource].self, from: data) {
            return list
        }
        if let single = try? decoder.decode(BookSource.self, from: data) {
            return [single]
        }
        throw ParseFailure("解析失败：请确认是 Legado 书源对象或数组，必须含 bookSourceUrl 与 bookSourceName")
    }

    struct ParseFailure: LocalizedError {
        var message: String
        init(_ message: String) { self.message = message }
        var errorDescription: String? { message }
    }
}

// MARK: - 书源去重

private struct DedupeSheet: View {
    @EnvironmentObject private var session: AppSession
    @Environment(\.dismiss) private var dismiss

    var sources: [BookSource]
    var onRemoved: ([String]) -> Void

    @State private var isWorking = false
    @State private var message: String?

    private struct DuplicateGroup: Identifiable {
        var id: String
        var keep: BookSource
        var remove: [BookSource]
    }

    private var groups: [DuplicateGroup] {
        var byName: [String: [BookSource]] = [:]
        for source in sources {
            byName[Self.normalize(source.bookSourceName), default: []].append(source)
        }
        return byName.compactMap { key, list -> DuplicateGroup? in
            guard list.count > 1 else { return nil }
            let sorted = list.sorted { lhs, rhs in
                if lhs.enabled != rhs.enabled { return lhs.enabled }
                return lhs.bookSourceUrl.count < rhs.bookSourceUrl.count
            }
            return DuplicateGroup(id: key, keep: sorted[0], remove: Array(sorted.dropFirst()))
        }
        .sorted { $0.keep.bookSourceName < $1.keep.bookSourceName }
    }

    private var removableCount: Int {
        groups.reduce(0) { $0 + $1.remove.count }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                ScrollView {
                    VStack(spacing: 12) {
                        if groups.isEmpty {
                            EmptyStateView(
                                icon: "checkmark.seal",
                                title: "没有重复书源",
                                message: "同名书源只有一份，不需要清理。"
                            )
                        } else {
                            Card {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("按书源名称判重")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundStyle(Palette.ink)
                                    Text("同名书源保留一个：优先已启用，其次 URL 更短的。共 \(groups.count) 组，将删除 \(removableCount) 个。")
                                        .font(.caption)
                                        .foregroundStyle(Palette.secondaryInk)
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                            }

                            ForEach(groups) { group in
                                Card(padding: 0) {
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack(spacing: 6) {
                                            Image(systemName: "square.on.square")
                                                .font(.caption)
                                                .foregroundStyle(Palette.accent)
                                            Text(group.keep.bookSourceName)
                                                .font(.system(size: 14, weight: .semibold))
                                                .foregroundStyle(Palette.ink)
                                            Spacer()
                                            Text("保留这条")
                                                .font(.caption2)
                                                .foregroundStyle(Color(red: 0.20, green: 0.55, blue: 0.32))
                                        }
                                        Text(group.keep.bookSourceUrl)
                                            .font(.system(size: 10))
                                            .foregroundStyle(Palette.secondaryInk)
                                            .lineLimit(1)
                                            .truncationMode(.middle)

                                        ForEach(group.remove) { item in
                                            HStack(spacing: 6) {
                                                Image(systemName: "minus.circle")
                                                    .font(.caption2)
                                                    .foregroundStyle(Palette.accent)
                                                Text(item.bookSourceUrl)
                                                    .font(.system(size: 10))
                                                    .foregroundStyle(Palette.secondaryInk)
                                                    .lineLimit(1)
                                                    .truncationMode(.middle)
                                            }
                                        }
                                    }
                                    .padding(14)
                                }
                            }

                            if let message {
                                Text(message)
                                    .font(.caption)
                                    .foregroundStyle(Palette.accent)
                            }

                            Button {
                                Task { await dedupe() }
                            } label: {
                                HStack(spacing: 8) {
                                    if isWorking {
                                        ProgressView().scaleEffect(0.8)
                                    } else {
                                        Image(systemName: "trash")
                                    }
                                    Text(isWorking ? "正在清理…" : "删除 \(removableCount) 个重复书源")
                                        .font(.system(size: 14, weight: .medium))
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 11)
                                .background(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .fill(Palette.accent.opacity(0.12))
                                )
                                .foregroundStyle(Palette.accent)
                            }
                            .buttonStyle(.plain)
                            .disabled(isWorking)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("书源去重")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }

    private func dedupe() async {
        let urls = groups.flatMap { $0.remove.map(\.bookSourceUrl) }
        guard !urls.isEmpty else { return }
        isWorking = true
        message = nil
        do {
            _ = try await session.api.deleteSources(urls)
            onRemoved(urls)
            dismiss()
        } catch {
            message = error.localizedDescription
        }
        isWorking = false
    }

    /// 名称归一化：忽略空格、全角括号与大小写差异。
    static func normalize(_ name: String) -> String {
        name
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "　", with: "")
            .replacingOccurrences(of: "（", with: "(")
            .replacingOccurrences(of: "）", with: ")")
            .replacingOccurrences(of: "【", with: "[")
            .replacingOccurrences(of: "】", with: "]")
            .lowercased()
    }
}

// MARK: - 辅助

private extension Array {
    func chunked(into size: Int) -> [[Element]] {
        guard size > 0 else { return [self] }
        var result: [[Element]] = []
        var index = startIndex
        while index < endIndex {
            let end = Swift.min(index + size, endIndex)
            result.append(Array(self[index..<end]))
            index = end
        }
        return result
    }
}
