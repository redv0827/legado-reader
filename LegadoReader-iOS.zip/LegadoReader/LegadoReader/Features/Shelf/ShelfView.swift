import SwiftUI
import UIKit
import UniformTypeIdentifiers

extension Notification.Name {
    /// 书架里的书有增删时发一下，书架页收到就立刻重新拉一次，不必手动刷新。
    static let liubaiShelfChanged = Notification.Name("liubai.shelf.changed")
}

// MARK: - 封面

struct BookCoverView: View {
    let book: Book
    let coverURL: URL?

    private var shape: RoundedRectangle {
        RoundedRectangle(cornerRadius: 7, style: .continuous)
    }

    var body: some View {
        Color.clear
            .aspectRatio(3.0 / 4.0, contentMode: .fit)
            .overlay {
                ZStack {
                    LinearGradient(
                        colors: Palette.coverGradient(book.name),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    if let coverURL {
                        AsyncImage(url: coverURL, transaction: Transaction(animation: .easeIn(duration: 0.2))) { phase in
                            if case .success(let image) = phase {
                                image
                                    .resizable()
                                    .scaledToFill()
                            } else {
                                placeholder
                            }
                        }
                    } else {
                        placeholder
                    }
                }
            }
            .clipShape(shape)
            .overlay(shape.stroke(Color.black.opacity(0.10), lineWidth: 1))
            .shadow(color: Color.black.opacity(0.14), radius: 5, x: 0, y: 3)
    }

    private var placeholder: some View {
        VStack(spacing: 7) {
            Text(book.name)
                .font(.system(size: 12, weight: .semibold, design: .serif))
                .lineLimit(3)
                .multilineTextAlignment(.center)
            Rectangle()
                .fill(Color.white.opacity(0.55))
                .frame(width: 22, height: 1)
            Text(book.author.isEmpty ? "佚名" : book.author)
                .font(.system(size: 9))
                .lineLimit(1)
        }
        .foregroundStyle(Color.white.opacity(0.96))
        .padding(8)
        .shadow(color: .black.opacity(0.18), radius: 2, y: 1)
    }
}

// MARK: - 书架

struct ShelfView: View {
    @EnvironmentObject private var session: AppSession

    @State private var books: [Book] = []
    @State private var localBooks: [LocalBook] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var importError: String?
    @State private var sortMode: SortMode = .recent
    @State private var showOnlyReading = false
    @State private var layoutMode: ShelfLayout = .grid
    @State private var readingBook: Book?
    @State private var readingLocal: LocalBook?
    @State private var showImporter = false
    @State private var path = NavigationPath()

    // MARK: 多选管理
    /// 多选态：点书变勾选，底部出「置顶 / 取消置顶 / 删除」三条操作。
    @State private var isEditing = false
    @State private var selection: Set<String> = []
    @State private var isBulkWorking = false
    @State private var showDeleteConfirm = false
    @StateObject private var pins = ShelfPinsStore.shared
    @StateObject private var stats = ReadingStatsStore.shared
    @StateObject private var covers = CoverStore.shared
    @State private var isFillingCovers = false

    enum SortMode: String, CaseIterable, Identifiable {
        case recent = "最近阅读"
        case name = "书名"

        var id: String { rawValue }
    }

    enum ShelfLayout: String, CaseIterable, Identifiable {
        case grid = "网格"
        case list = "列表"

        var id: String { rawValue }
    }

    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16),
    ]

    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                PaperBackground()
                content
            }
            .navigationTitle("书架")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                if isEditing {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button(allSelected ? "取消全选" : "全选") {
                            toggleSelectAll()
                        }
                        .foregroundStyle(Palette.ink)
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("完成") { exitEditing() }
                            .fontWeight(.medium)
                            .foregroundStyle(Palette.ink)
                    }
                } else {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            beginEditing()
                        } label: {
                            Image(systemName: "checklist")
                                .foregroundStyle(Palette.ink)
                        }
                        .accessibilityLabel("多选管理")
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Menu {
                            Picker("排序", selection: $sortMode) {
                                ForEach(SortMode.allCases) { mode in
                                    Text(mode.rawValue).tag(mode)
                                }
                            }
                            Picker("视图", selection: $layoutMode) {
                                ForEach(ShelfLayout.allCases) { mode in
                                    Text(mode.rawValue).tag(mode)
                                }
                            }
                            Toggle("只看在读", isOn: $showOnlyReading)
                            Divider()
                            Button {
                                showImporter = true
                            } label: {
                                Label("导入本地书籍", systemImage: "square.and.arrow.down")
                            }
                        } label: {
                            Image(systemName: "line.3.horizontal.decrease.circle")
                                .foregroundStyle(Palette.ink)
                        }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            Task { await load() }
                        } label: {
                            Image(systemName: "arrow.clockwise")
                                .foregroundStyle(Palette.ink)
                        }
                        .accessibilityLabel("刷新书架")
                    }
                }
            }
            .navigationDestination(for: Book.self) { book in
                BookDetailView(book: book)
            }
            .onAppear { Task { await load() } }
            .onReceive(NotificationCenter.default.publisher(for: .liubaiShelfChanged)) { _ in
                Task { await load() }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if isEditing { editBar }
            }
            .confirmationDialog(
                "确定删除选中的 \(selection.count) 本书？",
                isPresented: $showDeleteConfirm,
                titleVisibility: .visible
            ) {
                Button("删除", role: .destructive) {
                    Task { await deleteSelection() }
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("服务端书架的书会移出书架（阅读进度也一起删掉），本地导入的 TXT 会从手机里删除，不能恢复。")
            }
            .fileImporter(
                isPresented: $showImporter,
                allowedContentTypes: importContentTypes,
                allowsMultipleSelection: true
            ) { result in
                Task { await handleImport(result) }
            }
            .fullScreenCover(item: $readingBook) { book in
                ReaderView(book: book, api: session.api)
            }
            .fullScreenCover(item: $readingLocal) { local in
                ReaderView(localBook: local, api: session.api)
                    .onDisappear { localBooks = LocalBookStore.shared.all() }
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if isLoading && books.isEmpty && localBooks.isEmpty {
            ProgressView("正在加载书架…")
                .tint(Palette.accent)
                .foregroundStyle(Palette.secondaryInk)
        } else if books.isEmpty && localBooks.isEmpty {
            ScrollView {
                VStack(spacing: 16) {
                    EmptyStateView(
                        icon: "books.vertical",
                        title: "书架还是空的",
                        message: "去「找书」搜索一本，或者从「文件」导入本地的 TXT 小说。"
                    )
                    Button {
                        showImporter = true
                    } label: {
                        Label("导入本地书籍", systemImage: "square.and.arrow.down")
                            .font(.system(size: 15, weight: .medium))
                            .foregroundStyle(Palette.ink)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(Color.white.opacity(0.85))
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .stroke(Palette.hairline, lineWidth: 1)
                            )
                    }
                    .buttonStyle(.plain)
                    if let errorMessage {
                        ErrorBanner(message: errorMessage).padding(.horizontal, 20)
                    }
                    if let importError {
                        ErrorBanner(message: importError).padding(.horizontal, 20)
                    }
                    Text("支持 TXT / MD 纯文本，自动按章节切分")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk.opacity(0.75))
                }
            }
            .refreshable { await load() }
        } else {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let errorMessage {
                        ErrorBanner(message: errorMessage)
                    }
                    if let importError {
                        ErrorBanner(message: importError)
                    }
                    if !localBooks.isEmpty {
                        sectionHeader("本地书籍", detail: "\(localBooks.count) 本")
                        LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                            ForEach(sortedLocalBooks) { local in
                                localCell(local)
                            }
                        }
                    }
                    if !books.isEmpty && !localBooks.isEmpty {
                        sectionHeader("服务端书架", detail: "\(books.count) 本")
                    }
                    if layoutMode == .list {
                        VStack(spacing: 8) {
                            ForEach(sortedBooks) { book in
                                shelfCell(book)
                            }
                        }
                    } else {
                        LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                            ForEach(sortedBooks) { book in
                                shelfCell(book)
                            }
                        }
                    }
                    Text("共 \(books.count + localBooks.count) 本 · 长按任意一本进入多选")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk.opacity(0.7))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 8)
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
            }
            .refreshable { await load() }
        }
    }

    // MARK: - 数据

    private var sortedBooks: [Book] {
        let filtered = showOnlyReading
            ? books.filter { ($0.durChapterIndex ?? 0) > 0 || ($0.lastReadTime ?? 0) > 0 }
            : books
        let base: [Book]
        switch sortMode {
        case .recent:
            base = filtered.sorted { ($0.lastReadTime ?? $0.addedAt ?? 0) > ($1.lastReadTime ?? $1.addedAt ?? 0) }
        case .name:
            base = filtered.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        }
        // 置顶的排最前，多个置顶之间按置顶时间从新到旧。
        let pinned = base
            .filter { pins.isPinned(ShelfPinsStore.key(bookURL: $0.bookUrl)) }
            .sorted { pins.pinnedAt(ShelfPinsStore.key(bookURL: $0.bookUrl)) > pins.pinnedAt(ShelfPinsStore.key(bookURL: $1.bookUrl)) }
        let rest = base.filter { !pins.isPinned(ShelfPinsStore.key(bookURL: $0.bookUrl)) }
        return pinned + rest
    }

    private var sortedLocalBooks: [LocalBook] {
        let pinned = localBooks
            .filter { pins.isPinned(ShelfPinsStore.key(localID: $0.id)) }
            .sorted { pins.pinnedAt(ShelfPinsStore.key(localID: $0.id)) > pins.pinnedAt(ShelfPinsStore.key(localID: $1.id)) }
        let rest = localBooks.filter { !pins.isPinned(ShelfPinsStore.key(localID: $0.id)) }
        return pinned + rest
    }

    private func coverURL(for book: Book) -> URL? {
        if let direct = session.api.resolve(book.coverUrl) { return direct }
        return session.api.resolve(covers.cover(for: book.bookUrl))
    }

    // MARK: - 多选管理

    private var editBar: some View {
        VStack(spacing: 0) {
            Divider().overlay(Palette.hairline)
            HStack(spacing: 8) {
                Text(selection.isEmpty ? "点书勾选" : "已选 \(selection.count) 本")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
                    .frame(maxWidth: .infinity, alignment: .leading)
                editAction(
                    selectionAllPinned ? "取消置顶" : "置顶",
                    systemImage: selectionAllPinned ? "pin.slash" : "pin.fill",
                    enabled: !selection.isEmpty
                ) {
                    pinSelection(!selectionAllPinned)
                }
                editAction("详情", systemImage: "info.circle", enabled: soleSelectedBook != nil) {
                    if let book = soleSelectedBook {
                        path.append(book)
                    }
                    exitEditing()
                }
                editAction("删除", systemImage: "trash", tint: Color(red: 0.72, green: 0.22, blue: 0.18), enabled: !selection.isEmpty) {
                    showDeleteConfirm = true
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
        }
        .background(.ultraThinMaterial)
    }

    private func editAction(
        _ title: String,
        systemImage: String,
        tint: Color = Palette.ink,
        enabled: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Label(title, systemImage: systemImage)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(enabled ? tint : Palette.secondaryInk.opacity(0.4))
                .padding(.horizontal, 9)
                .padding(.vertical, 7)
                .background(
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .fill(Color.white.opacity(0.82))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .stroke(Palette.hairline, lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .disabled(!enabled || isBulkWorking)
    }

    private var allKeys: [String] {
        sortedBooks.map { ShelfPinsStore.key(bookURL: $0.bookUrl) }
            + sortedLocalBooks.map { ShelfPinsStore.key(localID: $0.id) }
    }

    private var allSelected: Bool {
        !allKeys.isEmpty && allKeys.allSatisfy { selection.contains($0) }
    }

    private var selectionAllPinned: Bool {
        !selection.isEmpty && selection.allSatisfy { pins.isPinned($0) }
    }

    /// 只选了一本服务端书时才允许跳详情；本地 TXT 没有详情页。
    private var soleSelectedBook: Book? {
        guard selection.count == 1, let key = selection.first, !key.hasPrefix("local:") else { return nil }
        return books.first { ShelfPinsStore.key(bookURL: $0.bookUrl) == key }
    }

    private func beginEditing() {
        withAnimation(.easeOut(duration: 0.18)) {
            isEditing = true
            selection = []
        }
    }

    private func exitEditing() {
        withAnimation(.easeOut(duration: 0.18)) {
            isEditing = false
            selection = []
        }
    }

    private func toggleSelectAll() {
        if allSelected {
            selection = []
        } else {
            selection = Set(allKeys)
        }
    }

    private func toggleSelection(_ key: String) {
        if selection.contains(key) {
            selection.remove(key)
        } else {
            selection.insert(key)
        }
    }

    private func pinSelection(_ pinned: Bool) {
        guard !selection.isEmpty else { return }
        if pinned {
            pins.pin(Array(selection))
        } else {
            pins.unpin(Array(selection))
        }
        exitEditing()
    }

    private func deleteSelection() async {
        let keys = selection
        guard !keys.isEmpty else { return }
        isBulkWorking = true
        let serverURLs = keys.filter { !$0.hasPrefix("local:") }
        let localIDs = keys.filter { $0.hasPrefix("local:") }.map { String($0.dropFirst("local:".count)) }
        for url in serverURLs {
            do {
                try await session.api.removeBook(bookUrl: url)
            } catch {
                // 单本失败不影响其他，最后统一 load() 会以服务端实际状态为准。
            }
        }
        for id in localIDs {
            if let book = localBooks.first(where: { $0.id == id }) {
                LocalBookStore.shared.remove(book)
            }
        }
        pins.forget(Array(keys))
        for key in keys {
            ReadingStatsStore.shared.reset(key)
        }
        for url in serverURLs {
            covers.forget(url)
        }
        isBulkWorking = false
        exitEditing()
        await load()
        NotificationCenter.default.post(name: .liubaiShelfChanged, object: nil)
    }

    // MARK: - 书架单元

    @ViewBuilder
    private func shelfCell(_ book: Book) -> some View {
        let key = ShelfPinsStore.key(bookURL: book.bookUrl)
        let pinned = pins.isPinned(key)
        let selected = selection.contains(key)
        Group {
            if layoutMode == .list {
                ShelfListRow(
                    book: book,
                    coverURL: coverURL(for: book),
                    isPinned: pinned,
                    readSeconds: stats.seconds(for: key)
                )
            } else {
                BookGridCell(
                    book: book,
                    coverURL: coverURL(for: book),
                    isPinned: pinned,
                    readSeconds: stats.seconds(for: key)
                )
            }
        }
        .overlay(alignment: .topLeading) {
            if isEditing {
                SelectionBadge(isOn: selected)
                    .padding(6)
            }
        }
        .opacity(isEditing && !selected ? 0.7 : 1)
        .contentShape(Rectangle())
        .onTapGesture {
            if isEditing {
                toggleSelection(key)
            } else {
                // 书架点书直接进正文，不再绕详情页。
                readingBook = book
            }
        }
        .onLongPressGesture(minimumDuration: 0.45) {
            enterEditing(startingAt: key)
        }
    }

    @ViewBuilder
    private func localCell(_ local: LocalBook) -> some View {
        let key = ShelfPinsStore.key(localID: local.id)
        let pinned = pins.isPinned(key)
        let selected = selection.contains(key)
        LocalBookCell(book: local, isPinned: pinned, readSeconds: stats.seconds(for: key))
            .overlay(alignment: .topLeading) {
                if isEditing {
                    SelectionBadge(isOn: selected)
                        .padding(6)
                }
            }
            .opacity(isEditing && !selected ? 0.7 : 1)
            .contentShape(Rectangle())
            .onTapGesture {
                if isEditing {
                    toggleSelection(key)
                } else {
                    readingLocal = local
                }
            }
            .onLongPressGesture(minimumDuration: 0.45) {
                enterEditing(startingAt: key)
            }
    }

    /// 长按任意一本书：直接进多选态，并把这一本顺手勾上，省掉先点右上角那一步。
    private func enterEditing(startingAt key: String) {
        guard !isEditing else { return }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        withAnimation(.easeOut(duration: 0.18)) {
            isEditing = true
            selection = [key]
        }
    }

    private func togglePin(_ key: String) {
        if pins.isPinned(key) {
            pins.unpin([key])
        } else {
            pins.pin([key])
        }
    }

    private func sectionHeader(_ title: String, detail: String) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Spacer()
            Text(detail)
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
        }
    }

    // MARK: - 本地书导入

    private var importContentTypes: [UTType] {
        var types: [UTType] = [.plainText, .text]
        for ext in ["txt", "md", "markdown", "log"] {
            if let type = UTType(filenameExtension: ext), !types.contains(type) {
                types.append(type)
            }
        }
        return types
    }

    private func handleImport(_ result: Result<[URL], Error>) async {
        switch result {
        case .success(let urls):
            var failures: [String] = []
            for url in urls {
                if url.hasDirectoryPath { continue }
                do {
                    _ = try LocalBookStore.shared.importBook(from: url)
                } catch {
                    failures.append("\(url.lastPathComponent)：\(error.localizedDescription)")
                }
            }
            localBooks = LocalBookStore.shared.all()
            importError = failures.isEmpty ? nil : failures.joined(separator: "\n")
        case .failure(let error):
            importError = error.localizedDescription
        }
    }

    private func deleteLocal(_ book: LocalBook) {
        LocalBookStore.shared.remove(book)
        withAnimation {
            localBooks.removeAll { $0.id == book.id }
        }
    }

    private func load() async {
        localBooks = LocalBookStore.shared.all()
        do {
            let loaded = try await session.api.shelf()
            books = loaded
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
        Task { await fillMissingCovers() }
    }

    /// 服务端书架接口返回的书常缺封面图，缺的按 bookUrl 补抓一次，拿到就存本地缓存。
    @MainActor
    private func fillMissingCovers() async {
        guard !isFillingCovers else { return }
        isFillingCovers = true
        defer { isFillingCovers = false }
        let targets = books.filter { book in
            session.api.resolve(book.coverUrl) == nil && !covers.attempted(book.bookUrl)
        }
        for book in targets.prefix(20) {
            do {
                let result = try await session.api.bookDetails(book)
                covers.remember(result.book.coverUrl, for: book.bookUrl)
            } catch {
                // 网络抖动就不记，下次进书架再试。
            }
        }
    }

    private func delete(_ book: Book) async {
        do {
            try await session.api.removeBook(bookUrl: book.bookUrl)
            pins.forget([ShelfPinsStore.key(bookURL: book.bookUrl)])
            ReadingStatsStore.shared.reset(ShelfPinsStore.key(bookURL: book.bookUrl))
            covers.forget(book.bookUrl)
            withAnimation {
                books.removeAll { $0.bookUrl == book.bookUrl }
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - 本地书单元

struct LocalBookCell: View {
    let book: LocalBook
    var isPinned: Bool = false
    var readSeconds: Double = 0

    private var shape: RoundedRectangle {
        RoundedRectangle(cornerRadius: 7, style: .continuous)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack {
                LinearGradient(
                    colors: Palette.coverGradient(book.title),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                VStack(spacing: 7) {
                    Text(book.title)
                        .font(.system(size: 12, weight: .semibold, design: .serif))
                        .lineLimit(3)
                        .multilineTextAlignment(.center)
                    Rectangle()
                        .fill(Color.white.opacity(0.55))
                        .frame(width: 22, height: 1)
                    Text(book.lastReadText)
                        .font(.system(size: 9))
                }
                .foregroundStyle(Color.white.opacity(0.96))
                .padding(8)
            }
            .aspectRatio(3.0 / 4.0, contentMode: .fit)
            .clipShape(shape)
            .overlay(shape.stroke(Color.black.opacity(0.10), lineWidth: 1))
            .overlay(alignment: .topLeading) {
                Text("本地")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Capsule().fill(Color.black.opacity(0.32)))
                    .padding(6)
            }
            .overlay(alignment: .topTrailing) {
                if isPinned {
                    PinBadge()
                        .padding(6)
                }
            }
            .shadow(color: Color.black.opacity(0.14), radius: 5, x: 0, y: 3)

            VStack(alignment: .leading, spacing: 2) {
                Text(book.title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(2)
                Text("\(book.chapterCount) 章 · \(book.lastReadText)")
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
                if let read = ReadingDuration.text(readSeconds) {
                    Text(read)
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.accent.opacity(0.85))
                        .lineLimit(1)
                }
            }
        }
    }
}

// MARK: - 列表单元

/// 书架列表视图：一行一本，封面、书名作者、进度和正在读的章节名都能看到。
struct ShelfListRow: View {
    let book: Book
    let coverURL: URL?
    var isPinned: Bool = false
    var readSeconds: Double = 0

    var body: some View {
        HStack(spacing: 12) {
            BookCoverView(book: book, coverURL: coverURL)
                .frame(width: 46)
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 4) {
                    if isPinned {
                        Image(systemName: "pin.fill")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(Palette.accent)
                    }
                    Text(book.name)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                }
                Text(book.author.isEmpty ? "佚名" : book.author)
                    .font(.caption)
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
                HStack(spacing: 5) {
                    if let total = book.totalChapterNum, total > 0 {
                        Text("第 \((book.durChapterIndex ?? 0) + 1)/\(total) 章")
                    } else {
                        Text("未开始")
                    }
                    if let title = book.durChapterTitle, !title.isEmpty {
                        Text("· \(title)")
                            .lineLimit(1)
                    }
                }
                .font(.system(size: 10))
                .foregroundStyle(Palette.secondaryInk.opacity(0.85))
                if let read = ReadingDuration.text(readSeconds) {
                    Text(read)
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.accent.opacity(0.85))
                }
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Palette.secondaryInk.opacity(0.5))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color.white.opacity(0.72))
        )
    }
}

// MARK: - 网格单元

struct BookGridCell: View {
    let book: Book
    let coverURL: URL?
    var isPinned: Bool = false
    var readSeconds: Double = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            BookCoverView(book: book, coverURL: coverURL)
                .overlay(alignment: .topTrailing) {
                    if isPinned {
                        PinBadge()
                            .padding(6)
                    }
                }
                .overlay(alignment: .bottomTrailing) {
                    if book.progressFraction > 0 {
                        Text(book.progressFraction >= 0.999 ? "已读完" : "\(Int(book.progressFraction * 100))%")
                            .font(.system(size: 9, weight: .semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.black.opacity(0.35)))
                            .padding(6)
                    }
                }
            VStack(alignment: .leading, spacing: 2) {
                Text(book.name)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(2)
                Text(book.author.isEmpty ? "佚名" : book.author)
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
                if let read = ReadingDuration.text(readSeconds) {
                    Text(read)
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.accent.opacity(0.85))
                        .lineLimit(1)
                }
            }
        }
    }
}

// MARK: - 多选与置顶角标

/// 多选模式下压在封面左上角的勾选圈。
struct SelectionBadge: View {
    let isOn: Bool

    var body: some View {
        ZStack {
            Circle()
                .fill(isOn ? Palette.accent : Color.black.opacity(0.3))
            Circle()
                .stroke(Color.white.opacity(0.85), lineWidth: 1)
            if isOn {
                Image(systemName: "checkmark")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.white)
            }
        }
        .frame(width: 20, height: 20)
        .shadow(color: Color.black.opacity(0.12), radius: 2)
        .accessibilityLabel(isOn ? "已选中" : "未选中")
    }
}

/// 置顶角标：封面右上角一枚小图钉。
struct PinBadge: View {
    var body: some View {
        Image(systemName: "pin.fill")
            .font(.system(size: 9, weight: .bold))
            .foregroundStyle(Color.white)
            .frame(width: 19, height: 19)
            .background(
                Circle().fill(Palette.accent.opacity(0.92))
            )
            .shadow(color: Color.black.opacity(0.12), radius: 2)
            .accessibilityLabel("已置顶")
    }
}
