import SwiftUI

// MARK: - 封面

struct BookCoverView: View {
    let book: Book
    let coverURL: URL?

    private var shape: RoundedRectangle {
        RoundedRectangle(cornerRadius: 7, style: .continuous)
    }

    var body: some View {
        Color.clear
            .aspectRatio(3.0 / 4.0, contentMode: .fit)
            .overlay {
                ZStack {
                    LinearGradient(
                        colors: Palette.coverGradient(book.name),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    if let coverURL {
                        AsyncImage(url: coverURL, transaction: Transaction(animation: .easeIn(duration: 0.2))) { phase in
                            if case .success(let image) = phase {
                                image
                                    .resizable()
                                    .scaledToFill()
                            } else {
                                placeholder
                            }
                        }
                    } else {
                        placeholder
                    }
                }
            }
            .clipShape(shape)
            .overlay(shape.stroke(Color.black.opacity(0.10), lineWidth: 1))
            .shadow(color: Color.black.opacity(0.14), radius: 5, x: 0, y: 3)
    }

    private var placeholder: some View {
        VStack(spacing: 7) {
            Text(book.name)
                .font(.system(size: 12, weight: .semibold, design: .serif))
                .lineLimit(3)
                .multilineTextAlignment(.center)
            Rectangle()
                .fill(Color.white.opacity(0.55))
                .frame(width: 22, height: 1)
            Text(book.author.isEmpty ? "佚名" : book.author)
                .font(.system(size: 9))
                .lineLimit(1)
        }
        .foregroundStyle(Color.white.opacity(0.96))
        .padding(8)
        .shadow(color: .black.opacity(0.18), radius: 2, y: 1)
    }
}

// MARK: - 书架

struct ShelfView: View {
    @EnvironmentObject private var session: AppSession

    @State private var books: [Book] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var sortMode: SortMode = .recent
    @State private var showOnlyReading = false
    @State private var readingBook: Book?
    @State private var path = NavigationPath()

    enum SortMode: String, CaseIterable, Identifiable {
        case recent = "最近阅读"
        case name = "书名"

        var id: String { rawValue }
    }

    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16),
    ]

    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                PaperBackground()
                content
            }
            .navigationTitle("书架")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Picker("排序", selection: $sortMode) {
                            ForEach(SortMode.allCases) { mode in
                                Text(mode.rawValue).tag(mode)
                            }
                        }
                        Toggle("只看在读", isOn: $showOnlyReading)
                    } label: {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                            .foregroundStyle(Palette.ink)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        Task { await load() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .foregroundStyle(Palette.ink)
                    }
                    .accessibilityLabel("刷新书架")
                }
            }
            .navigationDestination(for: Book.self) { book in
                BookDetailView(book: book)
            }
            .task { await loadIfNeeded() }
            .fullScreenCover(item: $readingBook) { book in
                ReaderView(book: book, api: session.api)
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if isLoading && books.isEmpty {
            ProgressView("正在加载书架…")
                .tint(Palette.accent)
                .foregroundStyle(Palette.secondaryInk)
        } else if books.isEmpty {
            ScrollView {
                VStack(spacing: 16) {
                    EmptyStateView(
                        icon: "books.vertical",
                        title: "书架还是空的",
                        message: "去「找书」搜索一本，加入书架后就会出现在这里。\n书籍正文由你的留白服务端抓取。"
                    )
                    if let errorMessage {
                        ErrorBanner(message: errorMessage).padding(.horizontal, 20)
                    }
                }
            }
            .refreshable { await load() }
        } else {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let recent = recentBook {
                        ContinueReadingCard(book: recent, coverURL: coverURL(for: recent)) {
                            readingBook = recent
                        }
                    }
                    if let errorMessage {
                        ErrorBanner(message: errorMessage)
                    }
                    LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                        ForEach(sortedBooks) { book in
                            NavigationLink(value: book) {
                                BookGridCell(book: book, coverURL: coverURL(for: book))
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button {
                                    readingBook = book
                                } label: {
                                    Label("继续阅读", systemImage: "book")
                                }
                                Button(role: .destructive) {
                                    Task { await delete(book) }
                                } label: {
                                    Label("移出书架", systemImage: "trash")
                                }
                            }
                        }
                    }
                    Text("共 \(books.count) 本 · 右上角可刷新")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk.opacity(0.7))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 8)
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
            }
            .refreshable { await load() }
        }
    }

    // MARK: - 数据

    private var sortedBooks: [Book] {
        let filtered = showOnlyReading
            ? books.filter { ($0.durChapterIndex ?? 0) > 0 || ($0.lastReadTime ?? 0) > 0 }
            : books
        switch sortMode {
        case .recent:
            return filtered.sorted { ($0.lastReadTime ?? $0.addedAt ?? 0) > ($1.lastReadTime ?? $1.addedAt ?? 0) }
        case .name:
            return filtered.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        }
    }

    private var recentBook: Book? {
        books.filter { ($0.lastReadTime ?? 0) > 0 }.max { ($0.lastReadTime ?? 0) < ($1.lastReadTime ?? 0) }
    }

    private func coverURL(for book: Book) -> URL? {
        session.api.resolve(book.coverUrl)
    }

    private func loadIfNeeded() async {
        if books.isEmpty {
            await load()
        }
    }

    private func load() async {
        do {
            let loaded = try await session.api.shelf()
            books = loaded
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func delete(_ book: Book) async {
        do {
            try await session.api.removeBook(bookUrl: book.bookUrl)
            withAnimation {
                books.removeAll { $0.bookUrl == book.bookUrl }
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - 继续阅读

struct ContinueReadingCard: View {
    let book: Book
    let coverURL: URL?
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                BookCoverView(book: book, coverURL: coverURL)
                    .frame(width: 58)
                VStack(alignment: .leading, spacing: 6) {
                    Text("继续阅读")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(Palette.accent)
                    Text(book.name)
                        .font(.system(size: 17, weight: .semibold, design: .serif))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                    Text(book.durChapterTitle ?? "从头开始")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                    progressBar
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Palette.secondaryInk.opacity(0.7))
            }
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.82))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(Palette.hairline.opacity(0.7), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    private var progressBar: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(Palette.hairline.opacity(0.6))
                Capsule()
                    .fill(Palette.accent.opacity(0.75))
                    .frame(width: max(4, proxy.size.width * book.progressFraction))
            }
        }
        .frame(height: 4)
        .padding(.top, 2)
    }
}

// MARK: - 网格单元

struct BookGridCell: View {
    let book: Book
    let coverURL: URL?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            BookCoverView(book: book, coverURL: coverURL)
                .overlay(alignment: .bottomTrailing) {
                    if book.progressFraction > 0 {
                        Text("\(Int(book.progressFraction * 100))%")
                            .font(.system(size: 9, weight: .semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.black.opacity(0.35)))
                            .padding(6)
                    }
                }
            VStack(alignment: .leading, spacing: 2) {
                Text(book.name)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(2)
                Text(book.author.isEmpty ? "佚名" : book.author)
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
            }
        }
    }
}
