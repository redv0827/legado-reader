import SwiftUI
import UniformTypeIdentifiers

// MARK: - 封面

struct BookCoverView: View {
    let book: Book
    let coverURL: URL?

    private var shape: RoundedRectangle {
        RoundedRectangle(cornerRadius: 7, style: .continuous)
    }

    var body: some View {
        Color.clear
            .aspectRatio(3.0 / 4.0, contentMode: .fit)
            .overlay {
                ZStack {
                    LinearGradient(
                        colors: Palette.coverGradient(book.name),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    if let coverURL {
                        AsyncImage(url: coverURL, transaction: Transaction(animation: .easeIn(duration: 0.2))) { phase in
                            if case .success(let image) = phase {
                                image
                                    .resizable()
                                    .scaledToFill()
                            } else {
                                placeholder
                            }
                        }
                    } else {
                        placeholder
                    }
                }
            }
            .clipShape(shape)
            .overlay(shape.stroke(Color.black.opacity(0.10), lineWidth: 1))
            .shadow(color: Color.black.opacity(0.14), radius: 5, x: 0, y: 3)
    }

    private var placeholder: some View {
        VStack(spacing: 7) {
            Text(book.name)
                .font(.system(size: 12, weight: .semibold, design: .serif))
                .lineLimit(3)
                .multilineTextAlignment(.center)
            Rectangle()
                .fill(Color.white.opacity(0.55))
                .frame(width: 22, height: 1)
            Text(book.author.isEmpty ? "佚名" : book.author)
                .font(.system(size: 9))
                .lineLimit(1)
        }
        .foregroundStyle(Color.white.opacity(0.96))
        .padding(8)
        .shadow(color: .black.opacity(0.18), radius: 2, y: 1)
    }
}

// MARK: - 书架

struct ShelfView: View {
    @EnvironmentObject private var session: AppSession

    @State private var books: [Book] = []
    @State private var localBooks: [LocalBook] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var importError: String?
    @State private var sortMode: SortMode = .recent
    @State private var showOnlyReading = false
    @State private var layoutMode: ShelfLayout = .grid
    @State private var readingBook: Book?
    @State private var readingLocal: LocalBook?
    @State private var showImporter = false
    @State private var path = NavigationPath()

    enum SortMode: String, CaseIterable, Identifiable {
        case recent = "最近阅读"
        case name = "书名"

        var id: String { rawValue }
    }

    enum ShelfLayout: String, CaseIterable, Identifiable {
        case grid = "网格"
        case list = "列表"

        var id: String { rawValue }
    }

    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16),
    ]

    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                PaperBackground()
                content
            }
            .navigationTitle("书架")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showImporter = true
                    } label: {
                        Image(systemName: "square.and.arrow.down")
                            .foregroundStyle(Palette.ink)
                    }
                    .accessibilityLabel("导入本地书籍")
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Picker("排序", selection: $sortMode) {
                            ForEach(SortMode.allCases) { mode in
                                Text(mode.rawValue).tag(mode)
                            }
                        }
                        Picker("视图", selection: $layoutMode) {
                            ForEach(ShelfLayout.allCases) { mode in
                                Text(mode.rawValue).tag(mode)
                            }
                        }
                        Toggle("只看在读", isOn: $showOnlyReading)
                    } label: {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                            .foregroundStyle(Palette.ink)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        Task { await load() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .foregroundStyle(Palette.ink)
                    }
                    .accessibilityLabel("刷新书架")
                }
            }
            .navigationDestination(for: Book.self) { book in
                BookDetailView(book: book)
            }
            .task { await loadIfNeeded() }
            .fileImporter(
                isPresented: $showImporter,
                allowedContentTypes: importContentTypes,
                allowsMultipleSelection: true
            ) { result in
                Task { await handleImport(result) }
            }
            .fullScreenCover(item: $readingBook) { book in
                ReaderView(book: book, api: session.api)
            }
            .fullScreenCover(item: $readingLocal) { local in
                ReaderView(localBook: local, api: session.api)
                    .onDisappear { localBooks = LocalBookStore.shared.all() }
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if isLoading && books.isEmpty && localBooks.isEmpty {
            ProgressView("正在加载书架…")
                .tint(Palette.accent)
                .foregroundStyle(Palette.secondaryInk)
        } else if books.isEmpty && localBooks.isEmpty {
            ScrollView {
                VStack(spacing: 16) {
                    EmptyStateView(
                        icon: "books.vertical",
                        title: "书架还是空的",
                        message: "去「找书」搜索一本，或者从「文件」导入本地的 TXT 小说。"
                    )
                    Button {
                        showImporter = true
                    } label: {
                        Label("导入本地书籍", systemImage: "square.and.arrow.down")
                            .font(.system(size: 15, weight: .medium))
                            .foregroundStyle(Palette.ink)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(Color.white.opacity(0.85))
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .stroke(Palette.hairline, lineWidth: 1)
                            )
                    }
                    .buttonStyle(.plain)
                    if let errorMessage {
                        ErrorBanner(message: errorMessage).padding(.horizontal, 20)
                    }
                    if let importError {
                        ErrorBanner(message: importError).padding(.horizontal, 20)
                    }
                    Text("支持 TXT / MD 纯文本，自动按章节切分")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk.opacity(0.75))
                }
            }
            .refreshable { await load() }
        } else {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let recent = recentBook {
                        ContinueReadingCard(book: recent, coverURL: coverURL(for: recent)) {
                            readingBook = recent
                        }
                    }
                    if let errorMessage {
                        ErrorBanner(message: errorMessage)
                    }
                    if let importError {
                        ErrorBanner(message: importError)
                    }
                    if !localBooks.isEmpty {
                        sectionHeader("本地书籍", detail: "\(localBooks.count) 本")
                        LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                            ForEach(localBooks) { local in
                                Button {
                                    readingLocal = local
                                } label: {
                                    LocalBookCell(book: local)
                                }
                                .buttonStyle(.plain)
                                .contextMenu {
                                    Button {
                                        readingLocal = local
                                    } label: {
                                        Label("继续阅读", systemImage: "book")
                                    }
                                    Button(role: .destructive) {
                                        deleteLocal(local)
                                    } label: {
                                        Label("移除本地文件", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                    if !books.isEmpty && !localBooks.isEmpty {
                        sectionHeader("服务端书架", detail: "\(books.count) 本")
                    }
                    if layoutMode == .list {
                        VStack(spacing: 8) {
                            ForEach(sortedBooks) { book in
                                Button {
                                    readingBook = book
                                } label: {
                                    ShelfListRow(book: book, coverURL: coverURL(for: book))
                                }
                                .buttonStyle(.plain)
                                .contextMenu {
                                    Button {
                                        readingBook = book
                                    } label: {
                                        Label("继续阅读", systemImage: "book")
                                    }
                                    Button {
                                        path.append(book)
                                    } label: {
                                        Label("书籍详情", systemImage: "info.circle")
                                    }
                                    Button(role: .destructive) {
                                        Task { await delete(book) }
                                    } label: {
                                        Label("移出书架", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    } else {
                        LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                            ForEach(sortedBooks) { book in
                                Button {
                                    // 书架点书直接进正文，不再绕详情页。
                                    readingBook = book
                                } label: {
                                    BookGridCell(book: book, coverURL: coverURL(for: book))
                                }
                                .buttonStyle(.plain)
                                .contextMenu {
                                    Button {
                                        readingBook = book
                                    } label: {
                                        Label("继续阅读", systemImage: "book")
                                    }
                                    Button {
                                        path.append(book)
                                    } label: {
                                        Label("书籍详情", systemImage: "info.circle")
                                    }
                                    Button(role: .destructive) {
                                        Task { await delete(book) }
                                    } label: {
                                        Label("移出书架", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                    Text("共 \(books.count + localBooks.count) 本 · 右上角可刷新")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk.opacity(0.7))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 8)
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
            }
            .refreshable { await load() }
        }
    }

    // MARK: - 数据

    private var sortedBooks: [Book] {
        let filtered = showOnlyReading
            ? books.filter { ($0.durChapterIndex ?? 0) > 0 || ($0.lastReadTime ?? 0) > 0 }
            : books
        switch sortMode {
        case .recent:
            return filtered.sorted { ($0.lastReadTime ?? $0.addedAt ?? 0) > ($1.lastReadTime ?? $1.addedAt ?? 0) }
        case .name:
            return filtered.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        }
    }

    private var recentBook: Book? {
        books.filter { ($0.lastReadTime ?? 0) > 0 }.max { ($0.lastReadTime ?? 0) < ($1.lastReadTime ?? 0) }
    }

    private func coverURL(for book: Book) -> URL? {
        session.api.resolve(book.coverUrl)
    }

    private func sectionHeader(_ title: String, detail: String) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Spacer()
            Text(detail)
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
        }
    }

    // MARK: - 本地书导入

    private var importContentTypes: [UTType] {
        var types: [UTType] = [.plainText, .text]
        for ext in ["txt", "md", "markdown", "log"] {
            if let type = UTType(filenameExtension: ext), !types.contains(type) {
                types.append(type)
            }
        }
        return types
    }

    private func handleImport(_ result: Result<[URL], Error>) async {
        switch result {
        case .success(let urls):
            var failures: [String] = []
            for url in urls {
                if url.hasDirectoryPath { continue }
                do {
                    _ = try LocalBookStore.shared.importBook(from: url)
                } catch {
                    failures.append("\(url.lastPathComponent)：\(error.localizedDescription)")
                }
            }
            localBooks = LocalBookStore.shared.all()
            importError = failures.isEmpty ? nil : failures.joined(separator: "\n")
        case .failure(let error):
            importError = error.localizedDescription
        }
    }

    private func deleteLocal(_ book: LocalBook) {
        LocalBookStore.shared.remove(book)
        withAnimation {
            localBooks.removeAll { $0.id == book.id }
        }
    }

    private func loadIfNeeded() async {
        localBooks = LocalBookStore.shared.all()
        if books.isEmpty {
            await load()
        }
    }

    private func load() async {
        localBooks = LocalBookStore.shared.all()
        do {
            let loaded = try await session.api.shelf()
            books = loaded
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func delete(_ book: Book) async {
        do {
            try await session.api.removeBook(bookUrl: book.bookUrl)
            withAnimation {
                books.removeAll { $0.bookUrl == book.bookUrl }
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - 继续阅读

struct ContinueReadingCard: View {
    let book: Book
    let coverURL: URL?
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                BookCoverView(book: book, coverURL: coverURL)
                    .frame(width: 58)
                VStack(alignment: .leading, spacing: 6) {
                    Text("继续阅读")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(Palette.accent)
                    Text(book.name)
                        .font(.system(size: 17, weight: .semibold, design: .serif))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                    Text(book.durChapterTitle ?? "从头开始")
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                    progressBar
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Palette.secondaryInk.opacity(0.7))
            }
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.82))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(Palette.hairline.opacity(0.7), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    private var progressBar: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(Palette.hairline.opacity(0.6))
                Capsule()
                    .fill(Palette.accent.opacity(0.75))
                    .frame(width: max(4, proxy.size.width * book.progressFraction))
            }
        }
        .frame(height: 4)
        .padding(.top, 2)
    }
}

// MARK: - 本地书单元

struct LocalBookCell: View {
    let book: LocalBook

    private var shape: RoundedRectangle {
        RoundedRectangle(cornerRadius: 7, style: .continuous)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack {
                LinearGradient(
                    colors: Palette.coverGradient(book.title),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                VStack(spacing: 7) {
                    Text(book.title)
                        .font(.system(size: 12, weight: .semibold, design: .serif))
                        .lineLimit(3)
                        .multilineTextAlignment(.center)
                    Rectangle()
                        .fill(Color.white.opacity(0.55))
                        .frame(width: 22, height: 1)
                    Text(book.lastReadText)
                        .font(.system(size: 9))
                }
                .foregroundStyle(Color.white.opacity(0.96))
                .padding(8)
            }
            .aspectRatio(3.0 / 4.0, contentMode: .fit)
            .clipShape(shape)
            .overlay(shape.stroke(Color.black.opacity(0.10), lineWidth: 1))
            .overlay(alignment: .topLeading) {
                Text("本地")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Capsule().fill(Color.black.opacity(0.32)))
                    .padding(6)
            }
            .shadow(color: Color.black.opacity(0.14), radius: 5, x: 0, y: 3)

            VStack(alignment: .leading, spacing: 2) {
                Text(book.title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(2)
                Text("\(book.chapterCount) 章 · \(book.lastReadText)")
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
            }
        }
    }
}

// MARK: - 列表单元

/// 书架列表视图：一行一本，封面、书名作者、进度和正在读的章节名都能看到。
struct ShelfListRow: View {
    let book: Book
    let coverURL: URL?

    var body: some View {
        HStack(spacing: 12) {
            BookCoverView(book: book, coverURL: coverURL)
                .frame(width: 46)
            VStack(alignment: .leading, spacing: 3) {
                Text(book.name)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(1)
                Text(book.author.isEmpty ? "佚名" : book.author)
                    .font(.caption)
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
                HStack(spacing: 5) {
                    if let total = book.totalChapterNum, total > 0 {
                        Text("第 \((book.durChapterIndex ?? 0) + 1)/\(total) 章")
                    } else {
                        Text("未开始")
                    }
                    if let title = book.durChapterTitle, !title.isEmpty {
                        Text("· \(title)")
                            .lineLimit(1)
                    }
                }
                .font(.system(size: 10))
                .foregroundStyle(Palette.secondaryInk.opacity(0.85))
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Palette.secondaryInk.opacity(0.5))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color.white.opacity(0.72))
        )
    }
}

// MARK: - 网格单元

struct BookGridCell: View {
    let book: Book
    let coverURL: URL?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            BookCoverView(book: book, coverURL: coverURL)
                .overlay(alignment: .bottomTrailing) {
                    if book.progressFraction > 0 {
                        Text("\(Int(book.progressFraction * 100))%")
                            .font(.system(size: 9, weight: .semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.black.opacity(0.35)))
                            .padding(6)
                    }
                }
            VStack(alignment: .leading, spacing: 2) {
                Text(book.name)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(2)
                Text(book.author.isEmpty ? "佚名" : book.author)
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
            }
        }
    }
}
