import SwiftUI
import UIKit
import CoreText

// MARK: - 分页器

/// 用 CoreText 把整章文本按可视区域切成页，返回每页对应的字符范围。
final class TextPager {
    private(set) var ranges: [NSRange] = []
    let contentSize: CGSize

    init(attributed: NSAttributedString, size: CGSize) {
        contentSize = size
        guard size.width > 8, size.height > 8, attributed.length > 0 else { return }

        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)
        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        var start = 0
        while start < attributed.length {
            let frame = CTFramesetterCreateFrame(
                framesetter,
                CFRangeMake(start, attributed.length - start),
                path,
                nil
            )
            let visible = CTFrameGetVisibleStringRange(frame)
            guard visible.length > 0 else { break }
            ranges.append(NSRange(location: visible.location, length: visible.length))
            start = visible.location + visible.length
        }
        if ranges.isEmpty {
            ranges = [NSRange(location: 0, length: attributed.length)]
        }
    }

    var pageCount: Int { ranges.count }

    func pageIndex(for offset: Int) -> Int {
        guard !ranges.isEmpty else { return 0 }
        var low = 0
        var high = ranges.count - 1
        while low <= high {
            let mid = (low + high) / 2
            let range = ranges[mid]
            if offset < range.location {
                high = mid - 1
            } else if offset >= range.location + range.length {
                low = mid + 1
            } else {
                return mid
            }
        }
        return min(max(low, 0), ranges.count - 1)
    }

    func range(forPage index: Int) -> NSRange? {
        guard index >= 0, index < ranges.count else { return nil }
        return ranges[index]
    }
}

// MARK: - 翻页视图

/// 基于 CoreText 的整页渲染阅读视图：左右两侧点击或滑动翻页，中间点击呼出工具栏。
final class PagedTextView: UIView {
    var attributed: NSAttributedString = NSAttributedString()
    var renderID: UUID = UUID() {
        didSet { needsRebuild = true }
    }
    var pendingOffset: Int = 0 {
        didSet { needsRebuild = true }
    }

    var onOffsetChange: ((Int) -> Void)?
    var onPageChanged: ((Int, Int) -> Void)?
    var onNextChapter: (() -> Void)?
    var onPreviousChapter: (() -> Void)?
    var onToggleChrome: (() -> Void)?

    private let textInsets = UIEdgeInsets(top: 28, left: 22, bottom: 28, right: 22)
    private var pager = TextPager(attributed: NSAttributedString(), size: .zero)
    private var pageIndex = 0
    private var laidOutSize: CGSize = .zero
    private var needsRebuild = true

    override init(frame: CGRect) {
        super.init(frame: frame)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    private func installGestures() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        addGestureRecognizer(tap)

        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeLeft.direction = .left
        addGestureRecognizer(swipeLeft)

        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeRight.direction = .right
        addGestureRecognizer(swipeRight)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != laidOutSize {
            laidOutSize = bounds.size
            needsRebuild = true
        }
        if needsRebuild {
            rebuild()
        }
    }

    private func contentSize() -> CGSize {
        CGSize(
            width: max(1, bounds.width - textInsets.left - textInsets.right),
            height: max(1, bounds.height - textInsets.top - textInsets.bottom)
        )
    }

    private func rebuild() {
        needsRebuild = false
        let size = contentSize()
        let target = pendingOffset
        pager = TextPager(attributed: attributed, size: size)
        pageIndex = pager.pageIndex(for: target)
        setNeedsDisplay()
        report()
    }

    private func report() {
        guard let range = pager.range(forPage: pageIndex) else { return }
        onOffsetChange?(range.location)
        onPageChanged?(pageIndex + 1, pager.pageCount)
    }

    // MARK: 翻页

    func showNextPage() {
        if pageIndex + 1 < pager.pageCount {
            pageIndex += 1
            animatePageChange()
            report()
        } else {
            onNextChapter?()
        }
    }

    func showPreviousPage() {
        if pageIndex > 0 {
            pageIndex -= 1
            animatePageChange()
            report()
        } else {
            onPreviousChapter?()
        }
    }

    private func animatePageChange() {
        UIView.transition(
            with: self,
            duration: 0.16,
            options: [.transitionCrossDissolve, .allowUserInteraction]
        ) {
            self.setNeedsDisplay()
        }
    }

    // MARK: 手势

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        let point = gesture.location(in: self)
        let width = max(bounds.width, 1)
        if point.x < width * 0.3 {
            showPreviousPage()
        } else if point.x > width * 0.7 {
            showNextPage()
        } else {
            onToggleChrome?()
        }
    }

    @objc private func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        switch gesture.direction {
        case .left:
            showNextPage()
        case .right:
            showPreviousPage()
        default:
            break
        }
    }

    // MARK: 绘制

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext(),
              let range = pager.range(forPage: pageIndex) else { return }

        let size = pager.contentSize
        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)

        context.saveGState()
        context.textMatrix = .identity
        context.translateBy(x: textInsets.left, y: textInsets.top)
        context.translateBy(x: 0, y: size.height)
        context.scaleBy(x: 1, y: -1)

        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        let frame = CTFramesetterCreateFrame(
            framesetter,
            CFRangeMake(range.location, range.length),
            path,
            nil
        )
        CTFrameDraw(frame, context)
        context.restoreGState()
    }
}

// MARK: - SwiftUI 包装

struct PagedReaderView: UIViewRepresentable {
    let attributed: NSAttributedString?
    let renderID: UUID
    let restoreOffset: Int
    let backgroundColor: UIColor
    let onOffsetChange: (Int) -> Void
    let onPageChanged: (Int, Int) -> Void
    let onNextChapter: () -> Void
    let onPreviousChapter: () -> Void
    let onTap: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> PagedTextView {
        let view = PagedTextView()
        view.backgroundColor = backgroundColor
        view.attributed = attributed ?? NSAttributedString(string: "")
        view.renderID = renderID
        view.pendingOffset = restoreOffset
        bind(view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: PagedTextView, context: Context) {
        context.coordinator.parent = self
        view.backgroundColor = backgroundColor
        if view.renderID != renderID {
            view.attributed = attributed ?? NSAttributedString(string: "")
            view.pendingOffset = restoreOffset
            view.renderID = renderID
        }
        bind(view, coordinator: context.coordinator)
    }

    private func bind(_ view: PagedTextView, coordinator: Coordinator) {
        view.onOffsetChange = { [weak coordinator] value in coordinator?.parent.onOffsetChange(value) }
        view.onPageChanged = { [weak coordinator] page, total in
            coordinator?.parent.onPageChanged(page, total)
        }
        view.onNextChapter = { [weak coordinator] in coordinator?.parent.onNextChapter() }
        view.onPreviousChapter = { [weak coordinator] in coordinator?.parent.onPreviousChapter() }
        view.onToggleChrome = { [weak coordinator] in coordinator?.parent.onTap() }
    }

    final class Coordinator {
        var parent: PagedReaderView

        init(parent: PagedReaderView) {
            self.parent = parent
        }
    }
}
