import SwiftUI
import UIKit
import CoreText

// MARK: - 分页器

/// 用 CoreText 把整章文本按可视区域切成页，返回每页对应的字符范围。
final class TextPager {
    private(set) var ranges: [NSRange] = []
    let contentSize: CGSize

    init(attributed: NSAttributedString, size: CGSize) {
        contentSize = size
        guard size.width > 8, size.height > 8, attributed.length > 0 else { return }

        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)
        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        var start = 0
        while start < attributed.length {
            let frame = CTFramesetterCreateFrame(
                framesetter,
                CFRangeMake(start, attributed.length - start),
                path,
                nil
            )
            let visible = CTFrameGetVisibleStringRange(frame)
            guard visible.length > 0 else { break }
            ranges.append(NSRange(location: visible.location, length: visible.length))
            start = visible.location + visible.length
        }
        if ranges.isEmpty {
            ranges = [NSRange(location: 0, length: attributed.length)]
        }
    }

    var pageCount: Int { ranges.count }

    func pageIndex(for offset: Int) -> Int {
        guard !ranges.isEmpty else { return 0 }
        var low = 0
        var high = ranges.count - 1
        while low <= high {
            let mid = (low + high) / 2
            let range = ranges[mid]
            if offset < range.location {
                high = mid - 1
            } else if offset >= range.location + range.length {
                low = mid + 1
            } else {
                return mid
            }
        }
        return min(max(low, 0), ranges.count - 1)
    }

    func range(forPage index: Int) -> NSRange? {
        guard index >= 0, index < ranges.count else { return nil }
        return ranges[index]
    }
}

// MARK: - 整页仿真翻页

/// 一整页纸绕书脊（左边缘）做 3D 立体翻转：手指拖到哪，纸就转到哪。
/// 翻过 90° 之后看到的是纸背，上面透出淡淡的字迹。
final class PageFlipView: UIView {

    private let forward: Bool
    private let paperColor: UIColor

    private let underLayer = CALayer()
    private let spineShadow = CAGradientLayer()
    private let pageContainer = CALayer()
    private let frontLayer = CALayer()
    private let backLayer = CALayer()
    private let pageShade = CAGradientLayer()
    private let paperEdge = CALayer()

    private var progressValue: CGFloat = 0

    private var link: CADisplayLink?
    private var animFrom: CGFloat = 0
    private var animTo: CGFloat = 0
    private var animDuration: CFTimeInterval = 0
    private var animStart: CFTimeInterval = 0
    private var animCompletion: (() -> Void)?

    var currentProgress: CGFloat { progressValue }

    init(frame: CGRect, front: UIImage, under: UIImage, forward: Bool, paper: UIColor) {
        self.forward = forward
        self.paperColor = paper
        super.init(frame: frame)
        backgroundColor = paper
        clipsToBounds = true
        isUserInteractionEnabled = false
        build(front: front, under: under)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        link?.invalidate()
    }

    // MARK: 搭建

    private func build(front: UIImage, under: UIImage) {
        layer.backgroundColor = paperColor.cgColor

        // 底下不动的那一页，翻动页过去之后露出来的就是它
        underLayer.frame = bounds
        underLayer.contentsGravity = .resize
        underLayer.contentsScale = under.scale
        underLayer.contents = under.cgImage
        layer.addSublayer(underLayer)

        // 翻动页压在书脊附近投下的暗影
        spineShadow.frame = CGRect(
            x: 0,
            y: 0,
            width: max(60, bounds.width * 0.34),
            height: bounds.height
        )
        spineShadow.colors = [
            UIColor.black.withAlphaComponent(0.42).cgColor,
            UIColor.black.withAlphaComponent(0.12).cgColor,
            UIColor.clear.cgColor,
        ]
        spineShadow.locations = [0, 0.46, 1] as [NSNumber]
        spineShadow.startPoint = CGPoint(x: 0, y: 0.5)
        spineShadow.endPoint = CGPoint(x: 1, y: 0.5)
        spineShadow.opacity = 0
        layer.addSublayer(spineShadow)

        // 整页的容器，绕自己的左边缘旋转
        pageContainer.anchorPoint = CGPoint(x: 0, y: 0.5)
        pageContainer.bounds = CGRect(origin: .zero, size: bounds.size)
        pageContainer.position = CGPoint(x: 0, y: bounds.midY)
        pageContainer.masksToBounds = true
        pageContainer.isDoubleSided = false
        layer.addSublayer(pageContainer)

        frontLayer.frame = pageContainer.bounds
        frontLayer.contentsGravity = .resize
        frontLayer.contentsScale = front.scale
        frontLayer.contents = front.cgImage
        pageContainer.addSublayer(frontLayer)

        // 纸背：比正面略亮的纸，透出反向的淡字迹
        let back = Self.paperBack(from: front, size: bounds.size, paper: paperColor)
        backLayer.frame = pageContainer.bounds
        backLayer.contentsGravity = .resize
        backLayer.contentsScale = back.scale
        backLayer.contents = back.cgImage
        backLayer.opacity = 0
        pageContainer.addSublayer(backLayer)

        // 纸页自身的受光：靠书脊一侧暗，外侧亮
        pageShade.frame = pageContainer.bounds
        pageShade.colors = [
            UIColor.black.withAlphaComponent(0.30).cgColor,
            UIColor.black.withAlphaComponent(0.06).cgColor,
            UIColor.clear.cgColor,
        ]
        pageShade.locations = [0, 0.5, 1] as [NSNumber]
        pageShade.startPoint = CGPoint(x: 0, y: 0.5)
        pageShade.endPoint = CGPoint(x: 1, y: 0.5)
        pageShade.opacity = 0
        pageContainer.addSublayer(pageShade)

        // 纸张的侧边，让转到侧面时仍有一条纸边可看，而不是凭空消失
        paperEdge.frame = CGRect(x: bounds.width - 1.5, y: 0, width: 1.5, height: bounds.height)
        paperEdge.backgroundColor = paperColor.darker().cgColor
        pageContainer.addSublayer(paperEdge)

        applyProgress()
    }

    /// 纸背：一张比正面略亮的纸，透出字迹的反向影子。
    /// 容器旋转 180° 之后观看时这份内容会被镜像，正好还原成纸背该有的反向字。
    private static func paperBack(from front: UIImage, size: CGSize, paper: UIColor) -> UIImage {
        let format = UIGraphicsImageRendererFormat.preferred()
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: size, format: format)
        return renderer.image { ctx in
            let cg = ctx.cgContext
            paper.setFill()
            cg.fill(CGRect(origin: .zero, size: size))
            UIColor.white.withAlphaComponent(0.22).setFill()
            cg.fill(CGRect(origin: .zero, size: size))
            front.draw(
                in: CGRect(origin: .zero, size: size),
                blendMode: .normal,
                alpha: 0.13
            )
        }
    }

    // MARK: 进度

    func setProgress(_ value: CGFloat) {
        progressValue = min(1, max(0, value))
        applyProgress()
    }

    private func applyProgress() {
        let progress = progressValue
        // 往前翻：0° → -180°；往回翻：-180° → 0°
        let angle: CGFloat = forward
            ? -CGFloat.pi * progress
            : -CGFloat.pi * (1 - progress)

        var perspective = CATransform3DIdentity
        perspective.m34 = -1.0 / 1000.0
        pageContainer.transform = CATransform3DRotate(perspective, angle, 0, 1, 0)

        let facing = cos(angle)     // 1 正面朝读者，-1 完全是纸背
        let frontAlpha = min(1, max(0, (facing + 0.10) / 0.20))
        let backAlpha = min(1, max(0, (-facing + 0.10) / 0.20))
        frontLayer.opacity = Float(frontAlpha)
        backLayer.opacity = Float(backAlpha)

        // 页面侧过去的时候整体变暗，书脊一侧压得更暗
        let sideOn = sin(min(CGFloat.pi, abs(angle)))
        pageShade.opacity = Float(min(1, 0.26 + 0.34 * sideOn)) * Float(sideOn)

        spineShadow.opacity = Float(max(0, min(1, 0.52 * sin(CGFloat.pi * progress))))
    }

    // MARK: 收尾动画

    func animate(to target: CGFloat, duration seconds: CFTimeInterval, completion: (() -> Void)?) {
        link?.invalidate()
        link = nil
        animFrom = progressValue
        animTo = min(1, max(0, target))
        animDuration = max(0.10, seconds)
        animStart = CACurrentMediaTime()
        animCompletion = completion

        let display = CADisplayLink(target: self, selector: #selector(tick))
        display.add(to: .main, forMode: .common)
        link = display
    }

    @objc private func tick() {
        let t = min(1, (CACurrentMediaTime() - animStart) / animDuration)
        // 收尾用 easeOut：起步快、落页轻
        let eased = 1 - pow(1 - t, 3)
        setProgress(animFrom + (animTo - animFrom) * CGFloat(eased))
        if t >= 1 {
            link?.invalidate()
            link = nil
            let callback = animCompletion
            animCompletion = nil
            callback?()
        }
    }
}

// MARK: - 翻页视图

/// 基于 CoreText 的整页渲染阅读视图：左右拖动跟手翻页，轻点两侧翻页，中间点击呼出工具栏。
final class PagedTextView: UIView {
    var attributed: NSAttributedString = NSAttributedString() {
        didSet { requestRebuild() }
    }
    var renderID: UUID = UUID() {
        didSet { requestRebuild() }
    }
    var pendingOffset: Int = 0 {
        didSet { requestRebuild() }
    }

    var onOffsetChange: ((Int) -> Void)?
    var onPageChanged: ((Int, Int) -> Void)?
    var onNextChapter: (() -> Void)?
    var onPreviousChapter: (() -> Void)?
    var onToggleChrome: (() -> Void)?

    private let textInsets = UIEdgeInsets(top: 28, left: 22, bottom: 28, right: 22)
    private var pager = TextPager(attributed: NSAttributedString(), size: .zero)
    private var pageIndex = 0
    private var laidOutSize: CGSize = .zero
    private var needsRebuild = true
    private var isRebuilding = false
    private var isFlipping = false
    private var flipView: PageFlipView?
    private var lastReportedOffset = -1
    private var lastReportedPage = -1
    private var lastReportedCount = -1

    private enum DragMode {
        case idle
        case undecided
        case rejected
        case active
    }

    private var dragMode: DragMode = .idle
    private var dragForward = true

    override init(frame: CGRect) {
        super.init(frame: frame)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    private func installGestures() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        addGestureRecognizer(tap)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        pan.maximumNumberOfTouches = 1
        addGestureRecognizer(pan)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != laidOutSize {
            laidOutSize = bounds.size
            needsRebuild = true
        }
        if needsRebuild {
            rebuild()
        }
    }

    private func contentSize() -> CGSize {
        CGSize(
            width: max(1, bounds.width - textInsets.left - textInsets.right),
            height: max(1, bounds.height - textInsets.top - textInsets.bottom)
        )
    }

    /// 正文是异步到达的，尺寸却不会变。所以内容一变就主动重排，不能只依赖 layoutSubviews。
    private func requestRebuild() {
        needsRebuild = true
        if laidOutSize.width > 8, laidOutSize.height > 8 {
            rebuild()
        } else {
            setNeedsLayout()
        }
    }

    private func rebuild() {
        guard !isRebuilding else { return }
        isRebuilding = true
        defer { isRebuilding = false }
        // 重排（切主题、调字号）时把正在翻的纸页收掉，避免残影。
        flipView?.removeFromSuperview()
        flipView = nil
        isFlipping = false
        dragMode = .idle
        needsRebuild = false
        let size = contentSize()
        let target = pendingOffset
        pager = TextPager(attributed: attributed, size: size)
        pageIndex = pager.pageIndex(for: target)
        setNeedsDisplay()
        report()
    }

    private func report() {
        guard let range = pager.range(forPage: pageIndex) else { return }
        if range.location != lastReportedOffset {
            lastReportedOffset = range.location
            onOffsetChange?(range.location)
        }
        let page = pageIndex + 1
        let count = pager.pageCount
        if page != lastReportedPage || count != lastReportedCount {
            lastReportedPage = page
            lastReportedCount = count
            onPageChanged?(page, count)
        }
    }

    // MARK: 翻页

    func showNextPage() {
        guard !isFlipping else { return }
        guard pageIndex + 1 < pager.pageCount else {
            onNextChapter?()
            return
        }
        guard startFlip(forward: true) else { return }
        flipView?.animate(to: 1, duration: 0.55) { [weak self] in
            self?.finishFlip(forward: true)
        }
    }

    func showPreviousPage() {
        guard !isFlipping else { return }
        guard pageIndex > 0 else {
            onPreviousChapter?()
            return
        }
        guard startFlip(forward: false) else { return }
        flipView?.animate(to: 1, duration: 0.55) { [weak self] in
            self?.finishFlip(forward: false)
        }
    }

    /// 铺好翻页层：正面是要翻走的那页，底下是要露出来的那页。
    private func startFlip(forward: Bool) -> Bool {
        guard !isFlipping, bounds.width > 8, bounds.height > 8 else { return false }
        let frontIndex = forward ? pageIndex : pageIndex - 1
        let underIndex = forward ? pageIndex + 1 : pageIndex
        guard pager.range(forPage: frontIndex) != nil, pager.range(forPage: underIndex) != nil else {
            return false
        }
        guard let front = pageImage(frontIndex), let under = pageImage(underIndex) else {
            return false
        }

        isFlipping = true
        let view = PageFlipView(
            frame: bounds,
            front: front,
            under: under,
            forward: forward,
            paper: backgroundColor ?? .white
        )
        view.setProgress(0)
        addSubview(view)
        flipView = view
        return true
    }

    private func finishFlip(forward: Bool) {
        flipView?.removeFromSuperview()
        flipView = nil
        isFlipping = false
        if forward {
            pageIndex = min(pageIndex + 1, max(0, pager.pageCount - 1))
        } else {
            pageIndex = max(pageIndex - 1, 0)
        }
        setNeedsDisplay()
        report()
    }

    private func cancelFlip() {
        flipView?.removeFromSuperview()
        flipView = nil
        isFlipping = false
    }

    // MARK: 手势

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        guard !isFlipping, dragMode == .idle else { return }
        let point = gesture.location(in: self)
        let width = max(bounds.width, 1)
        if point.x < width * 0.3 {
            showPreviousPage()
        } else if point.x > width * 0.7 {
            showNextPage()
        } else {
            onToggleChrome?()
        }
    }

    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        switch gesture.state {
        case .began:
            guard !isFlipping else {
                dragMode = .rejected
                return
            }
            dragMode = .undecided

        case .changed:
            let translation = gesture.translation(in: self)

            if dragMode == .undecided {
                guard abs(translation.x) > 10 || abs(translation.y) > 10 else { return }
                if abs(translation.x) < abs(translation.y) * 0.55 {
                    dragMode = .rejected          // 以竖向为主，不归翻页管
                    return
                }
                let forward = translation.x < 0
                if forward, pageIndex + 1 >= pager.pageCount {
                    dragMode = .rejected
                    return
                }
                if !forward, pageIndex <= 0 {
                    dragMode = .rejected
                    return
                }
                guard startFlip(forward: forward) else {
                    dragMode = .rejected
                    return
                }
                dragForward = forward
                dragMode = .active
            }

            if dragMode == .active {
                // 手指挪多少，纸就转多少：从屏幕右边缘拖到左边缘正好翻完一页
                let distance = dragForward ? -translation.x : translation.x
                let progress = distance / max(bounds.width, 1)
                flipView?.setProgress(progress)
            }

        case .ended, .cancelled:
            if dragMode == .active {
                commitDrag(gesture)
            } else if dragMode == .undecided, gesture.state == .ended {
                // 位移很小但速度够快：当成轻扫
                let velocityX = gesture.velocity(in: self).x
                if velocityX < -900, pageIndex + 1 < pager.pageCount {
                    showNextPage()
                } else if velocityX > 900, pageIndex > 0 {
                    showPreviousPage()
                }
            }
            dragMode = .idle

        default:
            break
        }
    }

    /// 松手判定：得拖过大半屏，或者甩得很干脆，才把这页送过去；否则弹回原处。
    private func commitDrag(_ gesture: UIPanGestureRecognizer) {
        guard let view = flipView else {
            cancelFlip()
            return
        }
        let progress = view.currentProgress
        let velocityX = gesture.velocity(in: self).x
        let commit = dragForward
            ? (progress > 0.45 || velocityX < -900)
            : (progress > 0.45 || velocityX > 900)
        let forward = dragForward
        let target: CGFloat = commit ? 1 : 0
        let remaining = abs(target - progress)
        // 送走时把剩下的角度补完，回弹时慢一点，让手能看清纸是退回去的
        let duration = commit
            ? max(0.16, 0.34 * Double(remaining))
            : max(0.22, 0.40 * Double(remaining))

        view.animate(to: target, duration: duration) { [weak self] in
            guard let self else { return }
            if commit {
                self.finishFlip(forward: forward)
            } else {
                self.cancelFlip()
            }
        }
    }

    // MARK: 绘制

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }

        // 兜底：如果尺寸已经有效却还没排出分页，先补一次，避免出现整页空白。
        if (needsRebuild || pager.pageCount == 0), laidOutSize.width > 8, laidOutSize.height > 8 {
            rebuild()
        }
        guard attributed.length > 0 else { return }
        if pageIndex >= pager.pageCount {
            pageIndex = max(0, pager.pageCount - 1)
        }
        guard let range = pager.range(forPage: pageIndex) else { return }
        drawPage(range, into: context)
    }

    /// 把某一页的正文画到给定的上下文里，坐标与分页时使用的完全一致。
    private func drawPage(_ range: NSRange, into context: CGContext) {
        let size = pager.contentSize
        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)

        context.saveGState()
        context.textMatrix = .identity
        context.translateBy(x: textInsets.left, y: textInsets.top)
        context.translateBy(x: 0, y: size.height)
        context.scaleBy(x: 1, y: -1)

        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        let frame = CTFramesetterCreateFrame(
            framesetter,
            CFRangeMake(range.location, range.length),
            path,
            nil
        )
        CTFrameDraw(frame, context)
        context.restoreGState()
    }

    /// 把某一页渲染成位图，用于翻页时前后的两页。
    private func pageImage(_ index: Int) -> UIImage? {
        guard bounds.width > 8, bounds.height > 8 else { return nil }
        guard let range = pager.range(forPage: index) else { return nil }
        let format = UIGraphicsImageRendererFormat.preferred()
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: bounds.size, format: format)
        return renderer.image { ctx in
            let cg = ctx.cgContext
            cg.setFillColor((backgroundColor ?? UIColor.white).cgColor)
            cg.fill(CGRect(origin: .zero, size: bounds.size))
            drawPage(range, into: cg)
        }
    }
}

// MARK: - 颜色小工具

extension UIColor {
    /// 纸边用的深一点的同色
    func darker(by amount: CGFloat = 0.12) -> UIColor {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard getRed(&r, green: &g, blue: &b, alpha: &a) else { return self }
        return UIColor(
            red: max(0, r - amount),
            green: max(0, g - amount),
            blue: max(0, b - amount),
            alpha: a
        )
    }
}

// MARK: - SwiftUI 包装

struct PagedReaderView: UIViewRepresentable {
    let attributed: NSAttributedString?
    let renderID: UUID
    let restoreOffset: Int
    let backgroundColor: UIColor
    let onOffsetChange: (Int) -> Void
    let onPageChanged: (Int, Int) -> Void
    let onNextChapter: () -> Void
    let onPreviousChapter: () -> Void
    let onTap: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> PagedTextView {
        let view = PagedTextView()
        view.backgroundColor = backgroundColor
        view.attributed = attributed ?? NSAttributedString(string: "")
        view.renderID = renderID
        view.pendingOffset = restoreOffset
        bind(view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: PagedTextView, context: Context) {
        context.coordinator.parent = self
        view.backgroundColor = backgroundColor
        if view.renderID != renderID {
            view.attributed = attributed ?? NSAttributedString(string: "")
            if view.pendingOffset != restoreOffset {
                view.pendingOffset = restoreOffset
            }
            view.renderID = renderID
        }
        bind(view, coordinator: context.coordinator)
    }

    private func bind(_ view: PagedTextView, coordinator: Coordinator) {
        view.onOffsetChange = { [weak coordinator] value in coordinator?.parent.onOffsetChange(value) }
        view.onPageChanged = { [weak coordinator] page, total in
            coordinator?.parent.onPageChanged(page, total)
        }
        view.onNextChapter = { [weak coordinator] in coordinator?.parent.onNextChapter() }
        view.onPreviousChapter = { [weak coordinator] in coordinator?.parent.onPreviousChapter() }
        view.onToggleChrome = { [weak coordinator] in coordinator?.parent.onTap() }
    }

    final class Coordinator {
        var parent: PagedReaderView

        init(parent: PagedReaderView) {
            self.parent = parent
        }
    }
}
