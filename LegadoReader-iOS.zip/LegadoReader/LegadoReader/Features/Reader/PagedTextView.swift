import SwiftUI
import UIKit
import CoreText

// MARK: - 分页器

/// 用 CoreText 把整章文本按可视区域切成页，返回每页对应的字符范围。
final class TextPager {
    private(set) var ranges: [NSRange] = []
    let contentSize: CGSize

    init(attributed: NSAttributedString, size: CGSize) {
        contentSize = size
        guard size.width > 8, size.height > 8, attributed.length > 0 else { return }

        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)
        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        var start = 0
        while start < attributed.length {
            let frame = CTFramesetterCreateFrame(
                framesetter,
                CFRangeMake(start, attributed.length - start),
                path,
                nil
            )
            let visible = CTFrameGetVisibleStringRange(frame)
            guard visible.length > 0 else { break }
            ranges.append(NSRange(location: visible.location, length: visible.length))
            start = visible.location + visible.length
        }
        if ranges.isEmpty {
            ranges = [NSRange(location: 0, length: attributed.length)]
        }
    }

    var pageCount: Int { ranges.count }

    func pageIndex(for offset: Int) -> Int {
        guard !ranges.isEmpty else { return 0 }
        var low = 0
        var high = ranges.count - 1
        while low <= high {
            let mid = (low + high) / 2
            let range = ranges[mid]
            if offset < range.location {
                high = mid - 1
            } else if offset >= range.location + range.length {
                low = mid + 1
            } else {
                return mid
            }
        }
        return min(max(low, 0), ranges.count - 1)
    }

    func range(forPage index: Int) -> NSRange? {
        guard index >= 0, index < ranges.count else { return nil }
        return ranges[index]
    }
}

// MARK: - 翻页图层协议

protocol PageTurnAnimating: AnyObject {
    var currentProgress: CGFloat { get }
    func setProgress(_ value: CGFloat)
    func animate(to target: CGFloat, duration: CFTimeInterval, completion: (() -> Void)?)
}

// MARK: - 仿真翻页（整页立体翻转）

/// 一整页纸绕书脊（左边缘）做 3D 立体翻转：手指拖到哪，纸就转到哪。
/// 翻过 90° 之后看到的是纸背，上面透出淡淡的字迹。
final class PageFlipView: UIView, PageTurnAnimating {

    private let forward: Bool
    private let paperColor: UIColor

    private let underLayer = CALayer()
    private let spineShadow = CAGradientLayer()
    private let pageContainer = CALayer()
    private let frontLayer = CALayer()
    private let backLayer = CALayer()
    private let pageShade = CAGradientLayer()
    private let paperEdge = CALayer()

    private var progressValue: CGFloat = 0

    private var link: CADisplayLink?
    private var animFrom: CGFloat = 0
    private var animTo: CGFloat = 0
    private var animDuration: CFTimeInterval = 0
    private var animStart: CFTimeInterval = 0
    private var animCompletion: (() -> Void)?

    var currentProgress: CGFloat { progressValue }

    init(frame: CGRect, front: UIImage, under: UIImage, forward: Bool, paper: UIColor) {
        self.forward = forward
        self.paperColor = paper
        super.init(frame: frame)
        backgroundColor = paper
        clipsToBounds = true
        isUserInteractionEnabled = false
        build(front: front, under: under)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        link?.invalidate()
    }

    private func build(front: UIImage, under: UIImage) {
        layer.backgroundColor = paperColor.cgColor

        underLayer.frame = bounds
        underLayer.contentsGravity = .resize
        underLayer.contentsScale = under.scale
        underLayer.contents = under.cgImage
        layer.addSublayer(underLayer)

        spineShadow.frame = CGRect(
            x: 0,
            y: 0,
            width: max(60, bounds.width * 0.34),
            height: bounds.height
        )
        spineShadow.colors = [
            UIColor.black.withAlphaComponent(0.42).cgColor,
            UIColor.black.withAlphaComponent(0.12).cgColor,
            UIColor.clear.cgColor,
        ]
        spineShadow.locations = [0, 0.46, 1] as [NSNumber]
        spineShadow.startPoint = CGPoint(x: 0, y: 0.5)
        spineShadow.endPoint = CGPoint(x: 1, y: 0.5)
        spineShadow.opacity = 0
        layer.addSublayer(spineShadow)

        pageContainer.anchorPoint = CGPoint(x: 0, y: 0.5)
        pageContainer.bounds = CGRect(origin: .zero, size: bounds.size)
        pageContainer.position = CGPoint(x: 0, y: bounds.midY)
        pageContainer.masksToBounds = true
        pageContainer.isDoubleSided = false
        layer.addSublayer(pageContainer)

        frontLayer.frame = pageContainer.bounds
        frontLayer.contentsGravity = .resize
        frontLayer.contentsScale = front.scale
        frontLayer.contents = front.cgImage
        pageContainer.addSublayer(frontLayer)

        let back = Self.paperBack(from: front, size: bounds.size, paper: paperColor)
        backLayer.frame = pageContainer.bounds
        backLayer.contentsGravity = .resize
        backLayer.contentsScale = back.scale
        backLayer.contents = back.cgImage
        backLayer.opacity = 0
        pageContainer.addSublayer(backLayer)

        pageShade.frame = pageContainer.bounds
        pageShade.colors = [
            UIColor.black.withAlphaComponent(0.30).cgColor,
            UIColor.black.withAlphaComponent(0.06).cgColor,
            UIColor.clear.cgColor,
        ]
        pageShade.locations = [0, 0.5, 1] as [NSNumber]
        pageShade.startPoint = CGPoint(x: 0, y: 0.5)
        pageShade.endPoint = CGPoint(x: 1, y: 0.5)
        pageShade.opacity = 0
        pageContainer.addSublayer(pageShade)

        paperEdge.frame = CGRect(x: bounds.width - 1.5, y: 0, width: 1.5, height: bounds.height)
        paperEdge.backgroundColor = paperColor.darker().cgColor
        pageContainer.addSublayer(paperEdge)

        applyProgress()
    }

    /// 纸背：一张比正面略亮的纸，透出字迹的反向影子。
    private static func paperBack(from front: UIImage, size: CGSize, paper: UIColor) -> UIImage {
        let format = UIGraphicsImageRendererFormat.preferred()
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: size, format: format)
        return renderer.image { ctx in
            let cg = ctx.cgContext
            paper.setFill()
            cg.fill(CGRect(origin: .zero, size: size))
            UIColor.white.withAlphaComponent(0.22).setFill()
            cg.fill(CGRect(origin: .zero, size: size))
            front.draw(
                in: CGRect(origin: .zero, size: size),
                blendMode: .normal,
                alpha: 0.13
            )
        }
    }

    func setProgress(_ value: CGFloat) {
        progressValue = min(1, max(0, value))
        applyProgress()
    }

    private func applyProgress() {
        let progress = progressValue
        let angle: CGFloat = forward
            ? -CGFloat.pi * progress
            : -CGFloat.pi * (1 - progress)

        var perspective = CATransform3DIdentity
        perspective.m34 = -1.0 / 1000.0
        pageContainer.transform = CATransform3DRotate(perspective, angle, 0, 1, 0)

        let facing = cos(angle)
        let frontAlpha = min(1, max(0, (facing + 0.10) / 0.20))
        let backAlpha = min(1, max(0, (-facing + 0.10) / 0.20))
        frontLayer.opacity = Float(frontAlpha)
        backLayer.opacity = Float(backAlpha)

        let sideOn = sin(min(CGFloat.pi, abs(angle)))
        pageShade.opacity = Float(min(1, 0.26 + 0.34 * sideOn)) * Float(sideOn)

        spineShadow.opacity = Float(max(0, min(1, 0.52 * sin(CGFloat.pi * progress))))
    }

    func animate(to target: CGFloat, duration seconds: CFTimeInterval, completion: (() -> Void)?) {
        link?.invalidate()
        link = nil
        animFrom = progressValue
        animTo = min(1, max(0, target))
        animDuration = max(0.10, seconds)
        animStart = CACurrentMediaTime()
        animCompletion = completion

        let display = CADisplayLink(target: self, selector: #selector(tick))
        display.add(to: .main, forMode: .common)
        link = display
    }

    @objc private func tick() {
        let t = min(1, (CACurrentMediaTime() - animStart) / animDuration)
        let eased = 1 - pow(1 - t, 3)
        setProgress(animFrom + (animTo - animFrom) * CGFloat(eased))
        if t >= 1 {
            link?.invalidate()
            link = nil
            let callback = animCompletion
            animCompletion = nil
            callback?()
        }
    }
}

// MARK: - 平滑滑动

/// 当前页随手移动、并轻轻淡出，下一页从右侧浮上来。
/// 纸页不会被硬折成 90°，所以看起来比立体翻转柔和得多。
final class PageSlideView: UIView, PageTurnAnimating {

    private let forward: Bool
    private let paperColor: UIColor
    private let underLayer = CALayer()
    private let pageLayer = CALayer()

    private var progressValue: CGFloat = 0

    private var link: CADisplayLink?
    private var animFrom: CGFloat = 0
    private var animTo: CGFloat = 0
    private var animDuration: CFTimeInterval = 0
    private var animStart: CFTimeInterval = 0
    private var animCompletion: (() -> Void)?

    var currentProgress: CGFloat { progressValue }

    init(frame: CGRect, front: UIImage, under: UIImage, forward: Bool, paper: UIColor) {
        self.forward = forward
        self.paperColor = paper
        super.init(frame: frame)
        backgroundColor = paper
        clipsToBounds = true
        isUserInteractionEnabled = false

        underLayer.frame = bounds
        underLayer.contentsGravity = .resize
        underLayer.contentsScale = under.scale
        underLayer.contents = under.cgImage
        layer.addSublayer(underLayer)

        pageLayer.frame = bounds
        pageLayer.contentsGravity = .resize
        pageLayer.contentsScale = front.scale
        pageLayer.contents = front.cgImage
        pageLayer.shadowColor = UIColor.black.cgColor
        pageLayer.shadowOpacity = 0
        pageLayer.shadowRadius = 12
        pageLayer.shadowOffset = CGSize(width: 5, height: 0)
        layer.addSublayer(pageLayer)

        applyProgress()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        link?.invalidate()
    }

    func setProgress(_ value: CGFloat) {
        progressValue = min(1, max(0, value))
        applyProgress()
    }

    private func applyProgress() {
        let progress = progressValue
        let travel = bounds.width * 0.32

        if forward {
            // 当前页向左滑走并淡出，下一页从右侧归位
            pageLayer.transform = CATransform3DMakeTranslation(-travel * progress, 0, 0)
            pageLayer.opacity = Float(max(0, 1 - progress * 1.05))
            underLayer.transform = CATransform3DMakeTranslation(travel * 0.14 * (1 - progress), 0, 0)
            pageLayer.shadowOffset = CGSize(width: 5, height: 0)
        } else {
            // 上一页从左侧浮进来盖住当前页
            pageLayer.transform = CATransform3DMakeTranslation(-travel * (1 - progress), 0, 0)
            pageLayer.opacity = Float(max(0, 1 - (1 - progress) * 1.05))
            underLayer.transform = CATransform3DMakeTranslation(-travel * 0.14 * progress, 0, 0)
            pageLayer.shadowOffset = CGSize(width: -5, height: 0)
        }

        pageLayer.shadowOpacity = Float(max(0, 0.16 * sin(CGFloat.pi * progress)))
    }

    func animate(to target: CGFloat, duration seconds: CFTimeInterval, completion: (() -> Void)?) {
        link?.invalidate()
        link = nil
        animFrom = progressValue
        animTo = min(1, max(0, target))
        animDuration = max(0.08, seconds)
        animStart = CACurrentMediaTime()
        animCompletion = completion

        let display = CADisplayLink(target: self, selector: #selector(tick))
        display.add(to: .main, forMode: .common)
        link = display
    }

    @objc private func tick() {
        let t = min(1, (CACurrentMediaTime() - animStart) / animDuration)
        let eased = 1 - pow(1 - t, 2)
        setProgress(animFrom + (animTo - animFrom) * CGFloat(eased))
        if t >= 1 {
            link?.invalidate()
            link = nil
            let callback = animCompletion
            animCompletion = nil
            callback?()
        }
    }
}

// MARK: - 翻页视图

/// 基于 CoreText 的整页渲染阅读视图。
/// 三种切换效果：平滑滑动 / 仿真立体翻页 / 直接跳页；左右拖动跟手，轻点两侧翻页，中间点击呼出工具栏。
final class PagedTextView: UIView {
    var attributed: NSAttributedString = NSAttributedString() {
        didSet { requestRebuild() }
    }
    var renderID: UUID = UUID() {
        didSet { requestRebuild() }
    }
    var pendingOffset: Int = 0 {
        didSet { requestRebuild() }
    }
    var turnStyle: PageTurnStyle = .slide {
        didSet {
            guard oldValue != turnStyle else { return }
            cancelTurn()
        }
    }

    var onOffsetChange: ((Int) -> Void)?
    var onPageChanged: ((Int, Int) -> Void)?
    var onNextChapter: (() -> Void)?
    var onPreviousChapter: (() -> Void)?
    var onToggleChrome: (() -> Void)?

    /// 正文到页面四边的距离，由阅读设置里的页边距决定。
    var textInsets: UIEdgeInsets = UIEdgeInsets(top: 28, left: 22, bottom: 28, right: 22) {
        didSet {
            guard oldValue.top != textInsets.top
                || oldValue.left != textInsets.left
                || oldValue.bottom != textInsets.bottom
                || oldValue.right != textInsets.right else { return }
            // 改边距时从当前阅读位置重排，避免跳回本章开头。
            pendingOffset = max(0, lastReportedOffset)
            requestRebuild()
        }
    }
    private var pager = TextPager(attributed: NSAttributedString(), size: .zero)
    private var pageIndex = 0
    private var laidOutSize: CGSize = .zero
    private var needsRebuild = true
    private var isRebuilding = false
    private var isTurning = false
    private var turnView: (UIView & PageTurnAnimating)?
    private var dragProgress: CGFloat = 0
    private var lastReportedOffset = -1
    private var lastReportedPage = -1
    private var lastReportedCount = -1
    private var boundaryTurn: Bool?

    private enum DragMode {
        case idle
        case undecided
        case rejected
        case active
    }

    private var dragMode: DragMode = .idle
    private var dragForward = true

    override init(frame: CGRect) {
        super.init(frame: frame)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    private func installGestures() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        addGestureRecognizer(tap)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        pan.maximumNumberOfTouches = 1
        addGestureRecognizer(pan)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != laidOutSize {
            laidOutSize = bounds.size
            needsRebuild = true
        }
        if needsRebuild {
            rebuild()
        }
    }

    private func contentSize() -> CGSize {
        CGSize(
            width: max(1, bounds.width - textInsets.left - textInsets.right),
            height: max(1, bounds.height - textInsets.top - textInsets.bottom)
        )
    }

    /// 正文是异步到达的，尺寸却不会变。所以内容一变就主动重排，不能只依赖 layoutSubviews。
    private func requestRebuild() {
        needsRebuild = true
        if laidOutSize.width > 8, laidOutSize.height > 8 {
            rebuild()
        } else {
            setNeedsLayout()
        }
    }

    private func rebuild() {
        guard !isRebuilding else { return }
        isRebuilding = true
        defer { isRebuilding = false }
        cancelTurn()
        dragMode = .idle
        boundaryTurn = nil
        needsRebuild = false
        let size = contentSize()
        let target = pendingOffset
        pager = TextPager(attributed: attributed, size: size)
        pageIndex = pager.pageIndex(for: target)
        setNeedsDisplay()
        report()
    }

    private func report() {
        guard let range = pager.range(forPage: pageIndex) else { return }
        if range.location != lastReportedOffset {
            lastReportedOffset = range.location
            onOffsetChange?(range.location)
        }
        let page = pageIndex + 1
        let count = pager.pageCount
        if page != lastReportedPage || count != lastReportedCount {
            lastReportedPage = page
            lastReportedCount = count
            onPageChanged?(page, count)
        }
    }

    // MARK: 翻页

    /// 点击两侧时走这里：按当前效果切换；到章首/章末则交给上下章。
    private func turnPage(forward: Bool) {
        guard !isTurning else { return }
        if forward, pageIndex + 1 >= pager.pageCount {
            onNextChapter?()
            return
        }
        if !forward, pageIndex <= 0 {
            onPreviousChapter?()
            return
        }
        switch turnStyle {
        case .instant:
            stepPage(forward: forward)
        case .slide, .curl:
            guard beginTurn(forward: forward) else { return }
            let duration: CFTimeInterval = turnStyle == .curl ? 0.55 : 0.26
            turnView?.animate(to: 1, duration: duration) { [weak self] in
                self?.finishTurn(forward: forward)
            }
        }
    }

    /// 无动画直接换页。
    private func stepPage(forward: Bool) {
        if forward {
            guard pageIndex + 1 < pager.pageCount else {
                onNextChapter?()
                return
            }
            pageIndex += 1
        } else {
            guard pageIndex > 0 else {
                onPreviousChapter?()
                return
            }
            pageIndex -= 1
        }
        setNeedsDisplay()
        report()
    }

    /// 铺好翻页图层：正面是要翻走的那页，底下是要露出来的那页。
    private func beginTurn(forward: Bool) -> Bool {
        guard !isTurning, bounds.width > 8, bounds.height > 8 else { return false }
        let frontIndex = forward ? pageIndex : pageIndex - 1
        let underIndex = forward ? pageIndex + 1 : pageIndex
        guard pager.range(forPage: frontIndex) != nil, pager.range(forPage: underIndex) != nil else {
            return false
        }
        guard let front = pageImage(frontIndex), let under = pageImage(underIndex) else {
            return false
        }

        let paper = backgroundColor ?? .white
        let view: (UIView & PageTurnAnimating)
        switch turnStyle {
        case .curl:
            view = PageFlipView(frame: bounds, front: front, under: under, forward: forward, paper: paper)
        case .slide:
            view = PageSlideView(frame: bounds, front: front, under: under, forward: forward, paper: paper)
        case .instant:
            return false
        }

        isTurning = true
        view.setProgress(0)
        addSubview(view)
        turnView = view
        return true
    }

    private func finishTurn(forward: Bool) {
        turnView?.removeFromSuperview()
        turnView = nil
        isTurning = false
        dragProgress = 0
        if forward {
            pageIndex = min(pageIndex + 1, max(0, pager.pageCount - 1))
        } else {
            pageIndex = max(pageIndex - 1, 0)
        }
        setNeedsDisplay()
        report()
    }

    private func cancelTurn() {
        turnView?.removeFromSuperview()
        turnView = nil
        isTurning = false
        dragProgress = 0
    }

    // MARK: 手势

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        guard !isTurning, dragMode == .idle else { return }
        let point = gesture.location(in: self)
        let width = max(bounds.width, 1)
        if point.x < width * 0.3 {
            turnPage(forward: false)
        } else if point.x > width * 0.7 {
            turnPage(forward: true)
        } else {
            onToggleChrome?()
        }
    }

    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        switch gesture.state {
        case .began:
            guard !isTurning else {
                dragMode = .rejected
                return
            }
            dragMode = .undecided

        case .changed:
            let translation = gesture.translation(in: self)

            if dragMode == .undecided {
                guard abs(translation.x) > 10 || abs(translation.y) > 10 else { return }
                if abs(translation.x) < abs(translation.y) * 0.55 {
                    dragMode = .rejected          // 以竖向为主，不归翻页管
                    return
                }
                let forward = translation.x < 0
                if forward, pageIndex + 1 >= pager.pageCount {
                    dragMode = .rejected
                    boundaryTurn = true
                    return
                }
                if !forward, pageIndex <= 0 {
                    dragMode = .rejected
                    boundaryTurn = false
                    return
                }
                if turnStyle == .instant {
                    isTurning = true              // 只占位，不铺图层
                } else {
                    guard beginTurn(forward: forward) else {
                        dragMode = .rejected
                        return
                    }
                }
                dragForward = forward
                dragMode = .active
            }

            if dragMode == .active {
                let distance = dragForward ? -translation.x : translation.x
                dragProgress = min(1, max(0, distance / max(bounds.width, 1)))
                turnView?.setProgress(dragProgress)
            }

        case .ended, .cancelled:
            if dragMode == .active {
                commitDrag(gesture)
            } else if dragMode == .undecided, gesture.state == .ended {
                // 位移很小但速度够快：当成轻扫
                let velocityX = gesture.velocity(in: self).x
                if velocityX < -900 {
                    if pageIndex + 1 < pager.pageCount {
                        turnPage(forward: true)
                    } else {
                        onNextChapter?()
                    }
                } else if velocityX > 900 {
                    if pageIndex > 0 {
                        turnPage(forward: false)
                    } else {
                        onPreviousChapter?()
                    }
                }
            }
            if let direction = boundaryTurn {
                boundaryTurn = nil
                if direction {
                    onNextChapter?()
                } else {
                    onPreviousChapter?()
                }
            }
            dragMode = .idle

        default:
            break
        }
    }

    /// 松手判定：拖过四成，或者甩得够干脆，就把这页送过去；否则退回原处。
    private func commitDrag(_ gesture: UIPanGestureRecognizer) {
        let progress = dragProgress
        let velocityX = gesture.velocity(in: self).x
        let forward = dragForward
        let commit = forward
            ? (progress > 0.4 || velocityX < -900)
            : (progress > 0.4 || velocityX > 900)

        if turnStyle == .instant {
            isTurning = false
            dragProgress = 0
            if commit { stepPage(forward: forward) }
            return
        }

        guard let view = turnView else {
            cancelTurn()
            return
        }
        let target: CGFloat = commit ? 1 : 0
        let remaining = abs(target - progress)
        let duration = commit
            ? max(0.14, 0.26 * Double(remaining))
            : max(0.20, 0.32 * Double(remaining))

        view.animate(to: target, duration: duration) { [weak self] in
            guard let self else { return }
            if commit {
                self.finishTurn(forward: forward)
            } else {
                self.cancelTurn()
            }
        }
    }

    // MARK: 绘制

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }

        // 兜底：如果尺寸已经有效却还没排出分页，先补一次，避免出现整页空白。
        if (needsRebuild || pager.pageCount == 0), laidOutSize.width > 8, laidOutSize.height > 8 {
            rebuild()
        }
        guard attributed.length > 0 else { return }
        if pageIndex >= pager.pageCount {
            pageIndex = max(0, pager.pageCount - 1)
        }
        guard let range = pager.range(forPage: pageIndex) else { return }
        drawPage(range, into: context)
    }

    /// 把某一页的正文画到给定的上下文里，坐标与分页时使用的完全一致。
    private func drawPage(_ range: NSRange, into context: CGContext) {
        let size = pager.contentSize
        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)

        context.saveGState()
        context.textMatrix = .identity
        context.translateBy(x: textInsets.left, y: textInsets.top)
        context.translateBy(x: 0, y: size.height)
        context.scaleBy(x: 1, y: -1)

        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        let frame = CTFramesetterCreateFrame(
            framesetter,
            CFRangeMake(range.location, range.length),
            path,
            nil
        )
        CTFrameDraw(frame, context)
        context.restoreGState()
    }

    /// 把某一页渲染成位图，用于翻页时前后的两页。
    private func pageImage(_ index: Int) -> UIImage? {
        guard bounds.width > 8, bounds.height > 8 else { return nil }
        guard let range = pager.range(forPage: index) else { return nil }
        let format = UIGraphicsImageRendererFormat.preferred()
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: bounds.size, format: format)
        return renderer.image { ctx in
            let cg = ctx.cgContext
            cg.setFillColor((backgroundColor ?? UIColor.white).cgColor)
            cg.fill(CGRect(origin: .zero, size: bounds.size))
            drawPage(range, into: cg)
        }
    }
}

// MARK: - 颜色小工具

extension UIColor {
    /// 纸边用的深一点的同色
    func darker(by amount: CGFloat = 0.12) -> UIColor {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard getRed(&r, green: &g, blue: &b, alpha: &a) else { return self }
        return UIColor(
            red: max(0, r - amount),
            green: max(0, g - amount),
            blue: max(0, b - amount),
            alpha: a
        )
    }
}

// MARK: - SwiftUI 包装

struct PagedReaderView: UIViewRepresentable {
    let attributed: NSAttributedString?
    let renderID: UUID
    let restoreOffset: Int
    let backgroundColor: UIColor
    let turnStyle: PageTurnStyle
    let insets: UIEdgeInsets
    let onOffsetChange: (Int) -> Void
    let onPageChanged: (Int, Int) -> Void
    let onNextChapter: () -> Void
    let onPreviousChapter: () -> Void
    let onTap: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> PagedTextView {
        let view = PagedTextView()
        view.backgroundColor = backgroundColor
        view.turnStyle = turnStyle
        view.textInsets = insets
        view.attributed = attributed ?? NSAttributedString(string: "")
        view.renderID = renderID
        view.pendingOffset = restoreOffset
        bind(view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: PagedTextView, context: Context) {
        context.coordinator.parent = self
        view.backgroundColor = backgroundColor
        view.textInsets = insets
        if view.turnStyle != turnStyle {
            view.turnStyle = turnStyle
        }
        if view.renderID != renderID {
            view.attributed = attributed ?? NSAttributedString(string: "")
            if view.pendingOffset != restoreOffset {
                view.pendingOffset = restoreOffset
            }
            view.renderID = renderID
        }
        bind(view, coordinator: context.coordinator)
    }

    private func bind(_ view: PagedTextView, coordinator: Coordinator) {
        view.onOffsetChange = { [weak coordinator] value in coordinator?.parent.onOffsetChange(value) }
        view.onPageChanged = { [weak coordinator] page, total in
            coordinator?.parent.onPageChanged(page, total)
        }
        view.onNextChapter = { [weak coordinator] in coordinator?.parent.onNextChapter() }
        view.onPreviousChapter = { [weak coordinator] in coordinator?.parent.onPreviousChapter() }
        view.onToggleChrome = { [weak coordinator] in coordinator?.parent.onTap() }
    }

    final class Coordinator {
        var parent: PagedReaderView

        init(parent: PagedReaderView) {
            self.parent = parent
        }
    }
}
