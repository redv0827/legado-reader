import SwiftUI
import UIKit
import CoreText

// MARK: - 分页器

/// 用 CoreText 把整章文本按可视区域切成页，返回每页对应的字符范围。
final class TextPager {
    private(set) var ranges: [NSRange] = []
    let contentSize: CGSize

    init(attributed: NSAttributedString, size: CGSize) {
        contentSize = size
        guard size.width > 8, size.height > 8, attributed.length > 0 else { return }

        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)
        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        var start = 0
        while start < attributed.length {
            let frame = CTFramesetterCreateFrame(
                framesetter,
                CFRangeMake(start, attributed.length - start),
                path,
                nil
            )
            let visible = CTFrameGetVisibleStringRange(frame)
            guard visible.length > 0 else { break }
            ranges.append(NSRange(location: visible.location, length: visible.length))
            start = visible.location + visible.length
        }
        if ranges.isEmpty {
            ranges = [NSRange(location: 0, length: attributed.length)]
        }
    }

    var pageCount: Int { ranges.count }

    func pageIndex(for offset: Int) -> Int {
        guard !ranges.isEmpty else { return 0 }
        var low = 0
        var high = ranges.count - 1
        while low <= high {
            let mid = (low + high) / 2
            let range = ranges[mid]
            if offset < range.location {
                high = mid - 1
            } else if offset >= range.location + range.length {
                low = mid + 1
            } else {
                return mid
            }
        }
        return min(max(low, 0), ranges.count - 1)
    }

    func range(forPage index: Int) -> NSRange? {
        guard index >= 0, index < ranges.count else { return nil }
        return ranges[index]
    }
}

// MARK: - 翻页视图

/// 基于 CoreText 的整页渲染阅读视图：左右两侧点击或滑动翻页，中间点击呼出工具栏。
final class PagedTextView: UIView {
    var attributed: NSAttributedString = NSAttributedString() {
        didSet { requestRebuild() }
    }
    var renderID: UUID = UUID() {
        didSet { requestRebuild() }
    }
    var pendingOffset: Int = 0 {
        didSet { requestRebuild() }
    }

    var onOffsetChange: ((Int) -> Void)?
    var onPageChanged: ((Int, Int) -> Void)?
    var onNextChapter: (() -> Void)?
    var onPreviousChapter: (() -> Void)?
    var onToggleChrome: (() -> Void)?

    private let textInsets = UIEdgeInsets(top: 28, left: 22, bottom: 28, right: 22)
    private var pager = TextPager(attributed: NSAttributedString(), size: .zero)
    private var pageIndex = 0
    private var laidOutSize: CGSize = .zero
    private var needsRebuild = true
    private var isRebuilding = false
    private var isFlipping = false
    private var flipContainer: UIView?
    private var lastReportedOffset = -1
    private var lastReportedPage = -1
    private var lastReportedCount = -1

    override init(frame: CGRect) {
        super.init(frame: frame)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        isOpaque = false
        backgroundColor = .clear
        contentMode = .redraw
        installGestures()
    }

    private func installGestures() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        addGestureRecognizer(tap)

        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeLeft.direction = .left
        addGestureRecognizer(swipeLeft)

        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeRight.direction = .right
        addGestureRecognizer(swipeRight)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != laidOutSize {
            laidOutSize = bounds.size
            needsRebuild = true
        }
        if needsRebuild {
            rebuild()
        }
    }

    private func contentSize() -> CGSize {
        CGSize(
            width: max(1, bounds.width - textInsets.left - textInsets.right),
            height: max(1, bounds.height - textInsets.top - textInsets.bottom)
        )
    }

    /// 正文是异步到达的，尺寸却不会变。所以内容一变就主动重排，不能只依赖 layoutSubviews。
    private func requestRebuild() {
        needsRebuild = true
        if laidOutSize.width > 8, laidOutSize.height > 8 {
            rebuild()
        } else {
            setNeedsLayout()
        }
    }

    private func rebuild() {
        guard !isRebuilding else { return }
        isRebuilding = true
        defer { isRebuilding = false }
        // 重排（切主题、调字号）时把正在翻的动画层收掉，避免残影。
        flipContainer?.removeFromSuperview()
        flipContainer = nil
        isFlipping = false
        needsRebuild = false
        let size = contentSize()
        let target = pendingOffset
        pager = TextPager(attributed: attributed, size: size)
        pageIndex = pager.pageIndex(for: target)
        setNeedsDisplay()
        report()
    }

    private func report() {
        guard let range = pager.range(forPage: pageIndex) else { return }
        if range.location != lastReportedOffset {
            lastReportedOffset = range.location
            onOffsetChange?(range.location)
        }
        let page = pageIndex + 1
        let count = pager.pageCount
        if page != lastReportedPage || count != lastReportedCount {
            lastReportedPage = page
            lastReportedCount = count
            onPageChanged?(page, count)
        }
    }

    // MARK: 翻页

    func showNextPage() {
        if pageIndex + 1 < pager.pageCount {
            runFlip(forward: true) { [weak self] in
                guard let self else { return }
                self.pageIndex += 1
                self.setNeedsDisplay()
                self.report()
            }
        } else {
            onNextChapter?()
        }
    }

    func showPreviousPage() {
        if pageIndex > 0 {
            runFlip(forward: false) { [weak self] in
                guard let self else { return }
                self.pageIndex -= 1
                self.setNeedsDisplay()
                self.report()
            }
        } else {
            onPreviousChapter?()
        }
    }

    /// 仿真翻页：正在翻动的那一页绕书脊（左边缘）做 3D 立体翻转，
    /// 翻过去之后露出下一页，边缘带一道随角度变化的光影。
    private func runFlip(forward: Bool, completion: @escaping () -> Void) {
        guard !isFlipping, bounds.width > 8, bounds.height > 8 else {
            completion()
            return
        }
        let targetIndex = forward ? pageIndex + 1 : pageIndex - 1
        guard let incoming = pageImage(targetIndex), let outgoing = pageImage(pageIndex) else {
            completion()
            return
        }

        isFlipping = true

        let container = UIView(frame: bounds)
        container.isUserInteractionEnabled = false
        container.backgroundColor = backgroundColor ?? .white
        container.clipsToBounds = true
        addSubview(container)
        flipContainer = container

        let staticImage = forward ? incoming : outgoing
        let rotatingImage = forward ? outgoing : incoming

        let backView = UIImageView(image: staticImage)
        backView.frame = container.bounds
        backView.contentMode = .scaleAspectFill
        container.addSubview(backView)

        let frontView = UIImageView(image: rotatingImage)
        frontView.frame = container.bounds
        frontView.contentMode = .scaleAspectFill
        frontView.layer.anchorPoint = CGPoint(x: 0, y: 0.5)
        frontView.layer.position = CGPoint(x: 0, y: container.bounds.midY)
        container.addSubview(frontView)

        // 书脊处的阴影，翻动时最深，落页时收掉。
        let shadow = CAGradientLayer()
        shadow.colors = [
            UIColor.black.withAlphaComponent(0.34).cgColor,
            UIColor.black.withAlphaComponent(0.10).cgColor,
            UIColor.clear.cgColor,
        ]
        shadow.locations = [0, 0.45, 1] as [NSNumber]
        shadow.startPoint = CGPoint(x: 0, y: 0.5)
        shadow.endPoint = CGPoint(x: 1, y: 0.5)
        shadow.frame = CGRect(
            x: 0,
            y: 0,
            width: max(60, container.bounds.width * 0.3),
            height: container.bounds.height
        )
        shadow.opacity = 0
        container.layer.insertSublayer(shadow, above: backView.layer)

        let duration: CFTimeInterval = 0.46
        let timing = CAMediaTimingFunction(controlPoints: 0.22, 0.61, 0.36, 1.0)

        var perspective = CATransform3DIdentity
        perspective.m34 = -1.0 / 900.0
        let startAngle: CGFloat = forward ? 0 : -.pi
        let endAngle: CGFloat = forward ? -.pi : 0

        let flip = CABasicAnimation(keyPath: "transform")
        flip.fromValue = NSValue(caTransform3D: CATransform3DRotate(perspective, startAngle, 0, 1, 0))
        flip.toValue = NSValue(caTransform3D: CATransform3DRotate(perspective, endAngle, 0, 1, 0))
        flip.duration = duration
        flip.timingFunction = timing
        // 翻过 90° 之后把页面淡掉，避免看到镜像的正文。
        let fade = CAKeyframeAnimation(keyPath: "opacity")
        fade.values = [1.0, 1.0, 0.0]
        fade.keyTimes = [0, 0.62, 1] as [NSNumber]
        fade.duration = duration
        fade.isRemovedOnCompletion = false
        fade.fillMode = .forwards

        let shadowAnim = CAKeyframeAnimation(keyPath: "opacity")
        shadowAnim.values = [0.0, 0.75, 0.0]
        shadowAnim.keyTimes = [0, 0.5, 1] as [NSNumber]
        shadowAnim.duration = duration
        shadowAnim.isRemovedOnCompletion = false
        shadowAnim.fillMode = .forwards

        CATransaction.begin()
        CATransaction.setCompletionBlock { [weak self] in
            guard let self else { return }
            container.removeFromSuperview()
            self.flipContainer = nil
            self.isFlipping = false
            completion()
        }
        frontView.layer.add(flip, forKey: "flip")
        frontView.layer.add(fade, forKey: "fade")
        shadow.add(shadowAnim, forKey: "shadow")
        frontView.layer.transform = CATransform3DRotate(perspective, endAngle, 0, 1, 0)
        CATransaction.commit()
    }

    // MARK: 手势

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        guard !isFlipping else { return }
        let point = gesture.location(in: self)
        let width = max(bounds.width, 1)
        if point.x < width * 0.3 {
            showPreviousPage()
        } else if point.x > width * 0.7 {
            showNextPage()
        } else {
            onToggleChrome?()
        }
    }

    @objc private func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        guard !isFlipping else { return }
        switch gesture.direction {
        case .left:
            showNextPage()
        case .right:
            showPreviousPage()
        default:
            break
        }
    }

    // MARK: 绘制

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }

        // 兜底：如果尺寸已经有效却还没排出分页，先补一次，避免出现整页空白。
        if (needsRebuild || pager.pageCount == 0), laidOutSize.width > 8, laidOutSize.height > 8 {
            rebuild()
        }
        guard attributed.length > 0 else { return }
        if pageIndex >= pager.pageCount {
            pageIndex = max(0, pager.pageCount - 1)
        }
        guard let range = pager.range(forPage: pageIndex) else { return }
        drawPage(range, into: context)
    }

    /// 把某一页的正文画到给定的上下文里，坐标与分页时使用的完全一致。
    private func drawPage(_ range: NSRange, into context: CGContext) {
        let size = pager.contentSize
        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)

        context.saveGState()
        context.textMatrix = .identity
        context.translateBy(x: textInsets.left, y: textInsets.top)
        context.translateBy(x: 0, y: size.height)
        context.scaleBy(x: 1, y: -1)

        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        let frame = CTFramesetterCreateFrame(
            framesetter,
            CFRangeMake(range.location, range.length),
            path,
            nil
        )
        CTFrameDraw(frame, context)
        context.restoreGState()
    }

    /// 把某一页渲染成位图，用于仿真翻页时前后的两页。
    private func pageImage(_ index: Int) -> UIImage? {
        guard bounds.width > 8, bounds.height > 8 else { return nil }
        guard let range = pager.range(forPage: index) else { return nil }
        let format = UIGraphicsImageRendererFormat.preferred()
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: bounds.size, format: format)
        return renderer.image { ctx in
            let cg = ctx.cgContext
            cg.setFillColor((backgroundColor ?? UIColor.white).cgColor)
            cg.fill(CGRect(origin: .zero, size: bounds.size))
            drawPage(range, into: cg)
        }
    }
}

// MARK: - SwiftUI 包装

struct PagedReaderView: UIViewRepresentable {
    let attributed: NSAttributedString?
    let renderID: UUID
    let restoreOffset: Int
    let backgroundColor: UIColor
    let onOffsetChange: (Int) -> Void
    let onPageChanged: (Int, Int) -> Void
    let onNextChapter: () -> Void
    let onPreviousChapter: () -> Void
    let onTap: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> PagedTextView {
        let view = PagedTextView()
        view.backgroundColor = backgroundColor
        view.attributed = attributed ?? NSAttributedString(string: "")
        view.renderID = renderID
        view.pendingOffset = restoreOffset
        bind(view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: PagedTextView, context: Context) {
        context.coordinator.parent = self
        view.backgroundColor = backgroundColor
        if view.renderID != renderID {
            view.attributed = attributed ?? NSAttributedString(string: "")
            if view.pendingOffset != restoreOffset {
                view.pendingOffset = restoreOffset
            }
            view.renderID = renderID
        }
        bind(view, coordinator: context.coordinator)
    }

    private func bind(_ view: PagedTextView, coordinator: Coordinator) {
        view.onOffsetChange = { [weak coordinator] value in coordinator?.parent.onOffsetChange(value) }
        view.onPageChanged = { [weak coordinator] page, total in
            coordinator?.parent.onPageChanged(page, total)
        }
        view.onNextChapter = { [weak coordinator] in coordinator?.parent.onNextChapter() }
        view.onPreviousChapter = { [weak coordinator] in coordinator?.parent.onPreviousChapter() }
        view.onToggleChrome = { [weak coordinator] in coordinator?.parent.onTap() }
    }

    final class Coordinator {
        var parent: PagedReaderView

        init(parent: PagedReaderView) {
            self.parent = parent
        }
    }
}
