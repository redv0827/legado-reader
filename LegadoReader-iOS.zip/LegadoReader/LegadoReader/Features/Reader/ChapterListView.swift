import SwiftUI

/// 目录列表，阅读器与详情页共用。
struct ChapterListView: View {
    let chapters: [Chapter]
    var currentIndex: Int?
    let onSelect: (Int) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var keyword = ""

    private var filtered: [Chapter] {
        let key = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return chapters }
        return chapters.filter {
            $0.title.localizedCaseInsensitiveContains(key) || String($0.index + 1) == key
        }
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(filtered) { chapter in
                            Button {
                                onSelect(chapter.index)
                                dismiss()
                            } label: {
                                row(chapter)
                            }
                            .buttonStyle(.plain)
                            .id(chapter.index)

                            Divider()
                                .padding(.leading, 48)
                                .opacity(chapter.index == filtered.last?.index ? 0 : 0.6)
                        }
                    }
                    .padding(.vertical, 4)
                }
                .background(Palette.paper)
                .onAppear {
                    guard let currentIndex else { return }
                    DispatchQueue.main.async {
                        proxy.scrollTo(currentIndex, anchor: .center)
                    }
                }
            }
            .navigationTitle("目录 · \(chapters.count) 章")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $keyword, prompt: "筛选章节标题")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
            }
        }
    }

    private func row(_ chapter: Chapter) -> some View {
        let isCurrent = chapter.index == currentIndex
        return HStack(spacing: 10) {
            Text("\(chapter.index + 1)")
                .font(.system(size: 11, design: .monospaced))
                .foregroundStyle(Palette.secondaryInk)
                .frame(width: 32, alignment: .trailing)
            Text(chapter.title)
                .font(.system(size: 15, weight: isCurrent ? .semibold : .regular))
                .foregroundStyle(isCurrent ? Palette.accent : Palette.ink)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
            Spacer(minLength: 0)
            if isCurrent {
                Image(systemName: "book.fill")
                    .font(.caption)
                    .foregroundStyle(Palette.accent)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .contentShape(Rectangle())
    }
}
