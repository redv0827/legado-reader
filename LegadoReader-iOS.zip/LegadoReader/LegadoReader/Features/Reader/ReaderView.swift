import SwiftUI

struct ReaderView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model: ReaderController

    @State private var showCatalog = false
    @State private var showSettings = false
    @State private var showSourceSwitch = false
    @State private var toastText: String?
    @State private var autoHideTask: Task<Void, Never>?

    init(book: Book, api: APIClient, chapters: [Chapter] = [], startChapterIndex: Int? = nil) {
        _model = StateObject(
            wrappedValue: ReaderController(
                book: book,
                api: api,
                chapters: chapters,
                startIndex: startChapterIndex
            )
        )
    }

    /// 打开本地纯文本书籍。
    init(localBook: LocalBook, api: APIClient) {
        _model = StateObject(
            wrappedValue: ReaderController(localBook: localBook, api: api)
        )
    }

    private var theme: ReaderThemeKind { model.settings.theme }

    /// 整页阅读：卷角仿真用系统的 pageCurl，其余两种用自绘图层。
    @ViewBuilder
    private var pagedReader: some View {
        if model.settings.turn == .curl {
            PagedCurlReaderView(
                attributed: model.attributed,
                renderID: model.renderID,
                restoreOffset: model.restoreOffset,
                backgroundColor: theme.backgroundColor,
                insets: model.settings.textInsets,
                onOffsetChange: { model.noteOffset($0) },
                onPageChanged: { page, total in
                    model.pageLabel = "第 \(page) / \(total) 页"
                },
                onNextChapter: { Task { await model.goNext() } },
                onPreviousChapter: { Task { await model.goPrevious(landingAtEnd: true) } },
                onTap: toggleChrome
            )
        } else {
            PagedReaderView(
                attributed: model.attributed,
                renderID: model.renderID,
                restoreOffset: model.restoreOffset,
                backgroundColor: theme.backgroundColor,
                turnStyle: model.settings.turn,
                insets: model.settings.textInsets,
                onOffsetChange: { model.noteOffset($0) },
                onPageChanged: { page, total in
                    model.pageLabel = "第 \(page) / \(total) 页"
                },
                onNextChapter: { Task { await model.goNext() } },
                onPreviousChapter: { Task { await model.goPrevious(landingAtEnd: true) } },
                onTap: toggleChrome
            )
        }
    }

    var body: some View {
        ZStack {
            theme.swiftUIBackground.ignoresSafeArea()

            if model.settings.paged {
                pagedReader
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()
            } else {
                ChapterTextView(
                    attributed: model.attributed,
                    renderID: model.renderID,
                    restoreOffset: model.restoreOffset,
                    backgroundColor: theme.backgroundColor,
                    insets: model.settings.textInsets,
                    onOffsetChange: { model.noteOffset($0) },
                    onTap: toggleChrome
                )
            }

            if model.isLoading {
                loadingOverlay
            }
            if let error = model.errorMessage, !model.isLoading {
                errorOverlay(error)
            }
            if model.showChrome {
                chrome
                    .transition(.opacity)
            }
        }
        .statusBar(hidden: !model.showChrome)
        .toast($toastText)
        .onChange(of: model.settings.paged) { paged in
            if !paged { model.pageLabel = "" }
        }
        .task {
            await model.start()
            scheduleAutoHide()
        }
        .onDisappear {
            autoHideTask?.cancel()
            Task { await model.flush() }
        }
        .sheet(isPresented: $showCatalog) {
            ChapterListView(chapters: model.chapters, currentIndex: model.currentIndex) { index in
                showCatalog = false
                Task { await model.open(index: index, offset: 0) }
            }
        }
        .sheet(isPresented: $showSettings) {
            ReaderSettingsSheet(
                settings: Binding(
                    get: { model.settings },
                    set: { model.applySettings($0) }
                )
            )
        }
        .sheet(isPresented: $showSourceSwitch) {
            SourceSwitchSheet(book: model.book, api: model.api) { target in
                showSourceSwitch = false
                Task {
                    if let message = await model.switchSource(to: target) {
                        toastText = message
                    }
                }
            }
        }
    }

    // MARK: - 交互层

    private var chrome: some View {
        VStack(spacing: 0) {
            topBar
            Spacer(minLength: 0)
            bottomBar
        }
    }

    private var topBar: some View {
        HStack(alignment: .center, spacing: 10) {
            Button {
                close()
            } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 16, weight: .semibold))
                    .frame(width: 36, height: 36)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(model.book.name)
                    .font(.caption2)
                    .foregroundStyle(theme.swiftUISecondary)
                    .lineLimit(1)
                HStack(spacing: 6) {
                    Text(model.chapterTitle.isEmpty ? "正文" : model.chapterTitle)
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(theme.swiftUIText)
                        .lineLimit(1)
                    if !model.isLocal {
                        Button {
                            showSourceSwitch = true
                        } label: {
                            HStack(spacing: 2) {
                                Image(systemName: "arrow.left.arrow.right")
                                    .font(.system(size: 9, weight: .medium))
                                Text("换源")
                                    .font(.system(size: 10, weight: .medium))
                            }
                            .foregroundStyle(Palette.accent)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(
                                Capsule().stroke(Palette.accent.opacity(0.45), lineWidth: 0.8)
                            )
                        }
                        .buttonStyle(.plain)
                        .fixedSize()
                        if !model.isInShelf {
                            Button {
                                Task {
                                    if let message = await model.addToShelf() {
                                        toastText = message
                                    }
                                }
                            } label: {
                                HStack(spacing: 2) {
                                    Image(systemName: "plus")
                                        .font(.system(size: 9, weight: .medium))
                                    Text("加入书架")
                                        .font(.system(size: 10, weight: .medium))
                                }
                                .foregroundStyle(Palette.accent)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(
                                    Capsule().stroke(Palette.accent.opacity(0.45), lineWidth: 0.8)
                                )
                            }
                            .buttonStyle(.plain)
                            .fixedSize()
                        }
                    }
                }
            }
            Spacer(minLength: 4)
            Button { showSettings = true } label: {
                Image(systemName: "textformat.size")
                    .font(.system(size: 16, weight: .medium))
                    .frame(width: 36, height: 36)
            }
            Button { showCatalog = true } label: {
                Image(systemName: "list.bullet")
                    .font(.system(size: 16, weight: .medium))
                    .frame(width: 36, height: 36)
            }
        }
        .foregroundStyle(theme.swiftUIText)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(
            theme.swiftUIBackground
                .opacity(0.98)
                .ignoresSafeArea(edges: .top)
        )
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(theme.swiftUISecondary.opacity(0.18))
                .frame(height: 0.5)
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            HStack(spacing: 8) {
                Text(model.chapterPositionText)
                if !model.pageLabel.isEmpty {
                    Text("·")
                        .opacity(0.45)
                    Text(model.pageLabel)
                        .monospacedDigit()
                }
            }
            .font(.caption2)
            .foregroundStyle(theme.swiftUISecondary)
            HStack(spacing: 0) {
                navButton("目录", icon: "list.bullet", enabled: true) {
                    showCatalog = true
                }
                navButton("上一章", icon: "chevron.left", enabled: model.canGoPrevious) {
                    Task { await model.goPrevious() }
                }
                navButton("下一章", icon: "chevron.right", enabled: model.canGoNext) {
                    Task { await model.goNext() }
                }
                navButton("设置", icon: "textformat", enabled: true) {
                    showSettings = true
                }
            }
        }
        .padding(.top, 12)
        .padding(.bottom, 10)
        .background(
            theme.swiftUIBackground
                .opacity(0.98)
                .ignoresSafeArea(edges: .bottom)
        )
        .overlay(alignment: .top) {
            Rectangle()
                .fill(theme.swiftUISecondary.opacity(0.18))
                .frame(height: 0.5)
        }
    }

    private func navButton(_ title: String, icon: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .medium))
                Text(title)
                    .font(.system(size: 11))
            }
            .foregroundStyle(theme.swiftUIText.opacity(enabled ? 0.92 : 0.35))
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
    }

    // MARK: - 覆盖层

    private var loadingOverlay: some View {
        VStack(spacing: 10) {
            ProgressView()
                .tint(Palette.accent)
            Text(model.loadingText)
                .font(.caption)
                .foregroundStyle(theme.swiftUISecondary)
        }
        .padding(.horizontal, 26)
        .padding(.vertical, 20)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(theme.swiftUIBackground.opacity(0.94))
                .shadow(color: .black.opacity(0.10), radius: 12, y: 4)
        )
    }

    private func errorOverlay(_ message: String) -> some View {
        VStack(spacing: 14) {
            Image(systemName: "exclamationmark.triangle")
                .font(.system(size: 26, weight: .light))
                .foregroundStyle(Palette.accent)
            Text(message)
                .font(.footnote)
                .foregroundStyle(theme.swiftUIText)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 10) {
                Button("重试") {
                    Task { await model.retry() }
                }
                .font(.footnote.weight(.semibold))
                .foregroundStyle(Palette.accent)
                if model.canGoPrevious {
                    Button("读上一章") {
                        Task { await model.goPrevious() }
                    }
                    .font(.footnote)
                    .foregroundStyle(theme.swiftUISecondary)
                }
                Button("目录") { showCatalog = true }
                    .font(.footnote)
                    .foregroundStyle(theme.swiftUISecondary)
            }
        }
        .padding(24)
        .frame(maxWidth: 320)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(theme.swiftUIBackground.opacity(0.96))
                .shadow(color: .black.opacity(0.12), radius: 14, y: 5)
        )
    }

    // MARK: - 行为

    private func toggleChrome() {
        withAnimation(.easeInOut(duration: 0.18)) {
            model.showChrome.toggle()
        }
        if model.showChrome {
            scheduleAutoHide()
        } else {
            autoHideTask?.cancel()
        }
    }

    private func scheduleAutoHide() {
        autoHideTask?.cancel()
        guard model.showChrome else { return }
        autoHideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 3_500_000_000)
            if Task.isCancelled { return }
            withAnimation(.easeInOut(duration: 0.2)) {
                model.showChrome = false
            }
        }
    }

    private func close() {
        autoHideTask?.cancel()
        Task { await model.flush() }
        dismiss()
    }
}
