import SwiftUI
import UIKit

/// 基于 UITextView 的滚动阅读视图。
/// 关闭了选择与编辑，只用它来排版和滚动，并按原文 UTF-16 偏移记录阅读位置。
struct ChapterTextView: UIViewRepresentable {
    let attributed: NSAttributedString?
    let renderID: UUID
    let restoreOffset: Int
    let backgroundColor: UIColor
    let onOffsetChange: (Int) -> Void
    let onTap: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> UITextView {
        let textView = UITextView()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = true
        textView.alwaysBounceVertical = true
        textView.showsVerticalScrollIndicator = false
        textView.backgroundColor = backgroundColor
        textView.textContainerInset = UIEdgeInsets(top: 20, left: 22, bottom: 72, right: 22)
        textView.textContainer.lineFragmentPadding = 0
        textView.contentInsetAdjustmentBehavior = .never
        textView.delegate = context.coordinator
        // 访问 layoutManager 会把 UITextView 固定为 TextKit 1，字符位置换算更稳定。
        _ = textView.layoutManager

        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap))
        textView.addGestureRecognizer(tap)

        context.coordinator.textView = textView
        context.coordinator.renderID = renderID
        textView.attributedText = attributed ?? NSAttributedString(string: "")
        context.coordinator.restore(to: restoreOffset, in: textView)
        return textView
    }

    func updateUIView(_ textView: UITextView, context: Context) {
        context.coordinator.parent = self
        textView.backgroundColor = backgroundColor
        if context.coordinator.renderID != renderID {
            context.coordinator.renderID = renderID
            context.coordinator.suppressReport = true
            textView.attributedText = attributed ?? NSAttributedString(string: "")
            context.coordinator.restore(to: restoreOffset, in: textView)
            context.coordinator.suppressReport = false
        }
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: ChapterTextView
        weak var textView: UITextView?
        var renderID: UUID?
        var suppressReport = false
        private var lastOffset = -1

        init(parent: ChapterTextView) {
            self.parent = parent
        }

        @objc func handleTap() {
            parent.onTap()
        }

        func scrollViewDidScroll(_ scrollView: UIScrollView) {
            guard !suppressReport, let textView else { return }
            let offset = currentOffset(in: textView)
            if offset != lastOffset {
                lastOffset = offset
                parent.onOffsetChange(offset)
            }
        }

        func restore(to offset: Int, in textView: UITextView) {
            textView.layoutIfNeeded()
            let length = textView.text.utf16.count
            guard length > 0 else {
                lastOffset = 0
                return
            }
            let clamped = min(max(offset, 0), length - 1)
            textView.layoutManager.ensureLayout(for: textView.textContainer)
            let glyphRange = textView.layoutManager.glyphRange(
                forCharacterRange: NSRange(location: clamped, length: 0),
                actualCharacterRange: nil
            )
            let rect = textView.layoutManager.boundingRect(
                forGlyphRange: glyphRange,
                in: textView.textContainer
            )
            let desired = rect.minY + textView.textContainerInset.top
            let maxY = max(0, textView.contentSize.height - textView.bounds.height)
            textView.setContentOffset(
                CGPoint(x: textView.contentOffset.x, y: min(max(0, desired), maxY)),
                animated: false
            )
            lastOffset = currentOffset(in: textView)
        }

        private func currentOffset(in textView: UITextView) -> Int {
            let y = max(0, textView.contentOffset.y) + 10
            let point = CGPoint(x: textView.textContainerInset.left + 2, y: y)
            if let range = textView.characterRange(at: point) {
                return textView.offset(from: textView.beginningOfDocument, to: range.start)
            }
            let containerPoint = CGPoint(
                x: 2,
                y: max(0, textView.contentOffset.y) + 10 - textView.textContainerInset.top
            )
            let index = textView.layoutManager.characterIndex(
                for: containerPoint,
                in: textView.textContainer,
                fractionOfDistanceBetweenInsertionPoints: nil
            )
            return max(0, index)
        }
    }
}
