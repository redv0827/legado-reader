import SwiftUI

/// 换书源面板：先列出服务端已经聚合好的同书来源，不够用时再按书名搜索全网书源。
struct SourceSwitchSheet: View {
    let book: Book
    let api: APIClient
    let onSelect: (Book) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var candidates: [Book]
    @State private var isSearching = false
    @State private var progressText = ""
    @State private var searchMessage: String?
    @State private var searchTask: Task<Void, Never>?

    init(book: Book, api: APIClient, onSelect: @escaping (Book) -> Void) {
        self.book = book
        self.api = api
        self.onSelect = onSelect
        var initial = Self.candidates(from: book)
        // 上次精确搜索命中的书源（1 小时内）直接带进来，不用再等搜索。
        for hit in ExactSourceMemo.shared.books(for: book.name) where hit.bookUrl != book.bookUrl {
            guard !initial.contains(where: { $0.bookUrl == hit.bookUrl }) else { continue }
            initial.append(hit)
        }
        _candidates = State(initialValue: initial)
    }

    /// 换过的源置底，其余按源名排序，优先展示没换过的。
    private var orderedCandidates: [Book] {
        let used = SourceSwitchHistory.shared.used(bookName: book.name)
        return candidates.sorted { lhs, rhs in
            let leftUsed = used.contains(lhs.bookUrl)
            let rightUsed = used.contains(rhs.bookUrl)
            if leftUsed != rightUsed { return !leftUsed }
            return Self.sourceName(of: lhs).localizedStandardCompare(Self.sourceName(of: rhs)) == .orderedAscending
        }
    }

    private var memoText: String {
        guard let hit = ExactSourceMemo.shared.hit(for: book.name), !hit.books.isEmpty else { return "" }
        let minutes = Int(Date().timeIntervalSince(hit.savedAt) / 60)
        return "含上次精确搜索命中的 \(hit.books.count) 个书源（\(minutes) 分钟前）"
    }

    private var currentSourceName: String {
        Self.sourceName(of: book)
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(book.name)
                            .font(.system(size: 15, weight: .semibold))
                        HStack(spacing: 5) {
                            Text(book.author.isEmpty ? "佚名" : book.author)
                            Text("·")
                            Text("当前来源：\(currentSourceName)")
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    }
                    .padding(.vertical, 2)
                }

                Section("同书其他来源") {
                    if candidates.isEmpty {
                        Text(isSearching ? "正在搜索同名书…" : "暂时没有现成的其他来源，点下面搜索更多。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(orderedCandidates) { candidate in
                            Button {
                                pick(candidate)
                            } label: {
                                row(candidate)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                } footer: {
                    if !memoText.isEmpty {
                        Text(memoText)
                    }
                }

                Section {
                    Button {
                        search()
                    } label: {
                        HStack(spacing: 8) {
                            if isSearching {
                                ProgressView().scaleEffect(0.78)
                            } else {
                                Image(systemName: "magnifyingglass")
                            }
                            Text(isSearching ? "正在搜索… \(progressText)" : "搜索更多书源")
                                .font(.system(size: 14, weight: .medium))
                        }
                        .foregroundStyle(Palette.accent)
                    }
                    .disabled(isSearching)

                    if let searchMessage {
                        Text(searchMessage)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                } footer: {
                    Text("换源由服务端校验新来源的目录和正文；成功后按章节名定位，并从本章开头继续。")
                }
            }
            .navigationTitle("换书源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .onDisappear {
            searchTask?.cancel()
            api.cancelSearch()
        }
    }

    // MARK: - 行

    private func row(_ candidate: Book) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(Self.sourceName(of: candidate))
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(Palette.ink)
                    if let total = candidate.totalChapterNum, total > 0 {
                        Text("\(total) 章")
                            .font(.system(size: 10))
                            .foregroundStyle(Palette.secondaryInk)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1)
                            .background(Capsule().fill(Palette.hairline.opacity(0.35)))
                    }
                }
                Text(candidate.bookUrl)
                    .font(.system(size: 10))
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(Palette.secondaryInk.opacity(0.55))
        }
        .padding(.vertical, 3)
        .contentShape(Rectangle())
    }

    // MARK: - 行为

    private func pick(_ candidate: Book) {
        SourceSwitchHistory.shared.record(bookName: book.name, sourceURL: candidate.bookUrl)
        onSelect(candidate)
        dismiss()
    }

    @MainActor
    private func search() {
        guard !isSearching else { return }
        isSearching = true
        searchMessage = nil
        progressText = "0/0 源"
        searchTask?.cancel()
        searchTask = Task { @MainActor in
            do {
                var found = candidates
                for try await event in api.searchEvents(key: book.name, sourceUrl: nil) {
                    if Task.isCancelled { break }
                    if let progress = event.progress {
                        progressText = "\(progress.completed)/\(progress.total) 源"
                    }
                    if let books = event.books {
                        for item in books where isSameBook(item) {
                            merge(item, into: &found)
                        }
                        candidates = found
                    }
                }
                candidates = found
                isSearching = false
                if found.isEmpty {
                    searchMessage = "没有搜到同名同作者的其它来源。"
                }
            } catch {
                isSearching = false
                searchMessage = error.localizedDescription
            }
        }
    }

    private func merge(_ item: Book, into list: inout [Book]) {
        var incoming = [item]
        if let variants = item.sourceVariants {
            incoming.append(contentsOf: variants)
        }
        for candidate in incoming {
            guard candidate.bookUrl != book.bookUrl else { continue }
            guard !list.contains(where: { $0.bookUrl == candidate.bookUrl }) else { continue }
            list.append(candidate)
        }
        list.sort { Self.sourceName(of: $0) < Self.sourceName(of: $1) }
    }

    private func isSameBook(_ other: Book) -> Bool {
        guard normalize(other.name) == normalize(book.name) else { return false }
        if let media = other.mediaType, media != "text", media != "unknown" { return false }
        let currentAuthor = book.author.trimmingCharacters(in: .whitespacesAndNewlines)
        let otherAuthor = other.author.trimmingCharacters(in: .whitespacesAndNewlines)
        if !currentAuthor.isEmpty, !otherAuthor.isEmpty {
            return currentAuthor == otherAuthor
        }
        return true
    }

    private func normalize(_ text: String) -> String {
        text.replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "　", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    // MARK: - 工具

    private static func candidates(from book: Book) -> [Book] {
        var list: [Book] = []
        var incoming: [Book] = []
        if let variants = book.sourceVariants {
            incoming.append(contentsOf: variants)
        }
        for candidate in incoming where candidate.bookUrl != book.bookUrl {
            if !list.contains(where: { $0.bookUrl == candidate.bookUrl }) {
                list.append(candidate)
            }
        }
        list.sort { sourceName(of: $0) < sourceName(of: $1) }
        return list
    }

    private static func sourceName(of book: Book) -> String {
        if let name = book.originName, !name.isEmpty { return name }
        if let host = URL(string: book.origin)?.host, !host.isEmpty { return host }
        if !book.origin.isEmpty { return book.origin }
        return "未知来源"
    }
}
