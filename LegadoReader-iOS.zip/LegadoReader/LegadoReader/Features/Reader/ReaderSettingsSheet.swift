import SwiftUI

struct ReaderSettingsSheet: View {
    @Binding var settings: ReadingSettings
    @Environment(\.dismiss) private var dismiss

    private var theme: ReaderThemeKind { settings.theme }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    preview
                    modeControl
                    turnControl
                    fontSizeControl
                    sliderRow(
                        "行距",
                        value: $settings.lineHeightMultiple,
                        range: 1.15...2.2,
                        display: String(format: "%.2f 倍", settings.lineHeightMultiple)
                    )
                    sliderRow(
                        "段距",
                        value: $settings.paragraphSpacing,
                        range: 0...28,
                        display: "\(Int(settings.paragraphSpacing)) pt"
                    )
                    sliderRow(
                        "字距",
                        value: $settings.letterSpacing,
                        range: 0...4,
                        display: String(format: "%.1f", settings.letterSpacing)
                    )
                    marginsControl
                    fontControl
                    themeControl
                    Toggle(isOn: $settings.indent) {
                        Text("首行缩进")
                            .font(.system(size: 15, weight: .medium))
                    }
                    .tint(Palette.accent)
                    Button {
                        var next = ReadingSettings()
                        next.theme = settings.theme
                        next.paged = settings.paged
                        next.turn = settings.turn
                        settings = next
                    } label: {
                        Text("恢复默认排版")
                            .font(.footnote.weight(.medium))
                            .foregroundStyle(Palette.accent)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                    }
                }
                .padding(20)
            }
            .navigationTitle("阅读设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }

    // MARK: - 预览

    private var preview: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("留白")
                .font(.system(size: CGFloat(settings.fontSize) + 3, weight: .semibold, design: .serif))
            Text("一章一世界。排版改动会立刻应用到当前正文，进度按原文位置保留。")
                .font(.system(size: CGFloat(settings.fontSize), design: .serif))
                .lineSpacing(CGFloat(max(0, settings.fontSize * (settings.lineHeightMultiple - 1))))
                .fixedSize(horizontal: false, vertical: true)
        }
        .foregroundStyle(theme.swiftUIText)
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(theme.swiftUIBackground)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(Palette.hairline.opacity(0.6), lineWidth: 1)
        )
    }

    // MARK: - 控件

    private var modeControl: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("阅读方式")
                .font(.system(size: 14, weight: .medium))
            HStack(spacing: 10) {
                modeButton("整页翻页", subtitle: "点左右两侧翻页", isPaged: true)
                modeButton("连续滚动", subtitle: "上下滑动阅读", isPaged: false)
            }
        }
    }

    private func modeButton(_ title: String, subtitle: String, isPaged: Bool) -> some View {
        Button {
            settings.paged = isPaged
        } label: {
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Palette.ink)
                Text(subtitle)
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.secondaryInk)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .fill(Color.white.opacity(settings.paged == isPaged ? 0.95 : 0.55))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .stroke(
                        settings.paged == isPaged ? Palette.accent : Palette.hairline,
                        lineWidth: settings.paged == isPaged ? 1.5 : 1
                    )
            )
        }
        .buttonStyle(.plain)
    }

    private var turnControl: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Text("翻页效果")
                    .font(.system(size: 14, weight: .medium))
                if !settings.paged {
                    Text("整页阅读时生效")
                        .font(.system(size: 11))
                        .foregroundStyle(Palette.secondaryInk)
                }
            }
            Text("点击左右两侧即翻页；拖住纸页可以跟手翻。")
                .font(.system(size: 11))
                .foregroundStyle(Palette.secondaryInk)
            HStack(spacing: 10) {
                ForEach(PageTurnStyle.allCases) { style in
                    Button {
                        settings.turn = style
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(style.title)
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(Palette.ink)
                            Text(style.subtitle)
                                .font(.system(size: 10))
                                .foregroundStyle(Palette.secondaryInk)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(10)
                        .background(
                            RoundedRectangle(cornerRadius: 11, style: .continuous)
                                .fill(Color.white.opacity(settings.turn == style ? 0.95 : 0.55))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 11, style: .continuous)
                                .stroke(
                                    settings.turn == style ? Palette.accent : Palette.hairline,
                                    lineWidth: settings.turn == style ? 1.5 : 1
                                )
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
            .opacity(settings.paged ? 1 : 0.5)
            .disabled(!settings.paged)
        }
    }

    private var fontSizeControl: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("字号")
                    .font(.system(size: 14, weight: .medium))
                Spacer()
                Text("\(Int(settings.fontSize)) pt")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            HStack(spacing: 14) {
                Button {
                    settings.fontSize = max(13, settings.fontSize - 1)
                } label: {
                    fontAdjustButton("A-", small: true)
                }
                Slider(value: $settings.fontSize, in: 13...30, step: 1)
                    .tint(Palette.accent)
                Button {
                    settings.fontSize = min(30, settings.fontSize + 1)
                } label: {
                    fontAdjustButton("A+", small: false)
                }
            }
            .buttonStyle(.plain)
        }
    }

    private func fontAdjustButton(_ title: String, small: Bool) -> some View {
        Text(title)
            .font(.system(size: small ? 13 : 17, weight: .semibold, design: .serif))
            .foregroundStyle(Palette.ink)
            .frame(width: 40, height: 34)
            .background(
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(Color.white.opacity(0.9))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .stroke(Palette.hairline, lineWidth: 1)
            )
    }

    private func sliderRow(
        _ title: String,
        value: Binding<Double>,
        range: ClosedRange<Double>,
        display: String
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title)
                    .font(.system(size: 14, weight: .medium))
                Spacer()
                Text(display)
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Slider(value: value, in: range)
                .tint(Palette.accent)
        }
    }

    // MARK: - 页边距

    private var marginsControl: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("页边距")
                    .font(.system(size: 14, weight: .medium))
                Text("pt")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("恢复默认") {
                    settings.insetTop = 28
                    settings.insetBottom = 28
                    settings.insetLeft = 22
                    settings.insetRight = 22
                }
                .font(.caption.weight(.medium))
                .foregroundStyle(Palette.accent)
            }
            marginRow("上", value: $settings.insetTop, range: 0...90)
            marginRow("下", value: $settings.insetBottom, range: 0...90)
            marginRow("左", value: $settings.insetLeft, range: 0...60)
            marginRow("右", value: $settings.insetRight, range: 0...60)
        }
    }

    private func marginRow(
        _ title: String,
        value: Binding<Double>,
        range: ClosedRange<Double>
    ) -> some View {
        HStack(spacing: 12) {
            Text(title)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Palette.secondaryInk)
                .frame(width: 16, alignment: .leading)
            Slider(value: value, in: range, step: 2)
                .tint(Palette.accent)
            Text("\(Int(value.wrappedValue))")
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)
                .frame(width: 26, alignment: .trailing)
        }
    }

    private var fontControl: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("字体")
                .font(.system(size: 14, weight: .medium))
            HStack(spacing: 10) {
                ForEach(ReaderFontKind.allCases) { kind in
                    Button {
                        settings.fontKind = kind
                    } label: {
                        VStack(spacing: 4) {
                            Text("永")
                                .font(previewFont(kind, size: 20))
                                .foregroundStyle(Palette.ink)
                            Text(kind.title)
                                .font(.system(size: 11))
                                .foregroundStyle(Palette.secondaryInk)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(
                            RoundedRectangle(cornerRadius: 11, style: .continuous)
                                .fill(Color.white.opacity(settings.fontKind == kind ? 0.95 : 0.55))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 11, style: .continuous)
                                .stroke(
                                    settings.fontKind == kind ? Palette.accent : Palette.hairline,
                                    lineWidth: settings.fontKind == kind ? 1.5 : 1
                                )
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func previewFont(_ kind: ReaderFontKind, size: CGFloat) -> Font {
        switch kind {
        case .song: return .custom("Songti SC", size: size)
        case .kai: return .custom("Kaiti SC", size: size)
        case .hei: return .system(size: size, weight: .regular)
        }
    }

    private var themeControl: some View {        VStack(alignment: .leading, spacing: 10) {
            Text("主题")
                .font(.system(size: 14, weight: .medium))
            HStack(spacing: 12) {
                ForEach(ReaderThemeKind.allCases) { kind in
                    Button {
                        settings.theme = kind
                    } label: {
                        VStack(spacing: 6) {
                            Circle()
                                .fill(kind.swiftUIBackground)
                                .overlay(
                                    Circle().stroke(
                                        settings.theme == kind ? Palette.accent : Palette.hairline,
                                        lineWidth: settings.theme == kind ? 2 : 1
                                    )
                                )
                                .frame(width: 34, height: 34)
                                .overlay(
                                    Text("文")
                                        .font(.system(size: 13, weight: .medium, design: .serif))
                                        .foregroundStyle(kind.swiftUIText)
                                )
                            Text(kind.title)
                                .font(.system(size: 11))
                                .foregroundStyle(Palette.secondaryInk)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
