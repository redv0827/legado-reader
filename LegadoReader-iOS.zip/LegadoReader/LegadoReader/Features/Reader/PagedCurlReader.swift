import SwiftUI
import UIKit
import CoreText

// MARK: - 单页画布

/// 只负责把一页正文画出来，供 UIPageViewController 做卷角翻页。
final class PageCanvasView: UIView {
    var attributed: NSAttributedString? {
        didSet { setNeedsDisplay() }
    }
    var pageRange: NSRange? {
        didSet { setNeedsDisplay() }
    }
    var textInsets: UIEdgeInsets = .zero
    var paperColor: UIColor = .white {
        didSet {
            backgroundColor = paperColor
            setNeedsDisplay()
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        isOpaque = true
        contentMode = .redraw
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }
        paperColor.setFill()
        context.fill(bounds)

        guard let attributed, attributed.length > 0, let range = pageRange else { return }
        guard range.location >= 0, range.location + range.length <= attributed.length else { return }

        let size = CGSize(
            width: max(1, bounds.width - textInsets.left - textInsets.right),
            height: max(1, bounds.height - textInsets.top - textInsets.bottom)
        )

        context.saveGState()
        context.textMatrix = .identity
        context.translateBy(x: textInsets.left, y: textInsets.top)
        context.translateBy(x: 0, y: size.height)
        context.scaleBy(x: 1, y: -1)

        let path = CGPath(rect: CGRect(origin: .zero, size: size), transform: nil)
        let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)
        let frame = CTFramesetterCreateFrame(
            framesetter,
            CFRangeMake(range.location, range.length),
            path,
            nil
        )
        CTFrameDraw(frame, context)
        context.restoreGState()
    }
}

// MARK: - 单页控制器

final class PageHostController: UIViewController {
    let index: Int
    let canvas = PageCanvasView()

    init(index: Int) {
        self.index = index
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func loadView() {
        view = canvas
    }
}

/// 章首/章末的空白页。UIPageViewController 的卷角手势在边界处如果拿到 nil
/// 会抛出 NSInternalInconsistencyException 并直接崩溃，所以边界也要给一张
/// 同色纸页，等转场结束后再换章或弹回原位。
final class BoundaryPageController: UIViewController {
    let isLeading: Bool
    let canvas = PageCanvasView()

    init(isLeading: Bool) {
        self.isLeading = isLeading
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func loadView() {
        view = canvas
    }
}

// MARK: - 卷角翻页容器

/// 用 UIKit 的 pageCurl 转场做纸角卷起的仿真翻页：
/// 手指拖住纸角，纸页沿对角卷起来，卷边带阴影，下面露出下一页。
final class CurlPageViewController: UIViewController {

    var onOffsetChange: ((Int) -> Void)?
    var onPageChanged: ((Int, Int) -> Void)?
    var onNextChapter: (() -> Void)?
    var onPreviousChapter: (() -> Void)?
    var onToggleChrome: (() -> Void)?

    /// 正文到页面四边的距离，由阅读设置里的页边距决定。
    var textInsets: UIEdgeInsets = UIEdgeInsets(top: 28, left: 22, bottom: 28, right: 22)
    private let pagerViewController = UIPageViewController(
        transitionStyle: .pageCurl,
        navigationOrientation: .horizontal,
        options: [
            UIPageViewController.OptionsKey.spineLocation:
                UIPageViewController.SpineLocation.min.rawValue
        ]
    )

    private var attributed: NSAttributedString?
    private var paper: UIColor = .white
    private var version = UUID()
    private var pendingOffset = 0

    private var pager: TextPager?
    private var controllers: [Int: PageHostController] = [:]
    private var leadingBoundary: BoundaryPageController?
    private var trailingBoundary: BoundaryPageController?
    private var currentIndex = 0
    private var laidOutSize: CGSize = .zero
    private var needsReload = true
    private var isReloading = false
    private var isTransitioning = false
    private var needsReloadAfterTransition = false
    private var chromeGesture: UITapGestureRecognizer?

    override func loadView() {
        let root = UIView()
        root.backgroundColor = paper
        view = root
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = paper

        addChild(pagerViewController)
        pagerViewController.view.frame = view.bounds
        pagerViewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pagerViewController.view.backgroundColor = paper
        view.addSubview(pagerViewController.view)
        pagerViewController.didMove(toParent: self)

        pagerViewController.dataSource = self
        pagerViewController.delegate = self
        pagerViewController.isDoubleSided = false

        installChromeGesture()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pagerViewController.view.frame = view.bounds
        if view.bounds.size != laidOutSize {
            laidOutSize = view.bounds.size
            needsReload = true
        }
        if needsReload, view.bounds.width > 8, view.bounds.height > 8 {
            reload()
        }
    }

    // MARK: 外部注入

    func update(
        attributed: NSAttributedString?,
        paper: UIColor,
        offset: Int,
        version: UUID,
        insets: UIEdgeInsets
    ) {
        let unchanged = self.version == version
            && self.attributed == attributed
            && self.paper == paper
            && insetsEqual(self.textInsets, insets)
        self.attributed = attributed
        self.paper = paper
        self.version = version
        self.textInsets = insets
        if isViewLoaded {
            view.backgroundColor = paper
            pagerViewController.view.backgroundColor = paper
        }
        if !unchanged {
            pendingOffset = offset
            needsReload = true
            if isViewLoaded, view.bounds.width > 8 { reload() }
        }
    }

    private func insetsEqual(_ a: UIEdgeInsets, _ b: UIEdgeInsets) -> Bool {
        a.top == b.top && a.left == b.left && a.bottom == b.bottom && a.right == b.right
    }

    // MARK: 重排

    private func reload() {
        guard !isReloading else { return }
        guard !isTransitioning, !isPanning else {
            needsReloadAfterTransition = true
            return
        }
        guard let attributed, attributed.length > 0,
              view.bounds.width > 8, view.bounds.height > 8 else { return }
        isReloading = true
        defer { isReloading = false }

        let size = CGSize(
            width: max(1, view.bounds.width - textInsets.left - textInsets.right),
            height: max(1, view.bounds.height - textInsets.top - textInsets.bottom)
        )
        let newPager = TextPager(attributed: attributed, size: size)
        guard newPager.pageCount > 0 else { return }

        pager = newPager
        controllers.removeAll()
        leadingBoundary = nil
        trailingBoundary = nil
        laidOutSize = view.bounds.size

        let start = newPager.pageIndex(for: pendingOffset)
        currentIndex = min(max(start, 0), newPager.pageCount - 1)
        needsReload = false

        let first = controller(at: currentIndex)
        pagerViewController.setViewControllers([first], direction: .forward, animated: false)
        report()
    }

    /// UIPageViewController 的卷角转场中重新 setViewControllers 会抛异常，必须避开。
    private var isPanning: Bool {
        pagerViewController.gestureRecognizers.contains { gesture in
            gesture.state == .began || gesture.state == .changed
        }
    }

    private func controller(at index: Int) -> PageHostController {
        if let cached = controllers[index] { return cached }
        let host = PageHostController(index: index)
        host.canvas.textInsets = textInsets
        host.canvas.paperColor = paper
        host.canvas.attributed = attributed
        host.canvas.pageRange = pager?.range(forPage: index)
        controllers[index] = host
        return host
    }

    private func boundaryController(isLeading: Bool) -> BoundaryPageController {
        if isLeading, let leadingBoundary { return leadingBoundary }
        if !isLeading, let trailingBoundary { return trailingBoundary }
        let boundary = BoundaryPageController(isLeading: isLeading)
        boundary.canvas.paperColor = paper
        boundary.canvas.textInsets = textInsets
        if isLeading {
            leadingBoundary = boundary
        } else {
            trailingBoundary = boundary
        }
        return boundary
    }

    private func report() {
        guard let pager, let range = pager.range(forPage: currentIndex) else { return }
        onOffsetChange?(range.location)
        onPageChanged?(currentIndex + 1, pager.pageCount)
    }

    // MARK: 边界

    /// 中间点击呼出工具栏；左右两侧点一下直接翻一页（翻到章首/章末则换章）。
    private func installChromeGesture() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        tap.delegate = self
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        chromeGesture = tap
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        disableSystemTaps()
    }

    /// 接管点击：关掉系统自带的点按翻页，避免和我们叠加成一次跳两页。
    private func disableSystemTaps() {
        guard let gestures = pagerViewController.view.gestureRecognizers else { return }
        for gesture in gestures where gesture is UITapGestureRecognizer {
            gesture.isEnabled = false
        }
    }

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        let x = gesture.location(in: view).x
        let width = max(view.bounds.width, 1)
        if x < width * 0.3 {
            turnPage(forward: false)
        } else if x > width * 0.7 {
            turnPage(forward: true)
        } else {
            onToggleChrome?()
        }
    }

    func turnPage(forward: Bool) {
        guard !isTransitioning else { return }
        guard let pager else { return }
        let target = currentIndex + (forward ? 1 : -1)
        if target < 0 {
            onPreviousChapter?()
            return
        }
        if target >= pager.pageCount {
            onNextChapter?()
            return
        }
        let host = controller(at: target)
        isTransitioning = true
        pagerViewController.setViewControllers(
            [host],
            direction: forward ? .forward : .reverse,
            animated: true
        ) { [weak self] finished in
            guard let self else { return }
            self.isTransitioning = false
            if finished {
                self.currentIndex = target
                self.report()
            }
            self.runDeferredReloadIfNeeded()
        }
    }

    private func runDeferredReloadIfNeeded() {
        guard needsReloadAfterTransition, !isTransitioning else { return }
        needsReloadAfterTransition = false
        reload()
    }
}

// MARK: - 数据源与转场回调

extension CurlPageViewController: UIPageViewControllerDataSource, UIPageViewControllerDelegate {

    func pageViewController(
        _ pageViewController: UIPageViewController,
        viewControllerBefore viewController: UIViewController
    ) -> UIViewController? {
        guard let host = viewController as? PageHostController, let pager else {
            return nil
        }
        if host.index <= 0 {
            return boundaryController(isLeading: true)
        }
        let target = host.index - 1
        guard pager.range(forPage: target) != nil else {
            return boundaryController(isLeading: true)
        }
        return controller(at: target)
    }

    func pageViewController(
        _ pageViewController: UIPageViewController,
        viewControllerAfter viewController: UIViewController
    ) -> UIViewController? {
        guard let host = viewController as? PageHostController, let pager else {
            return nil
        }
        if host.index >= pager.pageCount - 1 {
            return boundaryController(isLeading: false)
        }
        let target = host.index + 1
        guard pager.range(forPage: target) != nil else {
            return boundaryController(isLeading: false)
        }
        return controller(at: target)
    }

    func pageViewController(
        _ pageViewController: UIPageViewController,
        willTransitionTo pendingViewControllers: [UIViewController]
    ) {
        isTransitioning = true
    }

    func pageViewController(
        _ pageViewController: UIPageViewController,
        didFinishAnimating finished: Bool,
        previousViewControllers: [UIViewController],
        transitionCompleted completed: Bool
    ) {
        isTransitioning = false
        if completed {
            if let host = pageViewController.viewControllers?.first as? PageHostController {
                currentIndex = host.index
                report()
            } else if let boundary = pageViewController.viewControllers?.first as? BoundaryPageController {
                let isLeading = boundary.isLeading
                if let pager, currentIndex >= 0, currentIndex < pager.pageCount {
                    pagerViewController.setViewControllers(
                        [controller(at: currentIndex)],
                        direction: isLeading ? .forward : .reverse,
                        animated: false
                    )
                }
                if isLeading {
                    onPreviousChapter?()
                } else {
                    onNextChapter?()
                }
            }
        }
        runDeferredReloadIfNeeded()
    }
}

// MARK: - 手势代理

extension CurlPageViewController: UIGestureRecognizerDelegate {
    func gestureRecognizer(
        _ gestureRecognizer: UIGestureRecognizer,
        shouldReceive touch: UITouch
    ) -> Bool {
        true
    }
}

// MARK: - SwiftUI 包装

struct PagedCurlReaderView: UIViewControllerRepresentable {
    let attributed: NSAttributedString?
    let renderID: UUID
    let restoreOffset: Int
    let backgroundColor: UIColor
    let insets: UIEdgeInsets
    let onOffsetChange: (Int) -> Void
    let onPageChanged: (Int, Int) -> Void
    let onNextChapter: () -> Void
    let onPreviousChapter: () -> Void
    /// 音量键翻页：command 每次变化就翻一页。
    let turnCommand: Int
    let turnForward: Bool
    let onTap: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIViewController(context: Context) -> CurlPageViewController {
        let controller = CurlPageViewController()
        context.coordinator.lastTurnCommand = turnCommand
        controller.update(
            attributed: attributed,
            paper: backgroundColor,
            offset: restoreOffset,
            version: renderID,
            insets: insets
        )
        bind(controller)
        return controller
    }

    func updateUIViewController(_ controller: CurlPageViewController, context: Context) {
        controller.update(
            attributed: attributed,
            paper: backgroundColor,
            offset: restoreOffset,
            version: renderID,
            insets: insets
        )
        if context.coordinator.lastTurnCommand != turnCommand {
            context.coordinator.lastTurnCommand = turnCommand
            controller.turnPage(forward: turnForward)
        }
        bind(controller)
    }

    private func bind(_ controller: CurlPageViewController) {
        controller.onOffsetChange = onOffsetChange
        controller.onPageChanged = onPageChanged
        controller.onNextChapter = onNextChapter
        controller.onPreviousChapter = onPreviousChapter
        controller.onToggleChrome = onTap
    }

    final class Coordinator {
        var lastTurnCommand = 0
    }
}
