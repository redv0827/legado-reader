import Foundation

/// 阅读器状态机：章节加载、字符偏移进度、上下章切换与预取。
/// 进度使用原文 UTF-16 字符偏移，与服务端和网页版的协议一致，多端可以接续阅读。
@MainActor
final class ReaderController: ObservableObject {
    let api: APIClient
    private let localBook: LocalBook?

    @Published private(set) var book: Book
    @Published private(set) var chapters: [Chapter]
    @Published private(set) var currentIndex: Int = 0
    @Published private(set) var chapterTitle: String = ""
    @Published private(set) var attributed: NSAttributedString?
    @Published private(set) var renderID = UUID()
    @Published private(set) var restoreOffset: Int = 0
    @Published private(set) var isLoading = false
    @Published private(set) var loadingText = "正在加载章节…"
    @Published private(set) var errorMessage: String?
    /// 当前这本是否在书架里，决定阅读器顶部显示「加入书架」还是「已在书架」。
    @Published private(set) var isInShelf = false

    @Published var settings: ReadingSettings
    @Published var showChrome = true
    /// 翻页模式下的「第 x / y 页」，滚动模式为空。
    @Published var pageLabel: String = ""

    private let initialIndex: Int?
    private var started = false
    private var cache: [Int: BookContent] = [:]
    private var currentContent: BookContent?
    private var currentOffset = 0
    private var openAtEnd = false
    private var saveTask: Task<Void, Never>?
    private var prefetchTask: Task<Void, Never>?

    init(book: Book, api: APIClient, chapters: [Chapter], startIndex: Int?) {
        self.book = book
        self.api = api
        self.localBook = nil
        self.chapters = chapters
        self.initialIndex = startIndex
        self.settings = ReadingSettings.load()
        self.restoreOffset = startIndex == nil ? max(0, book.durChapterPos ?? 0) : 0
    }

    /// 本地纯文本文件阅读。
    init(localBook: LocalBook, api: APIClient) {
        self.book = Book(
            bookUrl: "local://" + localBook.id,
            name: localBook.title,
            author: localBook.author,
            origin: "local"
        )
        self.api = api
        self.localBook = localBook
        self.chapters = []
        self.initialIndex = nil
        self.settings = ReadingSettings.load()
        self.restoreOffset = max(0, localBook.chapterOffset)
    }

    var isLocal: Bool { localBook != nil }

    // MARK: - 生命周期

    func start() async {
        guard !started else { return }
        started = true
        isLoading = true

        if let localBook {
            do {
                chapters = try LocalBookStore.shared.chapters(for: localBook)
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
            let index = min(max(localBook.chapterIndex, 0), max(chapters.count - 1, 0))
            await open(index: index, offset: max(0, localBook.chapterOffset))
            return
        }

        // 拉取书架里的最新快照，拿到当前 sourceRevision 与进度。
        let shelf = (try? await api.shelf()) ?? []
        if let fresh = shelf.first(where: { $0.bookUrl == book.bookUrl }) {
            book = fresh
            isInShelf = true
        } else {
            isInShelf = book.inShelf != false
        }

        if chapters.isEmpty {
            do {
                chapters = try await api.chapters(url: book.bookUrl)
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
        }

        let index = initialIndex ?? book.durChapterIndex ?? 0
        let offset = initialIndex == nil ? max(0, book.durChapterPos ?? 0) : 0
        await open(index: index, offset: offset)
    }

    // MARK: - 打开章节

    func open(index: Int, offset: Int) async {
        guard !chapters.isEmpty else { return }
        var target = min(max(index, 0), chapters.count - 1)
        if chapters[target].isTitleOnly {
            target = nextReadableIndex(after: target)
                ?? previousReadableIndex(before: target)
                ?? target
        }
        if chapters[target].isTitleOnly {
            errorMessage = "这一卷只有标题，没有正文。"
            return
        }

        let chapter = chapters[target]
        let sameChapter = currentIndex == chapter.index && currentContent != nil

        currentIndex = chapter.index
        chapterTitle = chapter.title
        errorMessage = nil
        loadingText = "正在加载章节…"

        if !sameChapter {
            isLoading = true
            currentContent = nil
            attributed = nil
            renderID = UUID()
            currentOffset = max(0, offset)
            restoreOffset = currentOffset
        }

        if let localBook {
            do {
                let content = try LocalBookStore.shared.content(for: localBook, chapter: chapter)
                cache[target] = content
                if currentIndex == chapter.index {
                    apply(content)
                }
                isLoading = false
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
        } else if let cached = cache[target] {
            apply(cached)
            isLoading = false
        } else {
            do {
                let content = try await api.content(
                    url: book.bookUrl,
                    index: chapter.index,
                    origin: book.origin,
                    sourceRevision: book.sourceRevision,
                    chapterUrl: chapter.url
                )
                cache[target] = content
                if currentIndex == chapter.index {
                    apply(content)
                }
                isLoading = false
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
        }

        scheduleSave()
        prefetch(index: target + 1)
    }

    func retry() async {
        await open(index: currentIndex, offset: currentOffset)
    }

    // MARK: - 换书源

    /// 把当前书换到另一个来源。服务端负责校验目录与正文并原子替换；
    /// 成功后重新拉目录，按服务端定位到的章节继续读。
    @discardableResult
    func switchSource(to target: Book) async -> String? {
        guard localBook == nil else { return nil }
        let previousBook = book
        isLoading = true
        loadingText = "正在换到 \(target.originName ?? "新书源")…"
        errorMessage = nil
        do {
            let result = try await api.switchSource(bookUrl: book.bookUrl, target: target)
            let newChapters = try await api.chapters(url: result.book.bookUrl)
            book = result.book
            chapters = newChapters
            cache.removeAll()
            currentContent = nil
            attributed = nil
            currentIndex = -1
            chapterTitle = ""
            isLoading = false
            await open(index: result.book.durChapterIndex ?? 0, offset: max(0, result.book.durChapterPos ?? 0))
            let sourceName = result.book.originName ?? target.originName ?? "新书源"
            return result.message ?? "已换到 \(sourceName)"
        } catch {
            book = previousBook
            isLoading = false
            loadingText = "正在加载章节…"
            errorMessage = error.localizedDescription
            return nil
        }
    }

    // MARK: - 书架

    /// 这本书当前是否真的在书架里。以服务端书架列表为准，点书源直接读进来的书不在书架。
    func addToShelf() async -> String? {
        guard localBook == nil else { return nil }
        do {
            let saved = try await api.saveBook(book)
            book = saved
            isInShelf = true
            return "已加入书架，之后从书架点进来就是「\(saved.originName ?? "当前书源")」"
        } catch {
            return error.localizedDescription
        }
    }

    /// 移出书架；正在读的这本会重新记进「可阅读」，进度也照原样写回去，不中断阅读。
    func removeFromShelf() async -> String? {
        guard localBook == nil else { return nil }
        let index = book.durChapterIndex ?? 0
        let position = book.durChapterPos ?? 0
        let title = book.durChapterTitle ?? ""
        do {
            try await api.removeBook(bookUrl: book.bookUrl)
            guard let prepared = try? await api.prepareReading(book) else {
                isInShelf = false
                return "已移出书架"
            }
            book = prepared
            isInShelf = false
            try? await api.saveProgress(
                bookUrl: prepared.bookUrl,
                origin: prepared.origin,
                sourceRevision: prepared.sourceRevision,
                chapterIndex: index,
                chapterOffset: position,
                chapterTitle: title
            )
            return "已移出书架，读到第 \(index + 1) 章的进度保留了"
        } catch {
            return error.localizedDescription
        }
    }

    // MARK: - 章节导航

    func goNext() async {
        guard let target = nextReadableIndex(after: currentIndex) else { return }
        await open(index: target, offset: 0)
    }

    func goPrevious(landingAtEnd: Bool = false) async {
        guard let target = previousReadableIndex(before: currentIndex) else { return }
        openAtEnd = landingAtEnd
        await open(index: target, offset: 0)
        openAtEnd = false
    }

    var canGoNext: Bool { nextReadableIndex(after: currentIndex) != nil }
    var canGoPrevious: Bool { previousReadableIndex(before: currentIndex) != nil }

    var chapterPositionText: String {
        "第 \(currentIndex + 1) / \(max(chapters.count, 1)) 章"
    }

    private func nextReadableIndex(after index: Int) -> Int? {
        var cursor = index + 1
        while cursor < chapters.count {
            if !chapters[cursor].isTitleOnly { return cursor }
            cursor += 1
        }
        return nil
    }

    private func previousReadableIndex(before index: Int) -> Int? {
        var cursor = index - 1
        while cursor >= 0 {
            if !chapters[cursor].isTitleOnly { return cursor }
            cursor -= 1
        }
        return nil
    }

    // MARK: - 排版

    func applySettings(_ newValue: ReadingSettings) {
        settings = newValue
        newValue.save()
        guard let content = currentContent else { return }
        restoreOffset = max(0, currentOffset)
        attributed = ReaderTypography.attributedString(text: displayText(content), settings: newValue)
        renderID = UUID()
    }

    private func apply(_ content: BookContent) {
        currentContent = content
        if !content.title.isEmpty {
            chapterTitle = content.title
        }
        attributed = ReaderTypography.attributedString(text: displayText(content), settings: settings)
        if openAtEnd {
            openAtEnd = false
            let end = max(0, (attributed?.length ?? 1) - 1)
            restoreOffset = end
            currentOffset = end
        }
        renderID = UUID()
    }

    private func displayText(_ content: BookContent) -> String {
        content.content.isEmpty ? "（本章暂无正文）" : content.content
    }

    // MARK: - 进度

    func noteOffset(_ value: Int) {
        guard value >= 0 else { return }
        guard abs(value - currentOffset) >= 2 else { return }
        currentOffset = value
        scheduleSave()
    }

    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            if Task.isCancelled { return }
            await self?.saveProgress()
        }
    }

    func saveProgress() async {
        if let localBook {
            let title = chapters.first(where: { $0.index == currentIndex })?.title ?? chapterTitle
            LocalBookStore.shared.updateProgress(
                bookId: localBook.id,
                chapterIndex: currentIndex,
                chapterOffset: max(0, currentOffset),
                chapterTitle: title
            )
            return
        }
        guard let chapter = chapters.first(where: { $0.index == currentIndex }) else { return }
        do {
            try await api.saveProgress(
                bookUrl: book.bookUrl,
                origin: book.origin,
                sourceRevision: book.sourceRevision,
                chapterIndex: chapter.index,
                chapterOffset: max(0, currentOffset),
                chapterTitle: chapter.title
            )
        } catch {
            // 进度保存失败不打断阅读；下次滚动会再次尝试。
        }
    }

    func flush() async {
        saveTask?.cancel()
        prefetchTask?.cancel()
        await saveProgress()
    }

    // MARK: - 预取

    private func prefetch(index: Int) {
        guard localBook == nil else { return }
        guard index >= 0, index < chapters.count, !chapters[index].isTitleOnly, cache[index] == nil else { return }
        let chapter = chapters[index]
        prefetchTask?.cancel()
        prefetchTask = Task { [weak self] in
            guard let self else { return }
            guard let content = try? await self.api.content(
                url: self.book.bookUrl,
                index: chapter.index,
                origin: self.book.origin,
                sourceRevision: self.book.sourceRevision,
                chapterUrl: chapter.url
            ) else { return }
            if Task.isCancelled { return }
            self.cache[index] = content
        }
    }
}
