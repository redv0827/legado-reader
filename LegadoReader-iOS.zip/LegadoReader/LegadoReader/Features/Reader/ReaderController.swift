import Foundation

/// 整本离线下载的状态。
enum DownloadPhase: Equatable {
    case idle
    case running
    case done
    case failed(String)
}

/// 阅读器状态机：章节加载、字符偏移进度、上下章切换与预取。
/// 进度使用原文 UTF-16 字符偏移，与服务端和网页版的协议一致，多端可以接续阅读。
@MainActor
final class ReaderController: ObservableObject {
    let api: APIClient
    private let localBook: LocalBook?

    @Published private(set) var book: Book
    @Published private(set) var chapters: [Chapter]
    @Published private(set) var currentIndex: Int = 0
    @Published private(set) var chapterTitle: String = ""
    @Published private(set) var attributed: NSAttributedString?
    @Published private(set) var renderID = UUID()
    @Published private(set) var restoreOffset: Int = 0
    @Published private(set) var isLoading = false
    @Published private(set) var loadingText = "正在加载章节…"
    @Published private(set) var errorMessage: String?
    /// 当前这本是否在书架里，决定阅读器顶部显示「加入书架」还是「已在书架」。
    @Published private(set) var isInShelf = false

    @Published var settings: ReadingSettings
    @Published var showChrome = true
    /// 翻页模式下的「第 x / y 页」，滚动模式为空。
    @Published var pageLabel: String = ""

    /// 整本离线下载：进度和状态。
    @Published private(set) var downloadPhase: DownloadPhase = .idle
    @Published private(set) var downloadDone = 0
    @Published private(set) var downloadTotal = 0

    private let initialIndex: Int?
    private var started = false
    private var cache: [Int: BookContent] = [:]
    private var currentContent: BookContent?
    /// 当前这章的排版结果，用来在「渲染偏移」和「原文偏移」之间换算。
    private var layout: ReaderLayout?
    private var currentOffset = 0
    private var openAtEnd = false
    private var saveTask: Task<Void, Never>?
    /// 每章独立一支预取任务，互不打断；失败的章节最多重试 3 次。
    private var prefetchTasks: [Int: Task<Void, Never>] = [:]
    private var prefetchFailures: [Int: Int] = [:]
    /// 阅读计时：从哪一刻开始算，每 5 秒结算一次并累计到本地统计里。
    private var activeSince: Date?
    private var timingTask: Task<Void, Never>?
    /// 整本离线下载的任务，退出阅读器或换书时取消。
    private var downloadTask: Task<Void, Never>?

    init(book: Book, api: APIClient, chapters: [Chapter], startIndex: Int?) {
        self.book = book
        self.api = api
        self.localBook = nil
        self.chapters = chapters
        self.initialIndex = startIndex
        self.settings = ReadingSettings.load()
        self.restoreOffset = startIndex == nil ? max(0, book.durChapterPos ?? 0) : 0
    }

    /// 本地纯文本文件阅读。
    init(localBook: LocalBook, api: APIClient) {
        self.book = Book(
            bookUrl: "local://" + localBook.id,
            name: localBook.title,
            author: localBook.author,
            origin: "local"
        )
        self.api = api
        self.localBook = localBook
        self.chapters = []
        self.initialIndex = nil
        self.settings = ReadingSettings.load()
        self.restoreOffset = max(0, localBook.chapterOffset)
    }

    var isLocal: Bool { localBook != nil }

    // MARK: - 生命周期

    func start() async {
        guard !started else { return }
        started = true
        beginTiming()
        isLoading = true

        if let localBook {
            do {
                chapters = try LocalBookStore.shared.chapters(for: localBook)
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
            let index = min(max(localBook.chapterIndex, 0), max(chapters.count - 1, 0))
            await open(index: index, offset: max(0, localBook.chapterOffset))
            return
        }

        // 拉取书架里的最新快照，拿到当前 sourceRevision 与进度。
        let shelf = (try? await api.shelf()) ?? []
        if let fresh = shelf.first(where: { $0.bookUrl == book.bookUrl }) {
            book = fresh
            isInShelf = true
        } else {
            isInShelf = book.inShelf != false
        }

        if chapters.isEmpty {
            do {
                chapters = try await api.chapters(url: book.bookUrl)
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
        }

        let index = initialIndex ?? book.durChapterIndex ?? 0
        let offset = initialIndex == nil ? max(0, book.durChapterPos ?? 0) : 0
        await open(index: index, offset: offset)
    }

    // MARK: - 打开章节

    func open(index: Int, offset: Int) async {
        guard !chapters.isEmpty else { return }
        var target = min(max(index, 0), chapters.count - 1)
        if chapters[target].isTitleOnly {
            target = nextReadableIndex(after: target)
                ?? previousReadableIndex(before: target)
                ?? target
        }
        if chapters[target].isTitleOnly {
            errorMessage = "这一卷只有标题，没有正文。"
            return
        }

        let chapter = chapters[target]
        let sameChapter = currentIndex == chapter.index && currentContent != nil

        currentIndex = chapter.index
        chapterTitle = chapter.title
        errorMessage = nil
        loadingText = "正在加载章节…"

        if !sameChapter {
            isLoading = true
            currentContent = nil
            attributed = nil
            renderID = UUID()
            currentOffset = max(0, offset)
            restoreOffset = currentOffset
        }

        if let localBook {
            do {
                let content = try LocalBookStore.shared.content(for: localBook, chapter: chapter)
                cache[target] = content
                if currentIndex == chapter.index {
                    apply(content)
                }
                isLoading = false
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
        } else if let cached = cache[target] {
            apply(cached)
            isLoading = false
        } else if let offline = OfflineStore.shared.content(bookURL: book.bookUrl, index: chapter.index) {
            // 整本下载过的章优先走本地，断网也能翻。
            cache[target] = offline
            apply(offline)
            isLoading = false
        } else {
            do {
                let content = try await api.content(
                    url: book.bookUrl,
                    index: chapter.index,
                    origin: book.origin,
                    sourceRevision: book.sourceRevision,
                    chapterUrl: chapter.url
                )
                cache[target] = content
                if currentIndex == chapter.index {
                    apply(content)
                }
                isLoading = false
            } catch {
                errorMessage = error.localizedDescription
                isLoading = false
                return
            }
        }

        scheduleSave()
        prefetch(index: nextReadableIndex(after: target) ?? (target + 1))
    }

    func retry() async {
        await open(index: currentIndex, offset: currentOffset)
    }

    // MARK: - 换书源

    /// 把当前书换到另一个来源。服务端负责校验目录与正文并原子替换；
    /// 成功后重新拉目录，按服务端定位到的章节继续读。
    @discardableResult
    func switchSource(to target: Book) async -> String? {
        guard localBook == nil else { return nil }
        let previousBook = book
        isLoading = true
        loadingText = "正在换到 \(target.originName ?? "新书源")…"
        errorMessage = nil
        do {
            let result = try await api.switchSource(bookUrl: book.bookUrl, target: target)
            let newChapters = try await api.chapters(url: result.book.bookUrl)
            // 换源之后旧 bookUrl 下的离线正文没人认领，顺手清掉，别让它一直占空间。
            OfflineStore.shared.clear(bookURL: previousBook.bookUrl)
            CoverStore.shared.forget(previousBook.bookUrl)
            book = result.book
            chapters = newChapters
            cache.removeAll()
            currentContent = nil
            layout = nil
            attributed = nil
            currentIndex = -1
            chapterTitle = ""
            isLoading = false
            await open(index: result.book.durChapterIndex ?? 0, offset: max(0, result.book.durChapterPos ?? 0))
            let sourceName = result.book.originName ?? target.originName ?? "新书源"
            return result.message ?? "已换到 \(sourceName)"
        } catch {
            book = previousBook
            isLoading = false
            loadingText = "正在加载章节…"
            errorMessage = error.localizedDescription
            return nil
        }
    }

    // MARK: - 书架

    /// 这本书当前是否真的在书架里。以服务端书架列表为准，点书源直接读进来的书不在书架。
    func addToShelf() async -> String? {
        guard localBook == nil else { return nil }
        do {
            let saved = try await api.saveBook(book)
            book = saved
            isInShelf = true
            NotificationCenter.default.post(name: .liubaiShelfChanged, object: nil)
            return "已加入书架，之后从书架点进来就是「\(saved.originName ?? "当前书源")」"
        } catch {
            return error.localizedDescription
        }
    }

    /// 移出书架；正在读的这本会重新记进「可阅读」，进度也照原样写回去，不中断阅读。
    func removeFromShelf() async -> String? {
        guard localBook == nil else { return nil }
        let index = book.durChapterIndex ?? 0
        let position = book.durChapterPos ?? 0
        let title = book.durChapterTitle ?? ""
        do {
            try await api.removeBook(bookUrl: book.bookUrl)
            guard let prepared = try? await api.prepareReading(book) else {
                isInShelf = false
                return "已移出书架"
            }
            book = prepared
            isInShelf = false
            NotificationCenter.default.post(name: .liubaiShelfChanged, object: nil)
            try? await api.saveProgress(
                bookUrl: prepared.bookUrl,
                origin: prepared.origin,
                sourceRevision: prepared.sourceRevision,
                chapterIndex: index,
                chapterOffset: position,
                chapterTitle: title
            )
            return "已移出书架，读到第 \(index + 1) 章的进度保留了"
        } catch {
            return error.localizedDescription
        }
    }

    // MARK: - 章节导航

    func goNext() async {
        guard let target = nextReadableIndex(after: currentIndex) else { return }
        await open(index: target, offset: 0)
    }

    func goPrevious(landingAtEnd: Bool = false) async {
        guard let target = previousReadableIndex(before: currentIndex) else { return }
        openAtEnd = landingAtEnd
        await open(index: target, offset: 0)
        openAtEnd = false
    }

    var canGoNext: Bool { nextReadableIndex(after: currentIndex) != nil }
    var canGoPrevious: Bool { previousReadableIndex(before: currentIndex) != nil }

    var chapterPositionText: String {
        "第 \(currentIndex + 1) / \(max(chapters.count, 1)) 章"
    }

    private func nextReadableIndex(after index: Int) -> Int? {
        var cursor = index + 1
        while cursor < chapters.count {
            if !chapters[cursor].isTitleOnly { return cursor }
            cursor += 1
        }
        return nil
    }

    private func previousReadableIndex(before index: Int) -> Int? {
        var cursor = index - 1
        while cursor >= 0 {
            if !chapters[cursor].isTitleOnly { return cursor }
            cursor -= 1
        }
        return nil
    }

    // MARK: - 排版

    func applySettings(_ newValue: ReadingSettings) {
        settings = newValue
        newValue.save()
        guard let content = currentContent else { return }
        let newLayout = ReaderTypography.layout(text: displayText(content), settings: newValue)
        layout = newLayout
        attributed = newLayout.attributed
        restoreOffset = newLayout.renderOffset(forSource: max(0, currentOffset))
        renderID = UUID()
    }

    private func apply(_ content: BookContent) {
        currentContent = content
        if !content.title.isEmpty {
            chapterTitle = content.title
        }
        let newLayout = ReaderTypography.layout(text: displayText(content), settings: settings)
        layout = newLayout
        attributed = newLayout.attributed
        if openAtEnd {
            openAtEnd = false
            let end = max(0, newLayout.attributed.length - 1)
            restoreOffset = end
            currentOffset = newLayout.sourceOffset(forRender: end)
        } else {
            restoreOffset = newLayout.renderOffset(forSource: max(0, currentOffset))
        }
        renderID = UUID()
    }

    private func displayText(_ content: BookContent) -> String {
        content.content.isEmpty ? "（本章暂无正文）" : content.content
    }

    // MARK: - 进度

    func noteOffset(_ value: Int) {
        guard value >= 0 else { return }
        // 页面报上来的是渲染偏移，存进度要用原文偏移。
        let source = layout?.sourceOffset(forRender: value) ?? value
        guard abs(source - currentOffset) >= 2 else { return }
        currentOffset = source
        scheduleSave()
        prefetchNextWhenNearEnd(offset: source)
    }

    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            if Task.isCancelled { return }
            await self?.saveProgress()
        }
    }

    func saveProgress() async {
        if let localBook {
            let title = chapters.first(where: { $0.index == currentIndex })?.title ?? chapterTitle
            LocalBookStore.shared.updateProgress(
                bookId: localBook.id,
                chapterIndex: currentIndex,
                chapterOffset: max(0, currentOffset),
                chapterTitle: title
            )
            return
        }
        guard let chapter = chapters.first(where: { $0.index == currentIndex }) else { return }
        do {
            try await api.saveProgress(
                bookUrl: book.bookUrl,
                origin: book.origin,
                sourceRevision: book.sourceRevision,
                chapterIndex: chapter.index,
                chapterOffset: max(0, currentOffset),
                chapterTitle: chapter.title
            )
        } catch {
            // 进度保存失败不打断阅读；下次滚动会再次尝试。
        }
    }

    func flush() async {
        saveTask?.cancel()
        downloadTask?.cancel()
        downloadTask = nil
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        endTiming()
        await saveProgress()
    }

    // MARK: - 阅读时长

    private var statsKey: String {
        if let localBook { return ReadingStatsStore.key(localID: localBook.id) }
        return ReadingStatsStore.key(bookURL: book.bookUrl)
    }

    /// 记时长时顺手把书名写进统计表，统计明细里就不用再查书架。
    private var statsName: String {
        if let localBook { return localBook.title }
        return book.name
    }

    /// 进入前台开始计时；后台或退出时用 endTiming 收口。
    func beginTiming() {
        guard activeSince == nil else { return }
        activeSince = Date()
        timingTask?.cancel()
        timingTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 5_000_000_000)
                if Task.isCancelled { return }
                self?.commitTiming()
            }
        }
    }

    func endTiming() {
        timingTask?.cancel()
        timingTask = nil
        commitTiming()
        activeSince = nil
        ReadingStatsStore.shared.flush()
    }

    private func commitTiming() {
        guard let start = activeSince else { return }
        let delta = Date().timeIntervalSince(start)
        activeSince = Date()
        // 超过 10 分钟的间隔当成系统休眠/锁屏回来，不计入。
        guard delta > 0, delta < 600 else { return }
        ReadingStatsStore.shared.add(delta, for: statsKey, name: statsName)
    }

    // MARK: - 预取

    private func prefetch(index: Int) {
        guard localBook == nil else { return }
        guard index >= 0, index < chapters.count, !chapters[index].isTitleOnly, cache[index] == nil else { return }
        if prefetchTasks[index] != nil { return }
        guard (prefetchFailures[index] ?? 0) < 3 else { return }
        if let offline = OfflineStore.shared.content(bookURL: book.bookUrl, index: index) {
            cache[index] = offline
            return
        }
        let chapter = chapters[index]
        let target = book
        prefetchTasks[index] = Task { [weak self] in
            guard let self else { return }
            do {
                let content = try await self.api.content(
                    url: target.bookUrl,
                    index: chapter.index,
                    origin: target.origin,
                    sourceRevision: target.sourceRevision,
                    chapterUrl: chapter.url
                )
                if !Task.isCancelled {
                    self.cache[index] = content
                }
            } catch {
                self.prefetchFailures[index] = (self.prefetchFailures[index] ?? 0) + 1
            }
            self.prefetchTasks[index] = nil
        }
    }

    /// 读到本章 60% 之后，把后面两章都拉好（本章已有一章的预取，这里是补第二跳），
    /// 连翻两三章也不用转圈。
    private func prefetchNextWhenNearEnd(offset: Int) {
        guard localBook == nil, let content = currentContent else { return }
        let total = displayText(content).utf16.count
        guard total > 0, offset > Int(Double(total) * 0.6) else { return }
        let next = nextReadableIndex(after: currentIndex) ?? (currentIndex + 1)
        prefetch(index: next)
        prefetch(index: nextReadableIndex(after: next) ?? (next + 1))
    }

    // MARK: - 整本离线

    var isDownloading: Bool { downloadPhase == .running }

    /// 把整本按章拉到本地：已有离线文件的章跳过，单章失败不中断整本。
    func startDownloadAll() {
        guard localBook == nil, downloadTask == nil else { return }
        guard !chapters.isEmpty else {
            downloadPhase = .failed("目录还没加载好")
            return
        }
        let targets = chapters.filter { !$0.isTitleOnly }
        guard !targets.isEmpty else { return }
        let targetBook = book
        OfflineStore.shared.keep(bookURL: targetBook.bookUrl, name: targetBook.name)
        downloadTotal = targets.count
        downloadDone = OfflineStore.shared.downloadedCount(bookURL: targetBook.bookUrl)
        downloadPhase = .running
        downloadTask = Task { [weak self] in
            guard let self else { return }
            for chapter in targets {
                if Task.isCancelled { break }
                if OfflineStore.shared.hasChapter(bookURL: targetBook.bookUrl, index: chapter.index) {
                    continue
                }
                do {
                    let content = try await self.api.content(
                        url: targetBook.bookUrl,
                        index: chapter.index,
                        origin: targetBook.origin,
                        sourceRevision: targetBook.sourceRevision,
                        chapterUrl: chapter.url
                    )
                    OfflineStore.shared.save(content, bookURL: targetBook.bookUrl, index: chapter.index)
                    self.cache[chapter.index] = content
                    self.downloadDone += 1
                } catch {
                    // 这一章抓不到就跳过，别让整本停下来。
                }
                // 每章之间歇 0.15 秒，别把源站打爆
                try? await Task.sleep(nanoseconds: 150_000_000)
            }
            self.downloadPhase = Task.isCancelled ? .idle : .done
            self.downloadTask = nil
        }
    }

    func cancelDownload() {
        downloadTask?.cancel()
        downloadTask = nil
        downloadPhase = .idle
    }
}
