import UIKit
import AVFoundation
import MediaPlayer

/// 音量键翻页。
///
/// 用一个隐藏的 MPVolumeView 接管系统音量 HUD，监听系统音量变化：
/// 变大当下一页、变小当上一页，然后把音量悄悄拨回原值，用户感觉不到声音在变。
final class VolumeKeyPager: NSObject, ObservableObject {
    /// 每按一次音量键 +1，配合 forward 一起看。
    @Published private(set) var command: Int = 0
    @Published private(set) var forward: Bool = true

    private let volumeView = MPVolumeView(frame: CGRect(x: -2000, y: -2000, width: 1, height: 1))
    private var observation: NSKeyValueObservation?
    private var baseline: Float = 0.5
    private var isResetting = false

    func start() {
        guard observation == nil else { return }
        let session = AVAudioSession.sharedInstance()
        try? session.setActive(true, options: [])
        baseline = session.outputVolume
        volumeView.showsRouteButton = false
        volumeView.isHidden = false
        volumeView.alpha = 0.02
        if let window = Self.keyWindow() {
            window.addSubview(volumeView)
        }
        observation = session.observe(\.outputVolume, options: [.new]) { [weak self] _, change in
            guard let value = change.newValue else { return }
            DispatchQueue.main.async { self?.handle(value) }
        }
    }

    func stop() {
        observation = nil
        volumeView.removeFromSuperview()
        try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
    }

    private func handle(_ value: Float) {
        if isResetting {
            isResetting = false
            return
        }
        guard abs(value - baseline) > 0.02 else { return }
        forward = value > baseline
        command += 1
        resetVolume()
    }

    /// 拨回原音量。不这么做的话，按键一次读一整章，音量就被拧到最大或静音。
    private func resetVolume() {
        DispatchQueue.main.async { [weak self] in
            guard let self, let slider = self.volumeSlider(in: self.volumeView) else { return }
            self.isResetting = true
            slider.setValue(self.baseline, animated: false)
        }
    }

    private func volumeSlider(in view: UIView) -> UISlider? {
        if let slider = view as? UISlider { return slider }
        for subview in view.subviews {
            if let found = volumeSlider(in: subview) { return found }
        }
        return nil
    }

    private static func keyWindow() -> UIWindow? {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
    }
}
