import Foundation
import SwiftUI

/// 搜索结果里每个书源的「共多少章 / 最新章节」。
///
/// 搜索接口本身只回书名作者简介，章数和最新章要靠目录才知道，所以这里按需探一次
/// `/api/book/details`（服务端会顺手把目录也取回来），结果在内存里存 10 分钟，
/// 并发压在 3 个以内，避免一次把上百个源同时打出去。
final class SourceChapterProbe: ObservableObject {
    struct Stat {
        var total: Int?
        var lastChapter: String
        var failed: Bool
        var at: Date
    }

    static let shared = SourceChapterProbe()

    @Published private(set) var stats: [String: Stat] = [:]

    private var inFlight = Set<String>()
    private let gate = ProbeGate(limit: 2)
    private let ttl: TimeInterval = 900

    /// 列表滚到某一行时调用：只探测这家书还没拿到目录的源。
    func load(_ books: [Book], api: APIClient) {
        let now = Date()
        for book in books {
            let key = book.bookUrl
            guard !key.isEmpty, !inFlight.contains(key) else { continue }
            if let stat = stats[key], now.timeIntervalSince(stat.at) < ttl, !stat.failed { continue }
            inFlight.insert(key)
            Task { @MainActor in
                // 让位给用户正在点的书源：先等一小会儿再慢慢补章数。
                try? await Task.sleep(nanoseconds: 900_000_000)
                await self.probe(book, key: key, api: api)
            }
        }
    }

    private func probe(_ book: Book, key: String, api: APIClient) async {
        await gate.acquire()
        let result = try? await api.bookDetails(book)
        await gate.release()
        inFlight.remove(key)
        if let result {
            let readable = result.chapters.filter { !$0.isTitleOnly }
            stats[key] = Stat(
                total: result.book.totalChapterNum ?? readable.count,
                lastChapter: readable.last?.title ?? book.lastChapterHint,
                failed: false,
                at: Date()
            )
        } else {
            stats[key] = Stat(
                total: book.totalChapterNum,
                lastChapter: book.lastChapterHint,
                failed: true,
                at: Date()
            )
        }
    }
}

/// 只发 N 个并发的闸门。
actor ProbeGate {
    private let limit: Int
    private var active = 0
    private var waiters: [CheckedContinuation<Void, Never>] = []

    init(limit: Int) { self.limit = limit }

    func acquire() async {
        if active < limit {
            active += 1
            return
        }
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            waiters.append(continuation)
        }
        active += 1
    }

    func release() {
        active = max(0, active - 1)
        if !waiters.isEmpty {
            waiters.removeFirst().resume()
        }
    }
}
