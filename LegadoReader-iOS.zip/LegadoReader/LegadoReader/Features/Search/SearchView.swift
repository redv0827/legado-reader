import SwiftUI

struct SearchGroup: Identifiable, Hashable {
    var id: String
    var name: String
    var author: String
    var books: [Book]
}

struct SearchView: View {
    @EnvironmentObject private var session: AppSession

    @State private var query = ""
    @State private var groups: [SearchGroup] = []
    @State private var sources: [BookSourceSummary] = []
    @State private var selectedSourceURL: String?
    @State private var isSearching = false
    @State private var hasSearched = false
    @State private var progress: SearchProgress?
    @State private var sourceErrors: [SearchError] = []
    @State private var errorMessage: String?
    @State private var searchTask: Task<Void, Never>?
    @State private var showErrors = false
    @State private var showSourceManage = false
    @State private var history: [String] = SearchHistory.load()

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                content
            }
            .navigationTitle("找书")
            .searchable(text: $query, prompt: "书名或作者")
            .onSubmit(of: .search) { startSearch() }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    if session.user?.isAdmin == true {
                        Button {
                            showSourceManage = true
                        } label: {
                            Image(systemName: "books.vertical")
                                .foregroundStyle(Palette.ink)
                        }
                        .accessibilityLabel("书源管理")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    sourceMenu
                }
            }
            .task { await loadSources() }
            .sheet(isPresented: $showSourceManage) {
                SourceHealthView()
            }
            .navigationDestination(for: Book.self) { book in
                BookDetailView(book: book)
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if isSearching {
                    searchingHeader
                } else if let errorMessage {
                    ErrorBanner(message: errorMessage)
                }

                if groups.isEmpty {
                    if hasSearched && !isSearching {
                        EmptyStateView(
                            icon: "text.magnifyingglass",
                            title: "没有找到这本书",
                            message: "换个关键词，或检查书源是否启用。\n搜索只使用已启用的书源。"
                        )
                    } else if !hasSearched {
                        if !history.isEmpty {
                            historyCard
                        }
                        hint
                    }
                } else {
                    ForEach(groups) { group in
                        if let book = group.books.first {
                            NavigationLink(value: book) {
                                SearchResultRow(group: group, coverURL: session.api.resolve(book.coverUrl))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    if !sourceErrors.isEmpty {
                        Button {
                            showErrors = true
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "exclamationmark.circle")
                                Text("\(sourceErrors.count) 个书源失败，查看原因")
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption)
                            }
                            .font(.footnote)
                            .foregroundStyle(Palette.secondaryInk)
                            .padding(.vertical, 8)
                        }
                    }
                    Text("共 \(groups.count) 本 · 结果按书名与作者合并")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk.opacity(0.7))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 4)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
        }
        .scrollDismissesKeyboard(.immediately)
        .sheet(isPresented: $showErrors) {
            SourceErrorSheet(errors: sourceErrors)
        }
    }

    private var historyCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 9) {
                HStack {
                    Text("最近搜索")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    Text("\(history.count)/\(SearchHistory.limit)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                }

                ForEach(history, id: \.self) { item in
                    HStack(spacing: 8) {
                        Button {
                            query = item
                            startSearch()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "clock")
                                    .font(.caption2)
                                    .foregroundStyle(Palette.secondaryInk)
                                Text(item)
                                    .font(.system(size: 13))
                                    .foregroundStyle(Palette.ink)
                                    .lineLimit(1)
                                Spacer(minLength: 0)
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)

                        Button {
                            history = SearchHistory.remove(item)
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(Palette.secondaryInk.opacity(0.55))
                        }
                        .buttonStyle(.plain)
                    }
                    if item != history.last {
                        Divider()
                    }
                }
            }
        }
    }

    private var hint: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("搜索由服务端逐源执行")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Text("结果会随着书源返回陆续出现，进度条显示已完成的书源数量。\n多个书源出现同名同作者的书会自动合并成一张卡片。")
                .font(.footnote)
                .foregroundStyle(Palette.secondaryInk)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 6) {
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .font(.caption)
                Text("已启用书源：\(sources.filter { $0.enabled ?? true }.count) 个")
                    .font(.caption)
            }
            .foregroundStyle(Palette.accent)

            if session.user?.isAdmin == true {
                Divider()
                Button {
                    showSourceManage = true
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "books.vertical")
                        Text("书源管理")
                            .font(.footnote.weight(.medium))
                        Spacer()
                        Text("检测 · 添加 · 去重")
                            .font(.caption2)
                            .foregroundStyle(Palette.secondaryInk)
                        Image(systemName: "chevron.right")
                            .font(.caption2)
                            .foregroundStyle(Palette.secondaryInk)
                    }
                    .foregroundStyle(Palette.accent)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.white.opacity(0.7))
        )
    }

    private var searchingHeader: some View {
        Card(padding: 14) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("正在搜索「\(query)」")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                    Spacer()
                    Button("停止") { stopSearch() }
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(Palette.accent)
                }
                if let progress {
                    ProgressView(value: progress.fraction)
                        .tint(Palette.accent)
                    Text("已完成 \(progress.completed)/\(progress.total) 个书源 · 找到 \(groups.count) 本 · 失败 \(progress.failed)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    ProgressView().tint(Palette.accent)
                }
            }
        }
    }

    private var sourceMenu: some View {
        Menu {
            Button {
                selectedSourceURL = nil
                if hasSearched { startSearch() }
            } label: {
                if selectedSourceURL == nil {
                    Label("全部已启用书源", systemImage: "checkmark")
                } else {
                    Text("全部已启用书源")
                }
            }
            ForEach(sources.filter { ($0.enabled ?? true) && !$0.isArchived }) { source in
                Button {
                    selectedSourceURL = source.bookSourceUrl
                    if hasSearched { startSearch() }
                } label: {
                    if selectedSourceURL == source.bookSourceUrl {
                        Label(source.bookSourceName, systemImage: "checkmark")
                    } else {
                        Text(source.bookSourceName)
                    }
                }
            }
        } label: {
            Image(systemName: "line.3.horizontal.decrease.circle")
                .foregroundStyle(Palette.ink)
        }
    }

    // MARK: - 数据

    private func loadSources() async {
        do {
            sources = try await session.api.sources()
        } catch {
            // 书源列表失败不阻塞搜索，搜索时会返回具体错误。
        }
    }

    private func startSearch() {
        let key = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        history = SearchHistory.add(key)
        searchTask?.cancel()
        session.api.cancelSearch()
        withAnimation(.easeInOut(duration: 0.2)) {
            groups = []
            sourceErrors = []
            progress = nil
            errorMessage = nil
            isSearching = true
            hasSearched = true
        }
        let source = selectedSourceURL
        searchTask = Task { @MainActor in
            do {
                for try await event in session.api.searchEvents(key: key, sourceUrl: source) {
                    if Task.isCancelled { break }
                    handle(event)
                }
            } catch {
                if !Task.isCancelled {
                    errorMessage = error.localizedDescription
                }
            }
            isSearching = false
            progress = nil
        }
    }

    private func stopSearch() {
        searchTask?.cancel()
        session.api.cancelSearch()
        isSearching = false
    }

    private func handle(_ event: SearchEvent) {
        if let progress = event.progress {
            self.progress = progress
        }
        switch event.type {
        case "source":
            if let books = event.books, !books.isEmpty {
                merge(books)
            }
            if let error = event.error {
                sourceErrors.append(error)
            }
        case "done":
            isSearching = false
            progress = nil
        default:
            break
        }
    }

    private func merge(_ books: [Book]) {
        for book in books {
            let key = book.name.trimmingCharacters(in: .whitespacesAndNewlines) + "|" + book.author
            if let index = groups.firstIndex(where: { $0.id == key }) {
                if !groups[index].books.contains(where: { $0.bookUrl == book.bookUrl }) {
                    groups[index].books.append(book)
                }
            } else {
                groups.append(SearchGroup(id: key, name: book.name, author: book.author, books: [book]))
            }
        }
    }
}

// MARK: - 结果行

struct SearchResultRow: View {
    let group: SearchGroup
    let coverURL: URL?

    var body: some View {
        HStack(spacing: 14) {
            BookCoverView(
                book: group.books.first ?? Book(bookUrl: "", name: group.name, origin: ""),
                coverURL: coverURL
            )
            .frame(width: 52)
            VStack(alignment: .leading, spacing: 5) {
                Text(group.name)
                    .font(.system(size: 16, weight: .medium, design: .serif))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(1)
                Text(group.author.isEmpty ? "佚名" : group.author)
                    .font(.caption)
                    .foregroundStyle(Palette.secondaryInk)
                    .lineLimit(1)
                HStack(spacing: 6) {
                    Text("\(group.books.count) 个书源")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(Palette.accent)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Capsule().fill(Palette.accent.opacity(0.1)))
                    if let kind = group.books.first?.kind, !kind.isEmpty {
                        Text(kind)
                            .font(.system(size: 10))
                            .foregroundStyle(Palette.secondaryInk)
                            .lineLimit(1)
                    }
                }
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Palette.secondaryInk.opacity(0.6))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.white.opacity(0.68))
        )
    }
}

struct SourceErrorSheet: View {
    let errors: [SearchError]
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List(errors, id: \.self) { error in
                VStack(alignment: .leading, spacing: 4) {
                    Text(error.source)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                    Text(error.message)
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                }
                .padding(.vertical, 4)
            }
            .navigationTitle("失败的书源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

// MARK: - 搜索记录

/// 本地保存最近搜索关键词，最多 20 条，重复词提到最前。
enum SearchHistory {
    static let limit = 20
    private static let storageKey = "liubai.searchHistory"

    static func load() -> [String] {
        UserDefaults.standard.stringArray(forKey: storageKey) ?? []
    }

    @discardableResult
    static func add(_ keyword: String) -> [String] {
        let trimmed = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return load() }
        var list = load().filter { $0 != trimmed }
        list.insert(trimmed, at: 0)
        if list.count > limit { list = Array(list.prefix(limit)) }
        UserDefaults.standard.set(list, forKey: storageKey)
        return list
    }

    @discardableResult
    static func remove(_ keyword: String) -> [String] {
        var list = load()
        list.removeAll { $0 == keyword }
        UserDefaults.standard.set(list, forKey: storageKey)
        return list
    }
}
