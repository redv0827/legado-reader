import SwiftUI

struct SearchGroup: Identifiable, Hashable {
    var id: String
    var name: String
    var author: String
    var books: [Book]
}

struct SearchView: View {
    @EnvironmentObject private var session: AppSession

    @State private var query = ""
    @State private var groups: [SearchGroup] = []
    @State private var sources: [BookSourceSummary] = []
    /// 服务端 enabled 快照，配合本地覆盖表算出生效的开关状态。
    @State private var serverEnabled: [String: Bool] = [:]
    @State private var selectedSourceURL: String?
    @State private var isSearching = false
    @State private var hasSearched = false
    @State private var progress: SearchProgress?
    @State private var sourceErrors: [SearchError] = []
    @State private var errorMessage: String?
    @State private var searchTask: Task<Void, Never>?
    @State private var showErrors = false
    @State private var showSourceManage = false
    @State private var history: [String] = SearchHistory.load()
    /// 本次搜索实际使用的关键词，避免搜索中改输入框导致精确/模糊分区错乱。
    @State private var activeKey = ""
    /// 触发上限自动暂停时的提示。
    @State private var pauseMessage: String?
    /// 点「继续搜索」后，上限在已有结果基础上叠加，避免继续一条又立刻暂停。
    @State private var exactBaseline = 0
    @State private var fuzzyBaseline = 0
    @State private var canResume = false

    var body: some View {
        NavigationStack {
            ZStack {
                PaperBackground()
                content
            }
            .navigationTitle("找书")
            .searchable(text: $query, prompt: "书名或作者")
            .onSubmit(of: .search) { startSearch() }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showSourceManage = true
                    } label: {
                        Image(systemName: "books.vertical")
                            .foregroundStyle(Palette.ink)
                    }
                    .accessibilityLabel("书源管理")
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    sourceMenu
                }
            }
            .task { await loadSources() }
            .sheet(isPresented: $showSourceManage) {
                SourceHealthView()
            }
            .navigationDestination(for: Book.self) { book in
                BookDetailView(book: book)
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                if isSearching {
                    searchingHeader
                } else if let errorMessage {
                    ErrorBanner(message: errorMessage)
                }

                if groups.isEmpty {
                    if hasSearched && !isSearching {
                        EmptyStateView(
                            icon: "text.magnifyingglass",
                            title: "没有找到这本书",
                            message: "换个关键词，或检查书源是否启用。\n搜索只使用已启用的书源。"
                        )
                    } else if !hasSearched {
                        if !history.isEmpty {
                            historyCard
                        }
                        hint
                    }
                } else {
                    if let pauseMessage {
                        HStack(spacing: 8) {
                            Image(systemName: "pause.circle.fill")
                                .font(.caption)
                                .foregroundStyle(Palette.accent)
                            Text(pauseMessage)
                                .font(.caption)
                                .foregroundStyle(Palette.ink)
                            Spacer(minLength: 0)
                            if canResume {
                                Button {
                                    continueSearch()
                                } label: {
                                    Text("继续搜索")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(Palette.accent)
                                        .padding(.horizontal, 9)
                                        .padding(.vertical, 3)
                                        .background(Capsule().fill(Palette.accent.opacity(0.16)))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 9)
                        .background(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(Palette.accent.opacity(0.08))
                        )
                    }
                    if !exactGroups.isEmpty {
                        matchHeader(
                            title: "精确",
                            detail: "\(exactGroups.count) 本 · 书名一字不差",
                            count: sourceCount(exactGroups),
                            tint: Palette.accent
                        )
                        ForEach(exactGroups) { group in
                            if let book = group.books.first {
                                NavigationLink(value: bookWithVariants(book, group: group)) {
                                    SearchResultRow(group: group, coverURL: session.api.resolve(book.coverUrl))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    if !fuzzyGroups.isEmpty {
                        matchHeader(
                            title: "模糊",
                            detail: "\(fuzzyGroups.count) 本 · 书名相近或作者命中",
                            count: sourceCount(fuzzyGroups),
                            tint: Palette.secondaryInk
                        )
                        ForEach(fuzzyGroups) { group in
                            if let book = group.books.first {
                                NavigationLink(value: bookWithVariants(book, group: group)) {
                                    SearchResultRow(group: group, coverURL: session.api.resolve(book.coverUrl))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    if !sourceErrors.isEmpty {
                        Button {
                            showErrors = true
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "exclamationmark.circle")
                                Text("\(sourceErrors.count) 个书源失败，查看原因")
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption)
                            }
                            .font(.footnote)
                            .foregroundStyle(Palette.secondaryInk)
                            .padding(.vertical, 8)
                        }
                    }

                    Text("精确 \(exactGroups.count) · 模糊 \(fuzzyGroups.count) · 合并后共 \(groups.count) 本")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk.opacity(0.7))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 4)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
        }
        .scrollDismissesKeyboard(.immediately)
        .sheet(isPresented: $showErrors) {
            SourceErrorSheet(errors: sourceErrors)
        }
    }

    private var historyCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 9) {
                HStack {
                    Text("最近搜索")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(Palette.ink)
                    Spacer()
                    Text("\(history.count)/\(SearchHistory.limit)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                }

                ForEach(history, id: \.self) { item in
                    HStack(spacing: 8) {
                        Button {
                            query = item
                            startSearch()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "clock")
                                    .font(.caption2)
                                    .foregroundStyle(Palette.secondaryInk)
                                Text(item)
                                    .font(.system(size: 13))
                                    .foregroundStyle(Palette.ink)
                                    .lineLimit(1)
                                Spacer(minLength: 0)
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)

                        Button {
                            history = SearchHistory.remove(item)
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(Palette.secondaryInk.opacity(0.55))
                        }
                        .buttonStyle(.plain)
                    }
                    if item != history.last {
                        Divider()
                    }
                }
            }
        }
    }

    private var hint: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("搜索由服务端逐源执行")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Text("结果会随着书源返回陆续出现，进度条显示已完成的书源数量。\n多个书源出现同名同作者的书会自动合并成一张卡片。")
                .font(.footnote)
                .foregroundStyle(Palette.secondaryInk)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 6) {
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .font(.caption)
                Text("已启用书源：\(sources.filter { $0.enabled ?? true }.count) 个")
                    .font(.caption)
            }
            .foregroundStyle(Palette.accent)

            Divider()
            Button {
                showSourceManage = true
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "books.vertical")
                    Text("书源管理")
                        .font(.footnote.weight(.medium))
                    Spacer()
                    Text("检测 · 添加 · 去重")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                    Image(systemName: "chevron.right")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                }
                .foregroundStyle(Palette.accent)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.white.opacity(0.7))
        )
    }

    private var searchingHeader: some View {
        Card(padding: 14) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("正在搜索「\(query)」")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                    Spacer()
                    Button("停止") { stopSearch() }
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(Palette.accent)
                }
                if let progress {
                    ProgressView(value: progress.fraction)
                        .tint(Palette.accent)
                    Text("已完成 \(progress.completed)/\(progress.total) 个书源 · 找到 \(groups.count) 本 · 失败 \(progress.failed)")
                        .font(.caption2)
                        .foregroundStyle(Palette.secondaryInk)
                } else {
                    ProgressView().tint(Palette.accent)
                }
            }
        }
    }

    private var sourceMenu: some View {
        Menu {
            Button {
                selectedSourceURL = nil
                if hasSearched { startSearch() }
            } label: {
                if selectedSourceURL == nil {
                    Label("全部已启用书源", systemImage: "checkmark")
                } else {
                    Text("全部已启用书源")
                }
            }
            ForEach(sources.filter { ($0.enabled ?? true) && !$0.isArchived }) { source in
                Button {
                    selectedSourceURL = source.bookSourceUrl
                    if hasSearched { startSearch() }
                } label: {
                    if selectedSourceURL == source.bookSourceUrl {
                        Label(source.bookSourceName, systemImage: "checkmark")
                    } else {
                        Text(source.bookSourceName)
                    }
                }
            }
        } label: {
            Image(systemName: "line.3.horizontal.decrease.circle")
                .foregroundStyle(Palette.ink)
        }
    }

    // MARK: - 精确 / 模糊

    private var searchKey: String {
        let key = activeKey.trimmingCharacters(in: .whitespacesAndNewlines)
        return key.isEmpty ? query.trimmingCharacters(in: .whitespacesAndNewlines) : key
    }

    /// 书名与搜索词一字不差（只忽略空格与大小写）。
    private var exactGroups: [SearchGroup] {
        guard !searchKey.isEmpty else { return [] }
        let key = Self.normalize(searchKey)
        return groups.filter { Self.normalize($0.name) == key }
    }

    private var fuzzyGroups: [SearchGroup] {
        guard !searchKey.isEmpty else { return groups }
        let key = Self.normalize(searchKey)
        return groups.filter { Self.normalize($0.name) != key }
    }

    private static func normalize(_ text: String) -> String {
        text
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "　", with: "")
            .replacingOccurrences(of: "（", with: "(")
            .replacingOccurrences(of: "）", with: ")")
            .replacingOccurrences(of: "【", with: "[")
            .replacingOccurrences(of: "】", with: "]")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    private func matchHeader(title: String, detail: String, count: Int, tint: Color) -> some View {
        HStack(spacing: 6) {
            Circle()
                .fill(tint.opacity(0.75))
                .frame(width: 5, height: 5)
            Text("\(title)（\(count)）")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Palette.ink)
            Spacer(minLength: 6)
            Text(detail)
                .font(.caption2)
                .foregroundStyle(Palette.secondaryInk)
                .lineLimit(1)
        }
        .padding(.top, 6)
    }

    private func sourceCount(_ list: [SearchGroup]) -> Int {
        list.reduce(0) { $0 + $1.books.count }
    }

    // MARK: - 数据

    private func loadSources() async {
        do {
            sources = try await session.api.sources()
            serverEnabled = Dictionary(
                uniqueKeysWithValues: sources.map { ($0.bookSourceUrl, $0.enabled ?? true) }
            )
        } catch {
            // 书源列表失败不阻塞搜索，搜索时会返回具体错误。
        }
    }

    /// 本地覆盖表优先：用户在书源管理里关掉的源，这里同样不再展示。
    private func isLocallyEnabled(_ book: Book) -> Bool {
        let url = book.origin.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !url.isEmpty else { return true }
        let server = serverEnabled[url] ?? true
        return SourcePrefs.shared.isEnabled(url: url, serverEnabled: server)
    }

    private func startSearch() {
        let key = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        history = SearchHistory.add(key)
        activeKey = key
        exactBaseline = 0
        fuzzyBaseline = 0
        canResume = false
        searchTask?.cancel()
        session.api.cancelSearch()
        withAnimation(.easeInOut(duration: 0.2)) {
            groups = []
            sourceErrors = []
            progress = nil
            errorMessage = nil
            pauseMessage = nil
            isSearching = true
            hasSearched = true
        }
        let source = selectedSourceURL
        searchTask = Task { @MainActor in
            do {
                for try await event in session.api.searchEvents(key: key, sourceUrl: source) {
                    if Task.isCancelled { break }
                    handle(event)
                }
            } catch {
                if !Task.isCancelled {
                    errorMessage = error.localizedDescription
                }
            }
            isSearching = false
            progress = nil
        }
    }

    /// 精确到 100 条或模糊到 500 条时自动停流，避免一次搜索拖太久。
    private func enforceBudget() {
        guard isSearching else { return }
        let exact = exactGroups.count
        let fuzzy = fuzzyGroups.count
        if exact >= exactBaseline + 100 {
            stopSearch()
            pauseMessage = "精确结果已达 \(exact) 条，已自动暂停搜索"
        } else if fuzzy >= fuzzyBaseline + 500 {
            stopSearch()
            pauseMessage = "模糊结果已达 \(fuzzy) 条，已自动暂停搜索"
        }
    }

    /// 在上限处继续：沿用同一关键词，带 resume 让服务端跳过已处理的书源。
    private func continueSearch() {
        guard !isSearching, !activeKey.isEmpty else { return }
        exactBaseline = exactGroups.count
        fuzzyBaseline = fuzzyGroups.count
        pauseMessage = nil
        canResume = false
        errorMessage = nil
        isSearching = true
        let source = selectedSourceURL
        searchTask?.cancel()
        searchTask = Task { @MainActor in
            do {
                for try await event in session.api.searchEvents(key: activeKey, sourceUrl: source, resume: true) {
                    if Task.isCancelled { break }
                    handle(event)
                }
            } catch {
                if !Task.isCancelled {
                    errorMessage = error.localizedDescription
                }
            }
            isSearching = false
            progress = nil
        }
    }

    private func stopSearch() {
        searchTask?.cancel()
        session.api.cancelSearch()
        isSearching = false
        canResume = !activeKey.isEmpty
    }

    private func handle(_ event: SearchEvent) {
        if let progress = event.progress {
            self.progress = progress
        }
        switch event.type {
        case "source":
            if let books = event.books, !books.isEmpty {
                let usable = books.filter { isLocallyEnabled($0) }
                if !usable.isEmpty {
                    let key = Self.normalize(activeKey)
                    let exact = usable.filter { Self.normalize($0.name) == key }
                    if !exact.isEmpty {
                        ExactSourceMemo.shared.record(name: activeKey, books: exact)
                    }
                    merge(usable)
                    enforceBudget()
                }
            }
            if let error = event.error {
                sourceErrors.append(error)
            }
        case "done":
            isSearching = false
            progress = nil
        default:
            break
        }
    }

    /// 把同一本书的其他源塞进 sourceVariants，详情页「书源一排」才能完整列出。
    private func bookWithVariants(_ book: Book, group: SearchGroup) -> Book {
        var merged = book
        let others = group.books.filter { $0.bookUrl != book.bookUrl }
        guard !others.isEmpty else { return merged }
        var variants = merged.sourceVariants ?? []
        for other in others where !variants.contains(where: { $0.bookUrl == other.bookUrl }) {
            variants.append(other)
        }
        merged.sourceVariants = variants
        return merged
    }

    private func merge(_ books: [Book]) {
        for book in books {
            let key = book.name.trimmingCharacters(in: .whitespacesAndNewlines) + "|" + book.author
            if let index = groups.firstIndex(where: { $0.id == key }) {
                if !groups[index].books.contains(where: { $0.bookUrl == book.bookUrl }) {
                    groups[index].books.append(book)
                }
            } else {
                groups.append(SearchGroup(id: key, name: book.name, author: book.author, books: [book]))
            }
        }
    }
}

// MARK: - 结果行

struct SearchResultRow: View {
    let group: SearchGroup
    let coverURL: URL?

    @EnvironmentObject private var session: AppSession
    @ObservedObject private var chapterProbe = SourceChapterProbe.shared

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 14) {
                BookCoverView(
                    book: group.books.first ?? Book(bookUrl: "", name: group.name, origin: ""),
                    coverURL: coverURL
                )
                .frame(width: 52)
                VStack(alignment: .leading, spacing: 5) {
                    Text(group.name)
                        .font(.system(size: 16, weight: .medium, design: .serif))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                    Text(group.author.isEmpty ? "佚名" : group.author)
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                    HStack(spacing: 6) {
                        Text("\(group.books.count) 个书源")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(Palette.accent)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Palette.accent.opacity(0.1)))
                        if let kind = group.books.first?.kind, !kind.isEmpty {
                            Text(kind)
                                .font(.system(size: 10))
                                .foregroundStyle(Palette.secondaryInk)
                                .lineLimit(1)
                        }
                    }
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Palette.secondaryInk.opacity(0.6))
            }
            sourceLines
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.white.opacity(0.68))
        )
        .onAppear { chapterProbe.load(group.books, api: session.api) }
    }

    /// 每家源一行：源名 · 共多少章 · 最新一章。
    private var sourceLines: some View {
        VStack(alignment: .leading, spacing: 5) {
            ForEach(group.books, id: \.bookUrl) { book in
                HStack(spacing: 6) {
                    Text(sourceName(book))
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(Palette.secondaryInk)
                        .lineLimit(1)
                    Text(sourceSummary(book))
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.secondaryInk.opacity(0.8))
                        .lineLimit(1)
                    Spacer(minLength: 0)
                }
            }
        }
        .padding(.leading, 66)
    }

    private func sourceName(_ book: Book) -> String {
        if let name = book.originName, !name.isEmpty { return name }
        if let host = URL(string: book.origin)?.host, !host.isEmpty { return host }
        return "未知书源"
    }

    private func sourceSummary(_ book: Book) -> String {
        let stat = chapterProbe.stats[book.bookUrl]
        var pieces: [String] = []
        if let total = stat?.total ?? book.totalChapterNum, total > 0 {
            pieces.append("共 \(total) 章")
        } else if stat == nil {
            pieces.append("章数读取中…")
        } else {
            pieces.append("章数未知")
        }
        let latest = stat?.lastChapter ?? book.lastChapterHint
        if !latest.isEmpty {
            pieces.append("最新「\(latest)」")
        }
        return pieces.joined(separator: " · ")
    }
}

struct SourceErrorSheet: View {
    let errors: [SearchError]
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List(errors, id: \.self) { error in
                VStack(alignment: .leading, spacing: 4) {
                    Text(error.source)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Palette.ink)
                        .lineLimit(1)
                    Text(error.message)
                        .font(.caption)
                        .foregroundStyle(Palette.secondaryInk)
                }
                .padding(.vertical, 4)
            }
            .navigationTitle("失败的书源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

// MARK: - 搜索记录

/// 本地保存最近搜索关键词，最多 20 条，重复词提到最前。
enum SearchHistory {
    static let limit = 20
    private static let storageKey = "liubai.searchHistory"

    static func load() -> [String] {
        UserDefaults.standard.stringArray(forKey: storageKey) ?? []
    }

    @discardableResult
    static func add(_ keyword: String) -> [String] {
        let trimmed = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return load() }
        var list = load().filter { $0 != trimmed }
        list.insert(trimmed, at: 0)
        if list.count > limit { list = Array(list.prefix(limit)) }
        UserDefaults.standard.set(list, forKey: storageKey)
        return list
    }

    @discardableResult
    static func remove(_ keyword: String) -> [String] {
        var list = load()
        list.removeAll { $0 == keyword }
        UserDefaults.standard.set(list, forKey: storageKey)
        return list
    }
}
