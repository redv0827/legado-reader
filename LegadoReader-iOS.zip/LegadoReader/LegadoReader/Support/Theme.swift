import SwiftUI
import UIKit

// MARK: - 界面配色

enum Palette {
    /// 朱红：来自传统印章色，作为主强调色。
    static let accent = Color(red: 0.72, green: 0.22, blue: 0.18)
    static let ink = Color(red: 0.16, green: 0.15, blue: 0.14)
    static let paper = Color(red: 0.976, green: 0.961, blue: 0.929)
    static let paperDeep = Color(red: 0.949, green: 0.925, blue: 0.878)
    static let secondaryInk = Color(red: 0.42, green: 0.40, blue: 0.38)
    static let hairline = Color(red: 0.84, green: 0.81, blue: 0.76)

    static func coverGradient(_ seed: String) -> [Color] {
        let palettes: [[Color]] = [
            [Color(red: 0.85, green: 0.79, blue: 0.70), Color(red: 0.66, green: 0.58, blue: 0.48)],
            [Color(red: 0.77, green: 0.82, blue: 0.78), Color(red: 0.52, green: 0.61, blue: 0.56)],
            [Color(red: 0.86, green: 0.82, blue: 0.83), Color(red: 0.64, green: 0.56, blue: 0.60)],
            [Color(red: 0.82, green: 0.80, blue: 0.74), Color(red: 0.58, green: 0.54, blue: 0.45)],
        ]
        var hash: UInt64 = 1469598103934665603
        for scalar in seed.unicodeScalars {
            hash = (hash ^ UInt64(scalar.value)) * 1099511628211
        }
        return palettes[Int(hash % UInt64(palettes.count))]
    }
}

// MARK: - 阅读主题

enum ReaderThemeKind: String, Codable, CaseIterable, Identifiable {
    case paper
    case white
    case sage
    case night

    var id: String { rawValue }

    var title: String {
        switch self {
        case .paper: return "暖纸"
        case .white: return "素白"
        case .sage: return "青竹"
        case .night: return "夜读"
        }
    }

    var backgroundColor: UIColor {
        switch self {
        case .paper: return UIColor(red: 0.976, green: 0.957, blue: 0.914, alpha: 1)
        case .white: return UIColor(red: 0.996, green: 0.996, blue: 0.992, alpha: 1)
        case .sage: return UIColor(red: 0.916, green: 0.937, blue: 0.910, alpha: 1)
        case .night: return UIColor(red: 0.086, green: 0.090, blue: 0.098, alpha: 1)
        }
    }

    var textColor: UIColor {
        switch self {
        case .paper: return UIColor(red: 0.180, green: 0.157, blue: 0.129, alpha: 1)
        case .white: return UIColor(red: 0.129, green: 0.129, blue: 0.125, alpha: 1)
        case .sage: return UIColor(red: 0.149, green: 0.196, blue: 0.161, alpha: 1)
        case .night: return UIColor(red: 0.760, green: 0.757, blue: 0.733, alpha: 1)
        }
    }

    var secondaryTextColor: UIColor {
        textColor.withAlphaComponent(0.55)
    }

    var swiftUIBackground: Color { Color(uiColor: backgroundColor) }
    var swiftUIText: Color { Color(uiColor: textColor) }
    var swiftUISecondary: Color { Color(uiColor: secondaryTextColor) }
}

// MARK: - 阅读字体

enum ReaderFontKind: String, Codable, CaseIterable, Identifiable {
    case song
    case kai
    case hei

    var id: String { rawValue }

    var title: String {
        switch self {
        case .song: return "宋体"
        case .kai: return "楷体"
        case .hei: return "黑体"
        }
    }

    func uiFont(size: CGFloat) -> UIFont {
        switch self {
        case .song:
            if let font = UIFont(name: "Songti SC", size: size) { return font }
            if let font = UIFont(name: "STSongti-SC-Regular", size: size) { return font }
        case .kai:
            if let font = UIFont(name: "Kaiti SC", size: size) { return font }
            if let font = UIFont(name: "STKaiti", size: size) { return font }
        case .hei:
            break
        }
        return UIFont.systemFont(ofSize: size)
    }
}

// MARK: - 阅读排版设置

struct ReadingSettings: Codable, Equatable {
    var fontSize: Double = 19
    var lineHeightMultiple: Double = 1.55
    var paragraphSpacing: Double = 12
    var letterSpacing: Double = 0
    var fontKind: ReaderFontKind = .song
    var theme: ReaderThemeKind = .paper
    var indent: Bool = false

    private static let storageKey = "reader.settings"

    static func load() -> ReadingSettings {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let value = try? JSONDecoder().decode(ReadingSettings.self, from: data) else {
            return ReadingSettings()
        }
        return value
    }

    func save() {
        guard let data = try? JSONEncoder().encode(self) else { return }
        UserDefaults.standard.set(data, forKey: Self.storageKey)
    }
}

enum ReaderTypography {
    static func attributedString(text: String, settings: ReadingSettings) -> NSAttributedString {
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineHeightMultiple = CGFloat(settings.lineHeightMultiple)
        paragraph.paragraphSpacing = CGFloat(settings.paragraphSpacing)
        paragraph.lineSpacing = 0
        paragraph.alignment = .justified
        paragraph.lineBreakMode = .byWordWrapping
        paragraph.firstLineHeadIndent = settings.indent ? CGFloat(settings.fontSize) * 2 : 0
        paragraph.headIndent = settings.indent ? CGFloat(settings.fontSize) * 2 : 0
        paragraph.tailIndent = 0

        let font = settings.fontKind.uiFont(size: CGFloat(settings.fontSize))
        var attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: settings.theme.textColor,
            .paragraphStyle: paragraph,
        ]
        if settings.letterSpacing != 0 {
            attributes[.kern] = CGFloat(settings.letterSpacing)
        }
        return NSAttributedString(string: text, attributes: attributes)
    }
}
