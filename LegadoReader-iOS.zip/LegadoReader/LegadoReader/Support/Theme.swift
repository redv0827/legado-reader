import SwiftUI
import UIKit

// MARK: - 界面配色

enum Palette {
    /// 朱红：来自传统印章色，作为主强调色。
    static let accent = Color(red: 0.72, green: 0.22, blue: 0.18)
    static let ink = Color(red: 0.16, green: 0.15, blue: 0.14)
    static let paper = Color(red: 0.976, green: 0.961, blue: 0.929)
    static let paperDeep = Color(red: 0.949, green: 0.925, blue: 0.878)
    static let secondaryInk = Color(red: 0.42, green: 0.40, blue: 0.38)
    static let hairline = Color(red: 0.84, green: 0.81, blue: 0.76)

    static func coverGradient(_ seed: String) -> [Color] {
        let palettes: [[Color]] = [
            [Color(red: 0.85, green: 0.79, blue: 0.70), Color(red: 0.66, green: 0.58, blue: 0.48)],
            [Color(red: 0.77, green: 0.82, blue: 0.78), Color(red: 0.52, green: 0.61, blue: 0.56)],
            [Color(red: 0.86, green: 0.82, blue: 0.83), Color(red: 0.64, green: 0.56, blue: 0.60)],
            [Color(red: 0.82, green: 0.80, blue: 0.74), Color(red: 0.58, green: 0.54, blue: 0.45)],
        ]
        // FNV-1a 需要回绕乘法，用 &* 避免 UInt64 溢出触发运行时 trap。
        var hash: UInt64 = 1469598103934665603
        for scalar in seed.unicodeScalars {
            hash = (hash ^ UInt64(scalar.value)) &* 1099511628211
        }
        return palettes[Int(hash % UInt64(palettes.count))]
    }
}

// MARK: - 阅读主题

enum ReaderThemeKind: String, Codable, CaseIterable, Identifiable {
    case paper
    case amber
    case white
    case sage
    case night

    var id: String { rawValue }

    var title: String {
        switch self {
        case .paper: return "暖纸"
        case .amber: return "羊皮"
        case .white: return "素白"
        case .sage: return "青竹"
        case .night: return "夜读"
        }
    }

    var backgroundColor: UIColor {
        switch self {
        case .paper: return UIColor(red: 0.976, green: 0.957, blue: 0.914, alpha: 1)
        // 取自参考图的纸张底色 #F1DFBB，偏暖偏黄的羊皮纸。
        case .amber: return UIColor(red: 0.945, green: 0.875, blue: 0.733, alpha: 1)
        case .white: return UIColor(red: 0.996, green: 0.996, blue: 0.992, alpha: 1)
        case .sage: return UIColor(red: 0.916, green: 0.937, blue: 0.910, alpha: 1)
        case .night: return UIColor(red: 0.086, green: 0.090, blue: 0.098, alpha: 1)
        }
    }

    var textColor: UIColor {
        switch self {
        case .paper: return UIColor(red: 0.180, green: 0.157, blue: 0.129, alpha: 1)
        case .amber: return UIColor(red: 0.196, green: 0.176, blue: 0.145, alpha: 1)
        case .white: return UIColor(red: 0.129, green: 0.129, blue: 0.125, alpha: 1)
        case .sage: return UIColor(red: 0.149, green: 0.196, blue: 0.161, alpha: 1)
        case .night: return UIColor(red: 0.760, green: 0.757, blue: 0.733, alpha: 1)
        }
    }

    var secondaryTextColor: UIColor {
        textColor.withAlphaComponent(0.55)
    }

    var swiftUIBackground: Color { Color(uiColor: backgroundColor) }
    var swiftUIText: Color { Color(uiColor: textColor) }
    var swiftUISecondary: Color { Color(uiColor: secondaryTextColor) }
}

// MARK: - 阅读字体

enum ReaderFontKind: String, Codable, CaseIterable, Identifiable {
    case song
    case kai
    case hei

    var id: String { rawValue }

    var title: String {
        switch self {
        case .song: return "宋体"
        case .kai: return "楷体"
        case .hei: return "黑体"
        }
    }

    func uiFont(size: CGFloat) -> UIFont {
        switch self {
        case .song:
            if let font = UIFont(name: "Songti SC", size: size) { return font }
            if let font = UIFont(name: "STSongti-SC-Regular", size: size) { return font }
        case .kai:
            if let font = UIFont(name: "Kaiti SC", size: size) { return font }
            if let font = UIFont(name: "STKaiti", size: size) { return font }
        case .hei:
            break
        }
        return UIFont.systemFont(ofSize: size)
    }
}

// MARK: - 翻页效果

enum PageTurnStyle: String, Codable, CaseIterable, Identifiable {
    case slide
    case curl
    case instant

    var id: String { rawValue }

    var title: String {
        switch self {
        case .slide: return "平滑滑动"
        case .curl: return "仿真翻页"
        case .instant: return "直接跳页"
        }
    }

    var subtitle: String {
        switch self {
        case .slide: return "纸页跟手平移"
        case .curl: return "纸角卷起翻页"
        case .instant: return "无动画，立刻换页"
        }
    }
}

// MARK: - 阅读排版设置

struct ReadingSettings: Codable, Equatable {
    var fontSize: Double = 19
    var lineHeightMultiple: Double = 1.55
    var paragraphSpacing: Double = 12
    var letterSpacing: Double = 0
    var fontKind: ReaderFontKind = .song
    var theme: ReaderThemeKind = .paper
    /// 旧版只有「首行缩进」开关，这里保留只为迁移旧设置，渲染不再使用。
    var indent: Bool = false
    /// 段首缩进：每段第一行往右缩多少，单位是「字」（1 字 = 当前字号），0 即不缩进。
    var headIndent: Double = 2
    /// 段尾缩进：每段右边界往左收多少，单位同样是「字」，0 即顶到右边。
    var tailIndent: Double = 0
    /// 阅读方式：true 为整页翻页，false 为连续滚动。
    var paged: Bool = true
    /// 整页翻页时用哪种切换效果。
    var turn: PageTurnStyle = .slide
    /// 正文页边距（pt）：上、下、左、右，四个方向都能单独调。
    var insetTop: Double = 28
    var insetBottom: Double = 28
    var insetLeft: Double = 22
    var insetRight: Double = 22

    /// 落到 UIKit 用的四边内边距。
    var textInsets: UIEdgeInsets {
        UIEdgeInsets(
            top: max(0, CGFloat(insetTop)),
            left: max(0, CGFloat(insetLeft)),
            bottom: max(0, CGFloat(insetBottom)),
            right: max(0, CGFloat(insetRight))
        )
    }

    private static let storageKey = "reader.settings"

    init() {}

    private enum CodingKeys: String, CodingKey {
        case fontSize, lineHeightMultiple, paragraphSpacing, letterSpacing
        case fontKind, theme, indent, paged, turn
        case headIndent, tailIndent
        case insetTop, insetBottom, insetLeft, insetRight
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        fontSize = (try? container.decode(Double.self, forKey: .fontSize)) ?? 19
        lineHeightMultiple = (try? container.decode(Double.self, forKey: .lineHeightMultiple)) ?? 1.55
        paragraphSpacing = (try? container.decode(Double.self, forKey: .paragraphSpacing)) ?? 12
        letterSpacing = (try? container.decode(Double.self, forKey: .letterSpacing)) ?? 0
        fontKind = (try? container.decode(ReaderFontKind.self, forKey: .fontKind)) ?? .song
        theme = (try? container.decode(ReaderThemeKind.self, forKey: .theme)) ?? .paper
        indent = (try? container.decode(Bool.self, forKey: .indent)) ?? false
        headIndent = (try? container.decode(Double.self, forKey: .headIndent)) ?? 2
        tailIndent = (try? container.decode(Double.self, forKey: .tailIndent)) ?? 0
        paged = (try? container.decode(Bool.self, forKey: .paged)) ?? true
        turn = (try? container.decode(PageTurnStyle.self, forKey: .turn)) ?? .slide
        insetTop = (try? container.decode(Double.self, forKey: .insetTop)) ?? 28
        insetBottom = (try? container.decode(Double.self, forKey: .insetBottom)) ?? 28
        insetLeft = (try? container.decode(Double.self, forKey: .insetLeft)) ?? 22
        insetRight = (try? container.decode(Double.self, forKey: .insetRight)) ?? 22
    }

    static func load() -> ReadingSettings {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let value = try? JSONDecoder().decode(ReadingSettings.self, from: data) else {
            return ReadingSettings()
        }
        return value
    }

    func save() {
        guard let data = try? JSONEncoder().encode(self) else { return }
        UserDefaults.standard.set(data, forKey: Self.storageKey)
    }
}

/// 排版结果：渲染用的富文本，加上「渲染偏移 ↔ 原文偏移」的双向换算。
///
/// 中文避头尾会在标点前插入零宽 word joiner，渲染出来的长度因此可能比原文长，
/// 而进度必须按原文偏移保存，否则每次保存都会往前漂一点，多端接续越读越偏。
struct ReaderLayout {
    let attributed: NSAttributedString
    /// 每个渲染位置（0...length）对应的原文位置，单调不减。
    private let renderToSource: [Int]

    init(attributed: NSAttributedString, renderToSource: [Int]) {
        self.attributed = attributed
        self.renderToSource = renderToSource
    }

    func sourceOffset(forRender render: Int) -> Int {
        guard !renderToSource.isEmpty else { return max(0, render) }
        let index = min(max(render, 0), renderToSource.count - 1)
        return renderToSource[index]
    }

    func renderOffset(forSource source: Int) -> Int {
        guard !renderToSource.isEmpty else { return max(0, source) }
        var low = 0
        var high = renderToSource.count - 1
        while low < high {
            let mid = (low + high) / 2
            if renderToSource[mid] < source { low = mid + 1 } else { high = mid }
        }
        return low
    }
}

enum ReaderTypography {
    /// 行首不能出现的标点：遇到就把前一个字和它绑住，不许在它前面断行。
    private static let forbiddenHead: Set<Character> = [
        "，", "。", "、", "；", "：", "？", "！", "）", "》", "」", "』", "】", "｝", "…", "·", "～",
    ]
    /// 行尾不能出现的标点：开引号、开括号，遇到就把它和后一个字绑住。
    private static let forbiddenTail: Set<Character> = ["（", "《", "「", "『", "【", "｛"]

    /// 生成排版结果；避头尾的处理与偏移映射都在这里完成。
    static func layout(text: String, settings: ReadingSettings) -> ReaderLayout {
        let prepared = bindPunctuation(text)
        let attributed = attributedString(text: prepared.text, settings: settings)
        return ReaderLayout(attributed: attributed, renderToSource: prepared.map)
    }

    /// 逐字扫描，在需要的地方插入 U+2060（word joiner，零宽、且禁止在它两侧断行）。
    private static func bindPunctuation(_ text: String) -> (text: String, map: [Int]) {
        var output = ""
        output.reserveCapacity(text.utf16.count + 64)
        var map: [Int] = []
        map.reserveCapacity(text.utf16.count + 80)
        var source = 0
        var previous: Character?
        for character in text {
            let length = character.utf16.count
            let tailBefore = previous.map { forbiddenTail.contains($0) } ?? false
            let needsJoin = previous != nil
                && previous != "\n"
                && (forbiddenHead.contains(character) || tailBefore)
            if needsJoin {
                output.append("\u{2060}")
                map.append(source)
            }
            output.append(character)
            for _ in 0..<length { map.append(source) }
            source += length
            previous = character
        }
        map.append(source)
        return (output, map)
    }

    static func attributedString(text: String, settings: ReadingSettings) -> NSAttributedString {
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineHeightMultiple = CGFloat(settings.lineHeightMultiple)
        paragraph.paragraphSpacing = CGFloat(settings.paragraphSpacing)
        paragraph.lineSpacing = 0
        paragraph.alignment = .justified
        paragraph.lineBreakMode = .byWordWrapping
        // 段首缩进只作用在每段第一行，后续行顶格；段尾缩进把每段右边往里收。
        let unit = CGFloat(settings.fontSize)
        paragraph.headIndent = 0
        paragraph.firstLineHeadIndent = unit * CGFloat(max(0, settings.headIndent))
        paragraph.tailIndent = -unit * CGFloat(max(0, settings.tailIndent))

        let font = settings.fontKind.uiFont(size: CGFloat(settings.fontSize))
        var attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: settings.theme.textColor,
            .paragraphStyle: paragraph,
        ]
        if settings.letterSpacing != 0 {
            attributes[.kern] = CGFloat(settings.letterSpacing)
        }
        return NSAttributedString(string: text, attributes: attributes)
    }
}
