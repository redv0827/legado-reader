import Combine
import Foundation

/// 书架收藏夹（纯本地）：书架最后一排单独展示的一批书。
/// 键与置顶表一致：服务端书用 `bookUrl`，本地 TXT 用 `local:<id>`，两种书都能收。
/// 存 Documents/liubai-shelf-favorites.json，最近收进来的排最前。
final class ShelfFavoritesStore: ObservableObject {
    static let shared = ShelfFavoritesStore()

    @Published private(set) var keys: [String] = []

    private let fileURL: URL

    private init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        fileURL = documents.appendingPathComponent("liubai-shelf-favorites.json")
        load()
    }

    var count: Int { keys.count }

    func contains(_ key: String) -> Bool {
        keys.contains(key)
    }

    /// 加收藏，最近加的排最前。
    func add(_ newKeys: [String]) {
        var changed = false
        for key in newKeys where !key.isEmpty {
            if !keys.contains(key) {
                keys.insert(key, at: 0)
                changed = true
            }
        }
        if changed { save() }
    }

    func remove(_ oldKeys: [String]) {
        let before = keys.count
        keys.removeAll { oldKeys.contains($0) }
        if keys.count != before { save() }
    }

    /// 书被删掉或移出书架后清掉对应收藏，免得收藏夹里挂着空项。
    func forget(_ oldKeys: [String]) {
        remove(oldKeys)
    }

    func clear() {
        keys = []
        try? FileManager.default.removeItem(at: fileURL)
    }

    var fileSize: Int64 {
        LocalDataFiles.size(of: fileURL)
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([String].self, from: data)
        else { return }
        keys = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(keys) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
