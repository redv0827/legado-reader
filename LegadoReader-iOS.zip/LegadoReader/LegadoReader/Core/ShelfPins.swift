import Combine
import Foundation

/// 书架置顶表（纯本地）：把选中的书钉在书架最前面。
/// 键：服务端书用 `bookUrl`，本地 TXT 用 `local:<LocalBook.id>`。
/// 存在 Documents/liubai-shelf-pins.json，值是该书被置顶的时间戳，越晚置顶排得越前。
/// 只在主线程读写（SwiftUI 侧调用），这里不加 @MainActor 以免 View 的属性初始化被隔离检查拦住。
final class ShelfPinsStore: ObservableObject {
    static let shared = ShelfPinsStore()

    @Published private(set) var pins: [String: Double] = [:]

    private let fileURL: URL

    private init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        fileURL = documents.appendingPathComponent("liubai-shelf-pins.json")
        load()
    }

    // MARK: - 键

    static func key(bookURL: String) -> String { bookURL }

    static func key(localID: String) -> String { "local:\(localID)" }

    // MARK: - 查询

    func isPinned(_ key: String) -> Bool {
        pins[key] != nil
    }

    func pinnedAt(_ key: String) -> Double {
        pins[key] ?? 0
    }

    // MARK: - 修改

    func pin(_ keys: [String]) {
        guard !keys.isEmpty else { return }
        let now = Date().timeIntervalSince1970
        for key in keys where pins[key] == nil {
            pins[key] = now
        }
        save()
    }

    func unpin(_ keys: [String]) {
        guard !keys.isEmpty else { return }
        for key in keys {
            pins.removeValue(forKey: key)
        }
        save()
    }

    /// 书被删掉/移出书架后，顺手把它的置顶记录也清掉，免得表越攒越脏。
    func forget(_ keys: [String]) {
        unpin(keys)
    }

    // MARK: - 持久化

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([String: Double].self, from: data)
        else { return }
        pins = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(pins) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
