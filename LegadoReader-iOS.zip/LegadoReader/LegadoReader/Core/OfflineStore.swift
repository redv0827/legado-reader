import Foundation

/// 整本离线缓存：按书的 bookUrl 建一个目录，每章正文存一个 json，
/// 断网、地铁里也能一路读下去，不用等接口。
final class OfflineStore {
    static let shared = OfflineStore()

    private let root: URL
    private let fileManager = FileManager.default

    private init() {
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        root = documents.appendingPathComponent("liubai-offline", isDirectory: true)
    }

    private func folder(for bookURL: String) -> URL {
        root.appendingPathComponent(Self.digest(bookURL), isDirectory: true)
    }

    private func file(for bookURL: String, index: Int) -> URL {
        folder(for: bookURL).appendingPathComponent("\(index).json")
    }

    func hasChapter(bookURL: String, index: Int) -> Bool {
        fileManager.fileExists(atPath: file(for: bookURL, index: index).path)
    }

    func content(bookURL: String, index: Int) -> BookContent? {
        let url = file(for: bookURL, index: index)
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(BookContent.self, from: data)
    }

    func save(_ content: BookContent, bookURL: String, index: Int) {
        let directory = folder(for: bookURL)
        if !fileManager.fileExists(atPath: directory.path) {
            try? fileManager.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        guard let data = try? JSONEncoder().encode(content) else { return }
        try? data.write(to: file(for: bookURL, index: index), options: .atomic)
    }

    func downloadedCount(bookURL: String) -> Int {
        guard let names = try? fileManager.contentsOfDirectory(atPath: folder(for: bookURL).path) else { return 0 }
        return names.filter { $0.hasSuffix(".json") && $0 != "meta.json" }.count
    }

    /// 把书名列下来，存储页要显示「下载了哪几本」，清理时也按它列。
    struct Meta: Codable {
        var bookUrl: String
        var name: String
    }

    /// 存储页用的一本书的离线概览。
    struct Summary: Identifiable {
        var id: String { bookUrl }
        var bookUrl: String
        var name: String
        var chapterCount: Int
        var bytes: Int64
    }

    func keep(bookURL: String, name: String) {
        let directory = folder(for: bookURL)
        if !fileManager.fileExists(atPath: directory.path) {
            try? fileManager.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        let meta = Meta(bookUrl: bookURL, name: name)
        guard let data = try? JSONEncoder().encode(meta) else { return }
        try? data.write(to: directory.appendingPathComponent("meta.json"), options: .atomic)
    }

    func summaries() -> [Summary] {
        guard let folders = try? fileManager.contentsOfDirectory(
            at: root,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else { return [] }
        var result: [Summary] = []
        for folder in folders {
            let metaURL = folder.appendingPathComponent("meta.json")
            guard let data = try? Data(contentsOf: metaURL),
                  let meta = try? JSONDecoder().decode(Meta.self, from: data)
            else { continue }
            let names = (try? fileManager.contentsOfDirectory(atPath: folder.path)) ?? []
            var bytes: Int64 = 0
            for name in names {
                let url = folder.appendingPathComponent(name)
                bytes += Int64((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
            }
            let count = names.filter { $0.hasSuffix(".json") && $0 != "meta.json" }.count
            result.append(Summary(bookUrl: meta.bookUrl, name: meta.name, chapterCount: count, bytes: bytes))
        }
        return result.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    func clearAll() {
        try? fileManager.removeItem(at: root)
    }

    func clear(bookURL: String) {
        try? fileManager.removeItem(at: folder(for: bookURL))
    }

    /// 整本离线一共占了多少空间，存储页用。
    func totalBytes() -> Int64 {
        guard let enumerator = fileManager.enumerator(
            at: root,
            includingPropertiesForKeys: [.fileSizeKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }
        var total: Int64 = 0
        for case let url as URL in enumerator {
            let size = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            total += Int64(size)
        }
        return total
    }

    /// 书名里可能有各种符号，用稳定摘要做目录名，避免非法路径。
    private static func digest(_ value: String) -> String {
        var hash: UInt64 = 0xcbf29ce484222325
        for byte in value.utf8 {
            hash ^= UInt64(byte)
            hash = hash &* 0x100000001b3
        }
        return String(format: "%016llx", hash)
    }
}
