import Foundation

// MARK: - 本地书籍模型

struct LocalBook: Codable, Identifiable, Hashable {
    var id: String
    var title: String
    var author: String
    var fileName: String
    var addedAt: Double
    var lastReadTime: Double?
    var chapterIndex: Int
    var chapterOffset: Int
    var chapterTitle: String?
    var chapterCount: Int
    var charCount: Int

    var progressFraction: Double {
        guard chapterCount > 1 else { return chapterOffset > 0 ? 0.5 : 0 }
        let index = min(max(chapterIndex, 0), chapterCount - 1)
        return min(1, max(0, Double(index) / Double(chapterCount - 1)))
    }

    var lastReadText: String {
        guard let time = lastReadTime, time > 0 else { return "未读" }
        let date = Date(timeIntervalSince1970: time)
        let formatter = RelativeDateTimeFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.unitsStyle = .short
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

enum LocalBookError: LocalizedError {
    case emptyFile
    case unsupportedEncoding
    case missingFile

    var errorDescription: String? {
        switch self {
        case .emptyFile: return "这个文件里没有可读的文字"
        case .unsupportedEncoding: return "无法识别这个文件的编码（支持 UTF-8 / UTF-16 / GB18030 / Big5 的纯文本）"
        case .missingFile: return "本地文件已丢失，请重新导入"
        }
    }
}

// MARK: - 章节切片

private struct LocalChapterSlice {
    let title: String
    let range: NSRange
}

// MARK: - 本地书库

/// 本地纯文本书籍的导入、章节切分与进度保存。文件存在 App 的 Documents/LocalBooks 下。
final class LocalBookStore {
    static let shared = LocalBookStore()

    private let fileManager = FileManager.default
    private var books: [LocalBook] = []
    private var indexLoaded = false
    private var cachedText: [String: String] = [:]
    private var cachedSlices: [String: [LocalChapterSlice]] = [:]

    private init() {}

    // MARK: 路径

    private var documentsURL: URL {
        fileManager.urls(for: .documentDirectory, in: .userDomainMask).first ?? fileManager.temporaryDirectory
    }

    private var rootURL: URL {
        documentsURL.appendingPathComponent("LocalBooks", isDirectory: true)
    }

    private var indexURL: URL {
        rootURL.appendingPathComponent("index.json")
    }

    private func fileURL(for book: LocalBook) -> URL {
        rootURL.appendingPathComponent(book.fileName)
    }

    // MARK: 索引读写

    private func ensureLoaded() {
        guard !indexLoaded else { return }
        indexLoaded = true
        if let data = try? Data(contentsOf: indexURL),
           let decoded = try? JSONDecoder().decode([LocalBook].self, from: data) {
            books = decoded
        }
    }

    private func persistIndex() {
        do {
            try fileManager.createDirectory(at: rootURL, withIntermediateDirectories: true, attributes: nil)
            let data = try JSONEncoder().encode(books)
            try data.write(to: indexURL, options: .atomic)
        } catch {
            // 索引写入失败只影响下次启动的列表，不影响当前阅读。
        }
    }

    // MARK: 查询

    func all() -> [LocalBook] {
        ensureLoaded()
        return books.sorted { lhs, rhs in
            (lhs.lastReadTime ?? lhs.addedAt) > (rhs.lastReadTime ?? rhs.addedAt)
        }
    }

    func book(withId id: String) -> LocalBook? {
        ensureLoaded()
        return books.first { $0.id == id }
    }

    // MARK: 导入

    func importBook(from url: URL) throws -> LocalBook {
        ensureLoaded()
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }

        let raw = try Data(contentsOf: url)
        guard let text = Self.decodeText(raw), !text.isEmpty else {
            throw LocalBookError.emptyFile
        }

        let id = UUID().uuidString
        let fileName = id + ".txt"
        try fileManager.createDirectory(at: rootURL, withIntermediateDirectories: true, attributes: nil)
        guard let normalized = text.data(using: .utf8) else {
            throw LocalBookError.unsupportedEncoding
        }
        try normalized.write(to: rootURL.appendingPathComponent(fileName), options: .atomic)

        let slices = Self.sliceChapters(text)
        let rawTitle = url.deletingPathExtension().lastPathComponent.trimmingCharacters(in: .whitespacesAndNewlines)
        let title = rawTitle.isEmpty ? "未命名" : rawTitle

        let book = LocalBook(
            id: id,
            title: title,
            author: "",
            fileName: fileName,
            addedAt: Date().timeIntervalSince1970,
            lastReadTime: nil,
            chapterIndex: 0,
            chapterOffset: 0,
            chapterTitle: slices.first?.title,
            chapterCount: max(1, slices.count),
            charCount: (text as NSString).length
        )
        books.append(book)
        cachedText[id] = text
        cachedSlices[id] = slices
        persistIndex()
        return book
    }

    func remove(_ book: LocalBook) {
        ensureLoaded()
        books.removeAll { $0.id == book.id }
        cachedText.removeValue(forKey: book.id)
        cachedSlices.removeValue(forKey: book.id)
        try? fileManager.removeItem(at: fileURL(for: book))
        persistIndex()
    }

    // MARK: 正文

    func text(for book: LocalBook) throws -> String {
        if let cached = cachedText[book.id] { return cached }
        guard let data = try? Data(contentsOf: fileURL(for: book)) else {
            throw LocalBookError.missingFile
        }
        guard let text = Self.decodeText(data) else {
            throw LocalBookError.unsupportedEncoding
        }
        cachedText[book.id] = text
        return text
    }

    func chapters(for book: LocalBook) throws -> [Chapter] {
        let text = try text(for: book)
        let slices = slices(for: book, text: text)
        if slices.isEmpty {
            return [Chapter(index: 0, title: book.title, url: "local://\(book.id)/0", bookUrl: nil, isVolume: false)]
        }
        return slices.enumerated().map { offset, slice in
            Chapter(
                index: offset,
                title: slice.title.isEmpty ? "第 \(offset + 1) 节" : slice.title,
                url: "local://\(book.id)/\(offset)",
                bookUrl: nil,
                isVolume: false
            )
        }
    }

    func content(for book: LocalBook, chapter: Chapter) throws -> BookContent {
        let text = try text(for: book)
        let slices = slices(for: book, text: text)
        guard chapter.index >= 0, chapter.index < slices.count else {
            throw LocalBookError.missingFile
        }
        let slice = slices[chapter.index]
        let body = (text as NSString).substring(with: slice.range)
        return BookContent(
            content: body,
            title: slice.title.isEmpty ? "第 \(chapter.index + 1) 节" : slice.title,
            index: chapter.index,
            mediaType: "text",
            pages: nil
        )
    }

    // MARK: 进度

    func updateProgress(bookId: String, chapterIndex: Int, chapterOffset: Int, chapterTitle: String) {
        ensureLoaded()
        guard let position = books.firstIndex(where: { $0.id == bookId }) else { return }
        books[position].chapterIndex = max(0, chapterIndex)
        books[position].chapterOffset = max(0, chapterOffset)
        books[position].chapterTitle = chapterTitle
        books[position].lastReadTime = Date().timeIntervalSince1970
        persistIndex()
    }

    // MARK: 切章

    private func slices(for book: LocalBook, text: String) -> [LocalChapterSlice] {
        if let cached = cachedSlices[book.id] { return cached }
        let computed = Self.sliceChapters(text)
        cachedSlices[book.id] = computed
        return computed
    }

    private static func sliceChapters(_ text: String) -> [LocalChapterSlice] {
        let ns = text as NSString
        guard ns.length > 0 else { return [] }

        let pattern = "^[\\s　]*(第[0-9０-９零〇一二三四五六七八九十百千万两]{1,12}[章回节卷部篇话][^\\n]{0,40}|Chapter[ 　]+[0-9]{1,4}[^\\n]{0,40})[\\s　]*$"
        if let regex = try? NSRegularExpression(pattern: pattern, options: [.anchorsMatchLines, .caseInsensitive]) {
            let matches = regex.matches(in: text, range: NSRange(location: 0, length: ns.length))
            if matches.count >= 3 {
                var slices: [LocalChapterSlice] = []
                let firstStart = matches[0].range.location
                if firstStart > 0 {
                    let head = ns.substring(with: NSRange(location: 0, length: firstStart))
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    if !head.isEmpty {
                        slices.append(LocalChapterSlice(title: "前言", range: NSRange(location: 0, length: firstStart)))
                    }
                }
                for (offset, match) in matches.enumerated() {
                    let start = match.range.location
                    let end = offset + 1 < matches.count ? matches[offset + 1].range.location : ns.length
                    let title = ns.substring(with: match.range).trimmingCharacters(in: .whitespacesAndNewlines)
                    slices.append(LocalChapterSlice(title: title, range: NSRange(location: start, length: max(0, end - start))))
                }
                if !slices.isEmpty { return slices }
            }
        }

        // 兜底：没有可识别的章节标题时，按约 8000 字切段，尽量落在换行处。
        var slices: [LocalChapterSlice] = []
        var cursor = 0
        var index = 1
        let chunk = 8000
        while cursor < ns.length {
            var end = min(cursor + chunk, ns.length)
            if end < ns.length {
                let probe = NSRange(location: end, length: min(400, ns.length - end))
                let newline = ns.rangeOfCharacter(from: .newlines, options: [], range: probe)
                if newline.location != NSNotFound {
                    end = newline.location + newline.length
                }
            }
            let length = end - cursor
            guard length > 0 else { break }
            slices.append(LocalChapterSlice(title: "第 \(index) 节", range: NSRange(location: cursor, length: length)))
            cursor = end
            index += 1
        }
        return slices
    }

    // MARK: 编码

    private static func decodeText(_ data: Data) -> String? {
        if let text = String(data: data, encoding: .utf8) { return clean(text) }
        if let text = String(data: data, encoding: .utf16) { return clean(text) }
        let gb18030 = String.Encoding(
            rawValue: CFStringConvertEncodingToNSStringEncoding(
                CFStringEncoding(CFStringEncodings.GB_18030_2000.rawValue)
            )
        )
        if let text = String(data: data, encoding: gb18030) { return clean(text) }
        let big5 = String.Encoding(
            rawValue: CFStringConvertEncodingToNSStringEncoding(
                CFStringEncoding(CFStringEncodings.big5.rawValue)
            )
        )
        if let text = String(data: data, encoding: big5) { return clean(text) }
        return nil
    }

    private static func clean(_ text: String) -> String {
        var value = text
        if value.hasPrefix("\u{FEFF}") {
            value.removeFirst()
        }
        value = value.replacingOccurrences(of: "\r\n", with: "\n")
        value = value.replacingOccurrences(of: "\r", with: "\n")
        return value
    }
}
