import Combine
import Foundation

/// 每本书的累计阅读时长（纯本地统计），书架卡片上显示「读 X 分钟」。
/// 键与置顶表一致：服务端书用 `bookUrl`，本地 TXT 用 `local:<LocalBook.id>`。
/// 同时按天记一份，用来算本周、日均这些汇总。
/// 存 Documents/liubai-reading-stats.json。
final class ReadingStatsStore: ObservableObject {
    static let shared = ReadingStatsStore()

    @Published private(set) var seconds: [String: Double] = [:]
    /// 按天累计，键是 yyyy-MM-dd。
    @Published private(set) var daily: [String: Double] = [:]
    /// 每本书的书名，统计明细里不用再回头查书架。
    @Published private(set) var names: [String: String] = [:]

    private let fileURL: URL
    private var lastSave = Date.distantPast

    private struct Snapshot: Codable {
        var seconds: [String: Double]
        var daily: [String: Double]?
        var names: [String: String]?
    }

    private static let dayFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()

    private init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        fileURL = documents.appendingPathComponent("liubai-reading-stats.json")
        load()
    }

    // MARK: - 键

    static func key(bookURL: String) -> String { bookURL }

    static func key(localID: String) -> String { "local:\(localID)" }

    static func dayKey(_ date: Date = Date()) -> String { dayFormatter.string(from: date) }

    // MARK: - 读写

    func seconds(for key: String) -> Double {
        seconds[key] ?? 0
    }

    func add(_ delta: Double, for key: String, name: String? = nil) {
        guard delta > 0, !key.isEmpty else { return }
        seconds[key, default: 0] += delta
        daily[Self.dayKey(), default: 0] += delta
        if let name, !name.isEmpty, names[key] != name {
            names[key] = name
        }
        // 阅读时每 5 秒累加一次，写盘再节流到 25 秒一次，避免频繁 IO。
        if Date().timeIntervalSince(lastSave) > 25 {
            save()
        }
    }

    func reset(_ key: String) {
        guard seconds[key] != nil else { return }
        seconds.removeValue(forKey: key)
        names.removeValue(forKey: key)
        save()
    }

    func flush() {
        save()
    }

    // MARK: - 汇总

    /// 所有书加起来读了多久。
    var totalSeconds: Double { seconds.values.reduce(0, +) }

    /// 读超过 1 分钟的书算「读过的书」。
    var bookCount: Int { seconds.values.filter { $0 >= 60 }.count }

    /// 统计明细用的书目：读过 30 秒以上的按累计时长从多到少排。
    var rankedKeys: [String] {
        seconds
            .filter { $0.value >= 30 }
            .sorted { $0.value > $1.value }
            .map { $0.key }
    }

    /// 某本书的书名（读过时记下来的），没有就返回 nil。
    func name(for key: String) -> String? {
        guard let name = names[key], !name.isEmpty else { return nil }
        return name
    }

    var todaySeconds: Double { daily[Self.dayKey()] ?? 0 }

    /// 最近 n 天（含今天）一共读了多久。
    func seconds(inLastDays days: Int) -> Double {
        let calendar = Calendar.current
        var total: Double = 0
        for offset in 0..<max(days, 0) {
            guard let date = calendar.date(byAdding: .day, value: -offset, to: Date()) else { continue }
            total += daily[Self.dayKey(date)] ?? 0
        }
        return total
    }

    /// 最近 n 天的日均。
    func averagePerDay(inLastDays days: Int) -> Double {
        seconds(inLastDays: days) / Double(max(days, 1))
    }

    /// 最近 n 天里每一天的秒数，从早到晚，方便画小柱状图。
    func recentDays(_ days: Int) -> [(date: Date, seconds: Double)] {
        let calendar = Calendar.current
        var result: [(date: Date, seconds: Double)] = []
        for offset in stride(from: max(days - 1, 0), through: 0, by: -1) {
            guard let date = calendar.date(byAdding: .day, value: -offset, to: Date()) else { continue }
            result.append((date, daily[Self.dayKey(date)] ?? 0))
        }
        return result
    }

    // MARK: - 持久化

    private func load() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        if let snapshot = try? JSONDecoder().decode(Snapshot.self, from: data) {
            seconds = snapshot.seconds
            daily = snapshot.daily ?? [:]
            names = snapshot.names ?? [:]
        } else if let legacy = try? JSONDecoder().decode([String: Double].self, from: data) {
            // 兼容 1.25 之前只记总时长的旧文件。
            seconds = legacy
        }
    }

    private func save() {
        lastSave = Date()
        let snapshot = Snapshot(seconds: seconds, daily: daily, names: names)
        guard let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}

enum ReadingDuration {
    /// 「读 12 分钟」/「读 1 小时 20 分」；不足 1 分钟返回 nil，卡片上就不占一行。
    static func text(_ seconds: Double) -> String? {
        let minutes = Int(seconds / 60)
        guard minutes >= 1 else { return nil }
        if minutes < 60 { return "读 \(minutes) 分钟" }
        let hours = minutes / 60
        let rest = minutes % 60
        return rest == 0 ? "读 \(hours) 小时" : "读 \(hours) 小时 \(rest) 分"
    }

    /// 不带「读」字的短格式，统计页用。
    static func compact(_ seconds: Double) -> String {
        let minutes = Int(seconds / 60)
        guard minutes >= 1 else { return "0 分钟" }
        if minutes < 60 { return "\(minutes) 分钟" }
        let hours = minutes / 60
        let rest = minutes % 60
        return rest == 0 ? "\(hours) 小时" : "\(hours) 小时 \(rest) 分"
    }

    /// 按书明细用：精确到分钟，不足 1 分钟单独说明，读满整点小时就不带零头。
    static func detail(_ seconds: Double) -> String {
        guard seconds >= 60 else { return "不足 1 分钟" }
        let minutes = Int(seconds / 60)
        if minutes < 60 { return "\(minutes) 分钟" }
        let hours = minutes / 60
        let rest = minutes % 60
        return rest == 0 ? "\(hours) 小时" : "\(hours) 小时 \(rest) 分钟"
    }
}
