import Foundation

// MARK: - 动态 JSON
//
// 留白·Legado Web 的 Book 对象允许携带任意扩展字段（例如书源规则变量 `variable`），
// 搜索 → 详情 → 正文 的链路依赖这些字段原样回传。这里用 JSONValue 保存未知字段，
// 保证客户端不会在网络往返中丢失数据。
enum JSONValue: Codable, Hashable {
    case string(String)
    case number(Double)
    case bool(Bool)
    case object([String: JSONValue])
    case array([JSONValue])
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode(Double.self) {
            self = .number(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else if let value = try? container.decode([JSONValue].self) {
            self = .array(value)
        } else if let value = try? container.decode([String: JSONValue].self) {
            self = .object(value)
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "不支持的 JSON 值")
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .string(let value): try container.encode(value)
        case .number(let value): try container.encode(value)
        case .bool(let value): try container.encode(value)
        case .object(let value): try container.encode(value)
        case .array(let value): try container.encode(value)
        case .null: try container.encodeNil()
        }
    }

    var stringValue: String? {
        if case .string(let value) = self { return value }
        return nil
    }

    var intValue: Int? {
        if case .number(let value) = self { return Int(value) }
        return nil
    }
}

struct DynamicCodingKey: CodingKey {
    var stringValue: String
    var intValue: Int?

    init(_ string: String) {
        stringValue = string
        intValue = nil
    }

    init?(stringValue: String) {
        self.stringValue = stringValue
        self.intValue = nil
    }

    init?(intValue: Int) {
        self.stringValue = String(intValue)
        self.intValue = intValue
    }
}

// MARK: - 账号

struct AuthUser: Codable, Identifiable, Hashable {
    var id: String
    var username: String
    var role: String
    var disabled: Bool?
    var createdAt: Double?
    var canMigrateLegacy: Bool?

    var isAdmin: Bool { role == "admin" }
}

struct MeResponse: Codable {
    var user: AuthUser?
}

struct LoginResponse: Codable {
    var user: AuthUser
}

struct HealthResponse: Codable {
    var ok: Bool?
}

// MARK: - 书源

struct SourceHealth: Codable, Hashable {
    var archived: Bool?
}

struct BookSourceSummary: Codable, Identifiable, Hashable {
    var bookSourceUrl: String
    var bookSourceName: String
    var bookSourceGroup: String?
    var enabled: Bool?
    var bookSourceType: Int?
    var sourceHealth: SourceHealth?

    var id: String { bookSourceUrl }
    var isArchived: Bool { sourceHealth?.archived ?? false }
}

// MARK: - 书籍

struct Book: Codable, Identifiable, Hashable {
    var bookUrl: String
    var name: String
    var author: String
    var origin: String
    var originName: String?
    var coverUrl: String?
    var intro: String?
    var kind: String?
    var tocUrl: String?
    var totalChapterNum: Int?
    var durChapterIndex: Int?
    var durChapterPos: Int?
    var durChapterTitle: String?
    var lastReadTime: Double?
    var addedAt: Double?
    var inShelf: Bool?
    var mediaType: String?
    var sourceRevision: String?
    var sourceVariants: [Book]?
    /// 服务端返回的未知字段，原样保留后在请求中原样回传。
    var extra: [String: JSONValue]

    var id: String { bookUrl }

    static func == (lhs: Book, rhs: Book) -> Bool {
        lhs.bookUrl == rhs.bookUrl
            && lhs.name == rhs.name
            && lhs.author == rhs.author
            && lhs.sourceRevision == rhs.sourceRevision
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(bookUrl)
        hasher.combine(sourceRevision)
    }

    init(
        bookUrl: String,
        name: String,
        author: String = "",
        origin: String,
        originName: String? = nil,
        coverUrl: String? = nil,
        intro: String? = nil,
        kind: String? = nil,
        tocUrl: String? = nil,
        totalChapterNum: Int? = nil,
        durChapterIndex: Int? = nil,
        durChapterPos: Int? = nil,
        durChapterTitle: String? = nil,
        lastReadTime: Double? = nil,
        addedAt: Double? = nil,
        inShelf: Bool? = nil,
        mediaType: String? = nil,
        sourceRevision: String? = nil,
        sourceVariants: [Book]? = nil,
        extra: [String: JSONValue] = [:]
    ) {
        self.bookUrl = bookUrl
        self.name = name
        self.author = author
        self.origin = origin
        self.originName = originName
        self.coverUrl = coverUrl
        self.intro = intro
        self.kind = kind
        self.tocUrl = tocUrl
        self.totalChapterNum = totalChapterNum
        self.durChapterIndex = durChapterIndex
        self.durChapterPos = durChapterPos
        self.durChapterTitle = durChapterTitle
        self.lastReadTime = lastReadTime
        self.addedAt = addedAt
        self.inShelf = inShelf
        self.mediaType = mediaType
        self.sourceRevision = sourceRevision
        self.sourceVariants = sourceVariants
        self.extra = extra
    }

    private enum CodingKeys: String, CodingKey {
        case bookUrl, name, author, origin, originName, coverUrl, intro, kind, tocUrl
        case totalChapterNum, durChapterIndex, durChapterPos, durChapterTitle
        case lastReadTime, addedAt, inShelf, mediaType, sourceRevision, sourceVariants
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        bookUrl = try container.decode(String.self, forKey: .bookUrl)
        name = try container.decode(String.self, forKey: .name)
        author = (try? container.decode(String.self, forKey: .author)) ?? ""
        origin = (try? container.decode(String.self, forKey: .origin)) ?? ""
        originName = try? container.decodeIfPresent(String.self, forKey: .originName)
        coverUrl = try? container.decodeIfPresent(String.self, forKey: .coverUrl)
        intro = try? container.decodeIfPresent(String.self, forKey: .intro)
        kind = try? container.decodeIfPresent(String.self, forKey: .kind)
        tocUrl = try? container.decodeIfPresent(String.self, forKey: .tocUrl)
        totalChapterNum = try? container.decodeIfPresent(Int.self, forKey: .totalChapterNum)
        durChapterIndex = try? container.decodeIfPresent(Int.self, forKey: .durChapterIndex)
        durChapterPos = try? container.decodeIfPresent(Int.self, forKey: .durChapterPos)
        durChapterTitle = try? container.decodeIfPresent(String.self, forKey: .durChapterTitle)
        lastReadTime = try? container.decodeIfPresent(Double.self, forKey: .lastReadTime)
        addedAt = try? container.decodeIfPresent(Double.self, forKey: .addedAt)
        inShelf = try? container.decodeIfPresent(Bool.self, forKey: .inShelf)
        mediaType = try? container.decodeIfPresent(String.self, forKey: .mediaType)
        sourceRevision = try? container.decodeIfPresent(String.self, forKey: .sourceRevision)
        sourceVariants = try? container.decodeIfPresent([Book].self, forKey: .sourceVariants)

        var extras: [String: JSONValue] = [:]
        if let dynamic = try? decoder.container(keyedBy: DynamicCodingKey.self) {
            for key in dynamic.allKeys {
                if CodingKeys(rawValue: key.stringValue) != nil { continue }
                if let value = try? dynamic.decode(JSONValue.self, forKey: key) {
                    extras[key.stringValue] = value
                }
            }
        }
        extra = extras
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(bookUrl, forKey: .bookUrl)
        try container.encode(name, forKey: .name)
        try container.encode(author, forKey: .author)
        try container.encode(origin, forKey: .origin)
        try container.encodeIfPresent(originName, forKey: .originName)
        try container.encodeIfPresent(coverUrl, forKey: .coverUrl)
        try container.encodeIfPresent(intro, forKey: .intro)
        try container.encodeIfPresent(kind, forKey: .kind)
        try container.encodeIfPresent(tocUrl, forKey: .tocUrl)
        try container.encodeIfPresent(totalChapterNum, forKey: .totalChapterNum)
        try container.encodeIfPresent(durChapterIndex, forKey: .durChapterIndex)
        try container.encodeIfPresent(durChapterPos, forKey: .durChapterPos)
        try container.encodeIfPresent(durChapterTitle, forKey: .durChapterTitle)
        try container.encodeIfPresent(lastReadTime, forKey: .lastReadTime)
        try container.encodeIfPresent(addedAt, forKey: .addedAt)
        try container.encodeIfPresent(inShelf, forKey: .inShelf)
        try container.encodeIfPresent(mediaType, forKey: .mediaType)
        try container.encodeIfPresent(sourceRevision, forKey: .sourceRevision)
        try container.encodeIfPresent(sourceVariants, forKey: .sourceVariants)

        var dynamic = encoder.container(keyedBy: DynamicCodingKey.self)
        for (key, value) in extra {
            if CodingKeys(rawValue: key) != nil { continue }
            try dynamic.encode(value, forKey: DynamicCodingKey(key))
        }
    }

    var progressFraction: Double {
        guard let index = durChapterIndex, let total = totalChapterNum, total > 0 else { return 0 }
        return min(1, max(0, Double(index + 1) / Double(total)))
    }

    var lastReadText: String {
        guard let time = lastReadTime, time > 0 else { return "未读" }
        let date = Date(timeIntervalSince1970: time / 1000)
        let formatter = RelativeDateTimeFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.unitsStyle = .short
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

// MARK: - 目录与正文

struct Chapter: Codable, Identifiable, Hashable {
    var index: Int
    var title: String
    var url: String
    var bookUrl: String?
    var isVolume: Bool?

    var id: Int { index }
    var isTitleOnly: Bool { isVolume ?? false }
}

struct ComicPage: Codable, Hashable {
    var id: String
    var index: Int
    var url: String
    var width: Int?
    var height: Int?
}

struct BookContent: Codable {
    var content: String
    var title: String
    var index: Int
    var mediaType: String?
    var pages: [ComicPage]?
}

struct BookDetailsResult: Codable {
    var book: Book
    var chapters: [Chapter]
    var chaptersError: String?
}

// MARK: - 搜索

struct SearchError: Codable, Hashable {
    var source: String
    var message: String
}

struct SearchResult: Codable {
    var books: [Book]
    var errors: [SearchError]
}

struct SearchProgress: Codable, Hashable {
    var total: Int
    var completed: Int
    var failed: Int
    var found: Int
    var elapsedMs: Double?

    var fraction: Double {
        guard total > 0 else { return 0 }
        return min(1, max(0, Double(completed) / Double(total)))
    }
}

struct SearchEvent: Codable {
    var type: String
    var progress: SearchProgress?
    var sourceUrl: String?
    var sourceName: String?
    var books: [Book]?
    var error: SearchError?
    var reason: String?
}

// MARK: - 进度

struct ProgressResult: Codable {
    var ok: Bool
    var book: Book?
}

struct SimpleOK: Codable {
    var ok: Bool?
}
