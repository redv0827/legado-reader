import Foundation

// MARK: - 动态 JSON
//
// 留白·Legado Web 的 Book 对象允许携带任意扩展字段（例如书源规则变量 `variable`），
// 搜索 → 详情 → 正文 的链路依赖这些字段原样回传。这里用 JSONValue 保存未知字段，
// 保证客户端不会在网络往返中丢失数据。
enum JSONValue: Codable, Hashable {
    case string(String)
    case number(Double)
    case bool(Bool)
    case object([String: JSONValue])
    case array([JSONValue])
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode(Double.self) {
            self = .number(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else if let value = try? container.decode([JSONValue].self) {
            self = .array(value)
        } else if let value = try? container.decode([String: JSONValue].self) {
            self = .object(value)
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "不支持的 JSON 值")
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .string(let value): try container.encode(value)
        case .number(let value): try container.encode(value)
        case .bool(let value): try container.encode(value)
        case .object(let value): try container.encode(value)
        case .array(let value): try container.encode(value)
        case .null: try container.encodeNil()
        }
    }

    var stringValue: String? {
        if case .string(let value) = self { return value }
        return nil
    }

    var intValue: Int? {
        if case .number(let value) = self { return Int(value) }
        return nil
    }
}

struct DynamicCodingKey: CodingKey {
    var stringValue: String
    var intValue: Int?

    init(_ string: String) {
        stringValue = string
        intValue = nil
    }

    init?(stringValue: String) {
        self.stringValue = stringValue
        self.intValue = nil
    }

    init?(intValue: Int) {
        self.stringValue = String(intValue)
        self.intValue = intValue
    }
}

// MARK: - 账号

struct AuthUser: Codable, Identifiable, Hashable {
    var id: String
    var username: String
    var role: String
    var disabled: Bool?
    var createdAt: Double?
    var canMigrateLegacy: Bool?

    var isAdmin: Bool {
        let normalized = role.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return normalized == "admin" || normalized == "administrator" || normalized == "superadmin"
    }
}

struct MeResponse: Codable {
    var user: AuthUser?
}

struct LoginResponse: Codable {
    var user: AuthUser
}

struct HealthResponse: Codable {
    var ok: Bool?
}

// MARK: - 书源

struct SourceHealth: Codable, Hashable {
    var archived: Bool?
}

/// Legado 书源的 `bookSourceType` 含义：
/// 0 = 文本（小说）、1 = 音频、2 = 图片（漫画）、3 = 文件。
enum BookMediaKind: String, CaseIterable, Identifiable, Hashable {
    case text
    case comic
    case audio
    case file

    var id: String { rawValue }

    var title: String {
        switch self {
        case .text: return "小说"
        case .comic: return "漫画"
        case .audio: return "音频"
        case .file: return "文件"
        }
    }

    var icon: String {
        switch self {
        case .text: return "text.book.closed"
        case .comic: return "photo.on.rectangle"
        case .audio: return "waveform"
        case .file: return "doc"
        }
    }

    /// 搜索接口使用的 media 参数。
    var searchMedia: String {
        switch self {
        case .text: return "text"
        case .comic: return "image"
        case .audio: return "audio"
        case .file: return "file"
        }
    }

    init(typeCode: Int?) {
        switch typeCode {
        case 1: self = .audio
        case 2: self = .comic
        case 3: self = .file
        default: self = .text
        }
    }
}

struct BookSourceSummary: Codable, Identifiable, Hashable {
    var bookSourceUrl: String
    var bookSourceName: String
    var bookSourceGroup: String?
    var enabled: Bool?
    var bookSourceType: Int?
    var sourceHealth: SourceHealth?

    var id: String { bookSourceUrl }
    var isArchived: Bool { sourceHealth?.archived ?? false }
    var mediaKind: BookMediaKind { BookMediaKind(typeCode: bookSourceType) }
}

// MARK: - 书籍

struct Book: Codable, Identifiable, Hashable {
    var bookUrl: String
    var name: String
    var author: String
    var origin: String
    var originName: String?
    var coverUrl: String?
    var intro: String?
    var kind: String?
    var tocUrl: String?
    var totalChapterNum: Int?
    var durChapterIndex: Int?
    var durChapterPos: Int?
    var durChapterTitle: String?
    var lastReadTime: Double?
    var addedAt: Double?
    var inShelf: Bool?
    var mediaType: String?
    var sourceRevision: String?
    var sourceVariants: [Book]?
    /// 服务端返回的未知字段，原样保留后在请求中原样回传。
    var extra: [String: JSONValue]

    var id: String { bookUrl }

    /// 书源规则在搜索时带回的「最新章节」标题，还没取到目录时先用它顶着。
    var lastChapterHint: String {
        for key in ["lastChapter", "latestChapter", "newChapter", "lastChapterTitle"] {
            if let value = extra[key]?.stringValue {
                let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty { return trimmed }
            }
        }
        return ""
    }

    /// 书源给的正文字数，支持「123万」「1.2亿」「1,234,567」这类写法。
    var wordCountValue: Int {
        let raw = (extra["wordCount"]?.stringValue ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return 0 }
        var digits = ""
        for character in raw where character.isNumber || character == "." {
            digits.append(character)
        }
        guard let value = Double(digits), value > 0 else { return 0 }
        let multiplier: Double = raw.contains("亿") ? 100_000_000 : (raw.contains("万") ? 10_000 : 1)
        return Int(value * multiplier)
    }

    /// 排源用的体量权重：优先真实字数，没有字数就按章数估。
    var sourceWeight: Int {
        if wordCountValue > 0 { return wordCountValue }
        if let total = totalChapterNum, total > 0 { return total * 2_500 }
        return 0
    }

    static func == (lhs: Book, rhs: Book) -> Bool {
        lhs.bookUrl == rhs.bookUrl
            && lhs.name == rhs.name
            && lhs.author == rhs.author
            && lhs.sourceRevision == rhs.sourceRevision
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(bookUrl)
        hasher.combine(sourceRevision)
    }

    init(
        bookUrl: String,
        name: String,
        author: String = "",
        origin: String,
        originName: String? = nil,
        coverUrl: String? = nil,
        intro: String? = nil,
        kind: String? = nil,
        tocUrl: String? = nil,
        totalChapterNum: Int? = nil,
        durChapterIndex: Int? = nil,
        durChapterPos: Int? = nil,
        durChapterTitle: String? = nil,
        lastReadTime: Double? = nil,
        addedAt: Double? = nil,
        inShelf: Bool? = nil,
        mediaType: String? = nil,
        sourceRevision: String? = nil,
        sourceVariants: [Book]? = nil,
        extra: [String: JSONValue] = [:]
    ) {
        self.bookUrl = bookUrl
        self.name = name
        self.author = author
        self.origin = origin
        self.originName = originName
        self.coverUrl = coverUrl
        self.intro = intro
        self.kind = kind
        self.tocUrl = tocUrl
        self.totalChapterNum = totalChapterNum
        self.durChapterIndex = durChapterIndex
        self.durChapterPos = durChapterPos
        self.durChapterTitle = durChapterTitle
        self.lastReadTime = lastReadTime
        self.addedAt = addedAt
        self.inShelf = inShelf
        self.mediaType = mediaType
        self.sourceRevision = sourceRevision
        self.sourceVariants = sourceVariants
        self.extra = extra
    }

    private enum CodingKeys: String, CodingKey {
        case bookUrl, name, author, origin, originName, coverUrl, intro, kind, tocUrl
        case totalChapterNum, durChapterIndex, durChapterPos, durChapterTitle
        case lastReadTime, addedAt, inShelf, mediaType, sourceRevision, sourceVariants
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        bookUrl = try container.decode(String.self, forKey: .bookUrl)
        name = try container.decode(String.self, forKey: .name)
        author = (try? container.decode(String.self, forKey: .author)) ?? ""
        origin = (try? container.decode(String.self, forKey: .origin)) ?? ""
        originName = try? container.decodeIfPresent(String.self, forKey: .originName)
        coverUrl = try? container.decodeIfPresent(String.self, forKey: .coverUrl)
        intro = try? container.decodeIfPresent(String.self, forKey: .intro)
        kind = try? container.decodeIfPresent(String.self, forKey: .kind)
        tocUrl = try? container.decodeIfPresent(String.self, forKey: .tocUrl)
        totalChapterNum = try? container.decodeIfPresent(Int.self, forKey: .totalChapterNum)
        durChapterIndex = try? container.decodeIfPresent(Int.self, forKey: .durChapterIndex)
        durChapterPos = try? container.decodeIfPresent(Int.self, forKey: .durChapterPos)
        durChapterTitle = try? container.decodeIfPresent(String.self, forKey: .durChapterTitle)
        lastReadTime = try? container.decodeIfPresent(Double.self, forKey: .lastReadTime)
        addedAt = try? container.decodeIfPresent(Double.self, forKey: .addedAt)
        inShelf = try? container.decodeIfPresent(Bool.self, forKey: .inShelf)
        mediaType = try? container.decodeIfPresent(String.self, forKey: .mediaType)
        sourceRevision = try? container.decodeIfPresent(String.self, forKey: .sourceRevision)
        sourceVariants = try? container.decodeIfPresent([Book].self, forKey: .sourceVariants)

        var extras: [String: JSONValue] = [:]
        if let dynamic = try? decoder.container(keyedBy: DynamicCodingKey.self) {
            for key in dynamic.allKeys {
                if CodingKeys(rawValue: key.stringValue) != nil { continue }
                if let value = try? dynamic.decode(JSONValue.self, forKey: key) {
                    extras[key.stringValue] = value
                }
            }
        }
        extra = extras
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(bookUrl, forKey: .bookUrl)
        try container.encode(name, forKey: .name)
        try container.encode(author, forKey: .author)
        try container.encode(origin, forKey: .origin)
        try container.encodeIfPresent(originName, forKey: .originName)
        try container.encodeIfPresent(coverUrl, forKey: .coverUrl)
        try container.encodeIfPresent(intro, forKey: .intro)
        try container.encodeIfPresent(kind, forKey: .kind)
        try container.encodeIfPresent(tocUrl, forKey: .tocUrl)
        try container.encodeIfPresent(totalChapterNum, forKey: .totalChapterNum)
        try container.encodeIfPresent(durChapterIndex, forKey: .durChapterIndex)
        try container.encodeIfPresent(durChapterPos, forKey: .durChapterPos)
        try container.encodeIfPresent(durChapterTitle, forKey: .durChapterTitle)
        try container.encodeIfPresent(lastReadTime, forKey: .lastReadTime)
        try container.encodeIfPresent(addedAt, forKey: .addedAt)
        try container.encodeIfPresent(inShelf, forKey: .inShelf)
        try container.encodeIfPresent(mediaType, forKey: .mediaType)
        try container.encodeIfPresent(sourceRevision, forKey: .sourceRevision)
        try container.encodeIfPresent(sourceVariants, forKey: .sourceVariants)

        var dynamic = encoder.container(keyedBy: DynamicCodingKey.self)
        for (key, value) in extra {
            if CodingKeys(rawValue: key) != nil { continue }
            try dynamic.encode(value, forKey: DynamicCodingKey(key))
        }
    }

    var progressFraction: Double {
        guard let index = durChapterIndex, let total = totalChapterNum, total > 0 else { return 0 }
        return min(1, max(0, Double(index + 1) / Double(total)))
    }

    var lastReadText: String {
        guard let time = lastReadTime, time > 0 else { return "未读" }
        let date = Date(timeIntervalSince1970: time / 1000)
        let formatter = RelativeDateTimeFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.unitsStyle = .short
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

// MARK: - 目录与正文

struct Chapter: Codable, Identifiable, Hashable {
    var index: Int
    var title: String
    var url: String
    var bookUrl: String?
    var isVolume: Bool?

    var id: Int { index }
    var isTitleOnly: Bool { isVolume ?? false }
}

struct ComicPage: Codable, Hashable {
    var id: String
    var index: Int
    var url: String
    var width: Int?
    var height: Int?
}

struct BookContent: Codable {
    var content: String
    var title: String
    var index: Int
    var mediaType: String?
    var pages: [ComicPage]?
}

struct BookDetailsResult: Codable {
    var book: Book
    var chapters: [Chapter]
    var chaptersError: String?
}

/// 服务端换源结果：book 为新来源的书，message 可直接展示给用户。
struct SourceSwitchResult: Codable {
    var book: Book
    var match: String?
    var message: String?
}

// MARK: - 搜索

struct SearchError: Codable, Hashable {
    var source: String
    var message: String
}

struct SearchResult: Codable {
    var books: [Book]
    var errors: [SearchError]
}

struct SearchProgress: Codable, Hashable {
    var total: Int
    var completed: Int
    var failed: Int
    var found: Int
    var elapsedMs: Double?

    var fraction: Double {
        guard total > 0 else { return 0 }
        return min(1, max(0, Double(completed) / Double(total)))
    }
}

struct SearchEvent: Codable {
    var type: String
    var progress: SearchProgress?
    var sourceUrl: String?
    var sourceName: String?
    var books: [Book]?
    var error: SearchError?
    var reason: String?
}

// MARK: - 进度

struct ProgressResult: Codable {
    var ok: Bool
    var book: Book?
}

struct SimpleOK: Codable {
    var ok: Bool?
}

// MARK: - 书源巡检

struct SourceHealthRecord: Codable, Hashable {
    var archived: Bool?
    var consecutiveFailures: Int?
    var lastCheckedAt: Double?
    var lastSucceededAt: Double?
    var lastError: String?
    var archivedAt: Double?
}

struct SourceHealthSource: Codable, Identifiable, Hashable {
    var url: String
    var name: String
    var enabled: Bool?
    var health: SourceHealthRecord?

    var id: String { url }
    var isArchived: Bool { health?.archived ?? false }
}

struct SourceHealthStatus: Codable {
    var running: Bool?
    var enabled: Bool?
    var intervalMs: Double?
    var timeoutMs: Double?
    var failureThreshold: Int?
    var probeKeyword: String?
    var nextScanAt: Double?
    var lastStartedAt: Double?
    var lastFinishedAt: Double?
    var lastError: String?
    var checked: Int?
    var total: Int?
    var sources: [SourceHealthSource]?
}

// MARK: - 完整书源（管理员书源管理用）

/// 服务端 `/api/sources` 的完整书源对象。规则字段结构不固定，
/// 用 `extra` 原样保留未知字段，回传（保存/启停）时不丢失规则。
struct BookSource: Codable, Identifiable, Hashable {
    var bookSourceUrl: String
    var bookSourceName: String
    var bookSourceGroup: String?
    var enabled: Bool
    var bookSourceType: Int?
    var extra: [String: JSONValue]

    var id: String { bookSourceUrl }
    var mediaKind: BookMediaKind { BookMediaKind(typeCode: bookSourceType) }

    init(
        bookSourceUrl: String,
        bookSourceName: String,
        bookSourceGroup: String? = nil,
        enabled: Bool = true,
        bookSourceType: Int? = nil,
        extra: [String: JSONValue] = [:]
    ) {
        self.bookSourceUrl = bookSourceUrl
        self.bookSourceName = bookSourceName
        self.bookSourceGroup = bookSourceGroup
        self.enabled = enabled
        self.bookSourceType = bookSourceType
        self.extra = extra
    }

    private enum CodingKeys: String, CodingKey {
        case bookSourceUrl, bookSourceName, bookSourceGroup, enabled, bookSourceType
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        bookSourceUrl = try container.decode(String.self, forKey: .bookSourceUrl)
        bookSourceName = try container.decode(String.self, forKey: .bookSourceName)
        bookSourceGroup = try? container.decodeIfPresent(String.self, forKey: .bookSourceGroup)
        enabled = (try? container.decodeIfPresent(Bool.self, forKey: .enabled)) ?? true
        bookSourceType = try? container.decodeIfPresent(Int.self, forKey: .bookSourceType)

        var extras: [String: JSONValue] = [:]
        if let dynamic = try? decoder.container(keyedBy: DynamicCodingKey.self) {
            for key in dynamic.allKeys {
                if CodingKeys(rawValue: key.stringValue) != nil { continue }
                if let value = try? dynamic.decode(JSONValue.self, forKey: key) {
                    extras[key.stringValue] = value
                }
            }
        }
        extra = extras
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(bookSourceUrl, forKey: .bookSourceUrl)
        try container.encode(bookSourceName, forKey: .bookSourceName)
        try container.encodeIfPresent(bookSourceGroup, forKey: .bookSourceGroup)
        try container.encode(enabled, forKey: .enabled)
        try container.encodeIfPresent(bookSourceType, forKey: .bookSourceType)

        var dynamic = encoder.container(keyedBy: DynamicCodingKey.self)
        for (key, value) in extra {
            if CodingKeys(rawValue: key) != nil { continue }
            try dynamic.encode(value, forKey: DynamicCodingKey(key))
        }
    }
}
