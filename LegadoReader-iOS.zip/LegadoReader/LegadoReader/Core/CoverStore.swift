import Foundation
import Combine

/// 封面缓存。
///
/// 服务端书架接口返回的书常常没有封面图（coverUrl 为空），
/// 这里按 bookUrl 存一份从「书籍详情」补抓到的封面地址，
/// 存 `Documents/liubai-covers.json`。
/// 空字符串表示「抓过，这个书源确实没有封面」，避免每次进书架都重试。
final class CoverStore: ObservableObject {
    static let shared = CoverStore()

    @Published private(set) var store: [String: String] = [:]

    /// 网络抖动导致抓取失败的，本轮不记，下次进书架再试。
    private let fileURL: URL
    private var loaded = false

    private init() {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = dir.appendingPathComponent("liubai-covers.json")
        load()
    }

    func cover(for bookURL: String) -> String? {
        guard let value = store[bookURL], !value.isEmpty else { return nil }
        return value
    }

    /// 是否已经尝试抓过（成功拿到地址，或明确没有封面）。
    func attempted(_ bookURL: String) -> Bool {
        store[bookURL] != nil
    }

    func remember(_ cover: String?, for bookURL: String) {
        let value = (cover ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard store[bookURL] != value else { return }
        store[bookURL] = value
        save()
    }

    func forget(_ bookURL: String) {
        guard store.removeValue(forKey: bookURL) != nil else { return }
        save()
    }

    private func load() {
        guard !loaded else { return }
        loaded = true
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([String: String].self, from: data)
        else { return }
        store = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(store) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
