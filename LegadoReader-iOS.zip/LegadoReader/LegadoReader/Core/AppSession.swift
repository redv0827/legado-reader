import Foundation

/// 登录状态与服务器地址。所有界面共享同一个 APIClient 实例。
@MainActor
final class AppSession: ObservableObject {
    enum Phase: Equatable {
        case checking
        case needLogin
        case ready
    }

    @Published var phase: Phase = .checking
    @Published var serverAddress: String
    @Published var user: AuthUser?
    @Published var lastError: String?

    let api = APIClient()

    private let addressKey = "server.address"

    init() {
        serverAddress = UserDefaults.standard.string(forKey: addressKey) ?? ""
        api.onUnauthorized = { [weak self] in
            Task { @MainActor in
                self?.handleUnauthorized()
            }
        }
    }

    var isLoggedIn: Bool { user != nil }

    // MARK: - 地址

    static func normalizeAddress(_ text: String) -> URL? {
        var value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }
        if !value.lowercased().hasPrefix("http://") && !value.lowercased().hasPrefix("https://") {
            value = "http://" + value
        }
        guard var components = URLComponents(string: value), let host = components.host, !host.isEmpty else {
            return nil
        }
        components.query = nil
        components.fragment = nil
        var path = components.path
        while path.hasSuffix("/") && path.count > 1 {
            path.removeLast()
        }
        components.path = path == "/" ? "" : path
        return components.url
    }

    func rememberAddress() {
        UserDefaults.standard.set(serverAddress, forKey: addressKey)
    }

    // MARK: - 生命周期

    func bootstrap() async {
        phase = .checking
        lastError = nil
        guard let url = Self.normalizeAddress(serverAddress) else {
            phase = .needLogin
            lastError = "请填写服务器地址，例如 http://192.168.1.20:3001"
            return
        }
        rememberAddress()
        api.configure(baseURL: url, userId: nil)
        do {
            try await api.health()
            if let user = try await api.me() {
                self.user = user
                api.configure(baseURL: url, userId: user.id)
                phase = .ready
            } else {
                api.clearSession()
                phase = .needLogin
            }
        } catch {
            // 网络不通时不强求重新登录，留在登录页并给出提示。
            lastError = error.localizedDescription
            phase = .needLogin
        }
    }

    func login(username: String, password: String) async throws {
        guard let url = Self.normalizeAddress(serverAddress) else {
            throw APIError(status: -1, message: "服务器地址无效")
        }
        api.configure(baseURL: url, userId: nil)
        do {
            try await api.health()
        } catch {
            throw APIError(status: -1, message: "无法连接服务器：\(error.localizedDescription)")
        }
        let user = try await api.login(username: username, password: password)
        self.user = user
        api.configure(baseURL: url, userId: user.id)
        rememberAddress()
        lastError = nil
        phase = .ready
    }

    func logout() async {
        try? await api.logout()
        user = nil
        api.configure(baseURL: Self.normalizeAddress(serverAddress), userId: nil)
        phase = .needLogin
    }

    func changeServer(_ text: String) {
        serverAddress = text
    }

    /// 修改服务器地址后清空登录态，避免旧 Cookie 被新服务器误用。
    func switchServer(_ text: String) {
        serverAddress = text
        user = nil
        api.clearSession()
        api.configure(baseURL: Self.normalizeAddress(text), userId: nil)
        phase = .needLogin
        rememberAddress()
    }

    private func handleUnauthorized() {
        guard user != nil else { return }
        user = nil
        api.clearSession()
        api.configure(baseURL: Self.normalizeAddress(serverAddress), userId: nil)
        phase = .needLogin
        lastError = "登录状态已失效，请重新登录"
    }
}
