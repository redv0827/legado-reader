import Foundation
import Security

/// 服务器会话 Cookie 的本地保存。
/// 服务端会话使用 HttpOnly + SameSite=Strict 的 Cookie；原生 App 没有浏览器同站概念，
/// 这里手动保存并从请求头回传，避免 CFNetwork 的 Cookie 策略差异。
struct StoredCookie: Codable {
    var name: String
    var value: String
    var expiresAt: Date?
}

enum CookieStore {
    private static let key = "session.cookie"

    static func load() -> StoredCookie? {
        guard let data = Keychain.readData(account: key) else { return nil }
        return try? JSONDecoder().decode(StoredCookie.self, from: data)
    }

    static func save(_ cookie: StoredCookie?) {
        guard let cookie else {
            Keychain.delete(account: key)
            return
        }
        guard let data = try? JSONEncoder().encode(cookie) else { return }
        Keychain.write(data, account: key)
    }

    /// 从响应头里解析 legado_session Cookie。服务端只会下发这一枚会话 Cookie。
    static func capture(from response: HTTPURLResponse, cookieName: String = "legado_session") -> StoredCookie? {
        guard let header = response.value(forHTTPHeaderField: "Set-Cookie") else { return nil }
        guard let range = header.range(of: "\(cookieName)=") else { return nil }
        let remainder = header[range.upperBound...]
        let value = remainder.split(separator: ";").first.map(String.init) ?? ""
        guard !value.isEmpty else { return nil }

        var expires: Date?
        for piece in header.split(separator: ";") {
            let trimmed = piece.trimmingCharacters(in: .whitespaces)
            let lower = trimmed.lowercased()
            if lower.hasPrefix("max-age=") {
                if let seconds = Double(trimmed.dropFirst("max-age=".count)) {
                    expires = seconds <= 0 ? Date() : Date().addingTimeInterval(seconds)
                }
            }
        }
        return StoredCookie(name: cookieName, value: value, expiresAt: expires)
    }
}

enum Keychain {
    private static let service = "com.liubai.reader"

    static func readData(account: String) -> Data? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess else { return nil }
        return item as? Data
    }

    static func write(_ data: Data, account: String) {
        delete(account: account)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock,
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    static func delete(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        SecItemDelete(query as CFDictionary)
    }
}
