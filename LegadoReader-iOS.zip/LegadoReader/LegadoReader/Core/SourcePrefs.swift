import Foundation

/// 本地数据文件（书源开关覆盖、精确搜索备忘）统一放 Documents 下，
/// 便于「存储空间」页统计与清理，不占用 UserDefaults。
enum LocalDataFiles {
    static let sourceOverrideName = "liubai-source-prefs.json"
    static let exactMemoName = "liubai-exact-sources.json"

    static var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
    }

    static func url(_ name: String) -> URL {
        documentsDirectory.appendingPathComponent(name)
    }

    static func size(of url: URL) -> Int64 {
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
              let number = attributes[.size] as? NSNumber else { return 0 }
        return number.int64Value
    }
}

/// 书源开关的本地覆盖表。
/// 服务端的 `enabled` 只作为默认值，用户手动改过的源记在这里，
/// 因此不需要管理员权限也能自由开关书源。
final class SourcePrefs {
    static let shared = SourcePrefs()

    private let fileURL = LocalDataFiles.url(LocalDataFiles.sourceOverrideName)
    private var overlays: [String: Bool] = [:]
    private let lock = NSLock()

    init() {
        load()
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([String: Bool].self, from: data) else { return }
        overlays = decoded
    }

    /// 生效值：本地覆盖优先，没有覆盖时用服务端值。
    func isEnabled(url: String, serverEnabled: Bool) -> Bool {
        lock.lock()
        defer { lock.unlock() }
        return overlays[url] ?? serverEnabled
    }

    func overlay(for url: String) -> Bool? {
        lock.lock()
        defer { lock.unlock() }
        return overlays[url]
    }

    var overrideCount: Int {
        lock.lock()
        defer { lock.unlock() }
        return overlays.count
    }

    func set(_ enabled: Bool, for urls: [String]) {
        lock.lock()
        for url in urls where !url.isEmpty {
            overlays[url] = enabled
        }
        let snapshot = overlays
        lock.unlock()
        persist(snapshot)
    }

    /// 撤掉本地覆盖，回到服务端设定。
    func reset(urls: [String]) {
        lock.lock()
        for url in urls {
            overlays.removeValue(forKey: url)
        }
        let snapshot = overlays
        lock.unlock()
        persist(snapshot)
    }

    func clear() {
        lock.lock()
        overlays = [:]
        lock.unlock()
        try? FileManager.default.removeItem(at: fileURL)
    }

    private func persist(_ snapshot: [String: Bool]) {
        guard let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    var fileSize: Int64 {
        LocalDataFiles.size(of: fileURL)
    }
}

/// 一次精确搜索命中的书源集合，1 小时内有效，最多保留 20 个书名。
struct ExactSourceHit: Codable {
    var key: String
    var displayName: String
    var books: [Book]
    var savedAt: Date
}

/// 精确搜索结果备忘：进书详情换源时立刻能看到上次命中的精确书源。
final class ExactSourceMemo {
    static let shared = ExactSourceMemo()
    static let ttl: TimeInterval = 3600
    static let limit = 20

    private let fileURL = LocalDataFiles.url(LocalDataFiles.exactMemoName)
    private var entries: [ExactSourceHit] = []

    init() {
        load()
        prune()
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([ExactSourceHit].self, from: data) else { return }
        entries = decoded
    }

    private func persist() {
        guard let data = try? JSONEncoder().encode(entries) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    static func normalize(_ text: String) -> String {
        text
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "　", with: "")
            .replacingOccurrences(of: "（", with: "(")
            .replacingOccurrences(of: "）", with: ")")
            .replacingOccurrences(of: "【", with: "[")
            .replacingOccurrences(of: "】", with: "]")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    /// 记录一次精确搜索（同一书名多次命中会合并去重）。
    func record(name: String, books: [Book]) {
        let key = Self.normalize(name)
        guard !key.isEmpty, !books.isEmpty else { return }

        var trimmed: [Book] = []
        for book in books where !book.bookUrl.isEmpty {
            if trimmed.contains(where: { $0.bookUrl == book.bookUrl }) { continue }
            trimmed.append(
                Book(
                    bookUrl: book.bookUrl,
                    name: book.name,
                    author: book.author,
                    origin: book.origin,
                    originName: book.originName,
                    coverUrl: book.coverUrl,
                    intro: book.intro.map { String($0.prefix(180)) },
                    totalChapterNum: book.totalChapterNum,
                    mediaType: book.mediaType
                )
            )
        }

        entries.removeAll { $0.key == key }
        entries.insert(
            ExactSourceHit(key: key, displayName: name, books: trimmed, savedAt: Date()),
            at: 0
        )
        prune()
        persist()
    }

    /// 读取某本书在上次精确搜索里命中的书源（1 小时内有效）。
    func books(for name: String) -> [Book] {
        let key = Self.normalize(name)
        prune()
        guard let hit = entries.first(where: { $0.key == key }) else { return [] }
        guard Date().timeIntervalSince(hit.savedAt) <= Self.ttl else {
            entries.removeAll { $0.key == key }
            persist()
            return []
        }
        return hit.books
    }

    /// 最近一次精确搜索命中的书名与时间，用于换源面板提示。
    func hit(for name: String) -> ExactSourceHit? {
        let key = Self.normalize(name)
        prune()
        guard let hit = entries.first(where: { $0.key == key }) else { return nil }
        guard Date().timeIntervalSince(hit.savedAt) <= Self.ttl else { return nil }
        return hit
    }

    var count: Int {
        prune()
        return entries.count
    }

    private func prune() {
        let now = Date()
        var changed = false
        let kept = entries.filter { now.timeIntervalSince($0.savedAt) <= Self.ttl }
        if kept.count != entries.count {
            entries = kept
            changed = true
        }
        if entries.count > Self.limit {
            entries = Array(entries.prefix(Self.limit))
            changed = true
        }
        if changed { persist() }
    }

    func clear() {
        entries = []
        try? FileManager.default.removeItem(at: fileURL)
    }

    var fileSize: Int64 {
        LocalDataFiles.size(of: fileURL)
    }
}

/// 每本书换源时点过的源，用于换源面板「换过的置底」排序。
final class SourceSwitchHistory {
    static let shared = SourceSwitchHistory()
    private static let perBookLimit = 30

    private let fileURL = LocalDataFiles.url("liubai-source-switch.json")
    private var history: [String: [String]] = [:]
    private let lock = NSLock()

    init() {
        load()
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([String: [String]].self, from: data) else { return }
        history = decoded
    }

    private func persist(_ snapshot: [String: [String]]) {
        guard let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    func record(bookName: String, sourceURL: String) {
        let key = ExactSourceMemo.normalize(bookName)
        guard !key.isEmpty, !sourceURL.isEmpty else { return }
        lock.lock()
        var list = history[key] ?? []
        list.removeAll { $0 == sourceURL }
        list.insert(sourceURL, at: 0)
        if list.count > Self.perBookLimit {
            list = Array(list.prefix(Self.perBookLimit))
        }
        history[key] = list
        let snapshot = history
        lock.unlock()
        persist(snapshot)
    }

    func used(bookName: String) -> Set<String> {
        let key = ExactSourceMemo.normalize(bookName)
        lock.lock()
        defer { lock.unlock() }
        return Set(history[key] ?? [])
    }

    func clear() {
        lock.lock()
        history = [:]
        lock.unlock()
        try? FileManager.default.removeItem(at: fileURL)
    }

    var fileSize: Int64 {
        LocalDataFiles.size(of: fileURL)
    }
}
