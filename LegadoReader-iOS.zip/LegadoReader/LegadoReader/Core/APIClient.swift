import Foundation

struct APIError: LocalizedError {
    let status: Int
    let message: String

    var errorDescription: String? { message }
    var isUnauthorized: Bool { status == 401 }
}

/// 留白·Legado Web 的原生客户端。
/// 只与自建服务端的 `/api` 交互，书源规则全部由服务端 Java 核心执行。
final class APIClient {
    private var baseURL: URL?
    private var userId: String?
    var onUnauthorized: (() -> Void)?

    private let session: URLSession
    private var cookie: StoredCookie?

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.httpShouldSetCookies = false
        configuration.httpCookieAcceptPolicy = .never
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 300
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)
        cookie = CookieStore.load()
    }

    // MARK: - 配置

    func configure(baseURL: URL?, userId: String?) {
        self.baseURL = baseURL
        self.userId = userId
    }

    func clearSession() {
        cookie = nil
        CookieStore.save(nil)
    }

    var hasSessionCookie: Bool {
        guard let cookie else { return false }
        if let expires = cookie.expiresAt, expires < Date() { return false }
        return true
    }

    /// 把服务端返回的相对地址（封面、漫画页）解析为绝对地址。
    func resolve(_ path: String?) -> URL? {
        guard let path, !path.isEmpty else { return nil }
        if let absolute = URL(string: path), absolute.scheme?.hasPrefix("http") == true {
            return absolute
        }
        guard let base = baseURL else { return nil }
        if path.hasPrefix("/") {
            return URL(string: path, relativeTo: base)?.absoluteURL
        }
        return URL(string: path, relativeTo: base)?.absoluteURL
    }

    // MARK: - 底层请求

    private func makeRequest(
        _ path: String,
        method: String = "GET",
        query: [String: String] = [:],
        body: Data? = nil
    ) throws -> URLRequest {
        guard let base = baseURL else {
            throw APIError(status: -1, message: "还没有设置服务器地址")
        }
        guard var components = URLComponents(url: base, resolvingAgainstBaseURL: false) else {
            throw APIError(status: -1, message: "服务器地址无效")
        }
        var basePath = components.path
        if basePath.hasSuffix("/") { basePath.removeLast() }
        let targetPath = path.hasPrefix("/") ? path : "/" + path
        components.path = basePath + targetPath
        if !query.isEmpty {
            components.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        guard let url = components.url else {
            throw APIError(status: -1, message: "请求地址无效")
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let userId {
            request.setValue(userId, forHTTPHeaderField: "X-Legado-User-Id")
        }
        if let cookie, cookie.expiresAt.map({ $0 > Date() }) ?? true {
            request.setValue("\(cookie.name)=\(cookie.value)", forHTTPHeaderField: "Cookie")
        }
        if let body {
            request.httpBody = body
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return request
    }

    private func jsonBody<T: Encodable>(_ value: T) throws -> Data {
        let encoder = JSONEncoder()
        do {
            return try encoder.encode(value)
        } catch {
            throw APIError(status: -1, message: "请求数据编码失败")
        }
    }

    private func perform(_ request: URLRequest) async throws -> Data {
        let result: (Data, URLResponse)
        do {
            result = try await session.data(for: request)
        } catch let error as URLError {
            throw APIError(status: error.errorCode, message: Self.describe(error))
        }
        let data = result.0
        let response = result.1
        guard let http = response as? HTTPURLResponse else {
            throw APIError(status: -1, message: "服务器响应异常")
        }
        if let captured = CookieStore.capture(from: http) {
            cookie = captured
            CookieStore.save(captured)
        }
        if http.statusCode == 401 {
            onUnauthorized?()
        }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError(status: http.statusCode, message: Self.errorMessage(from: data, status: http.statusCode))
        }
        return data
    }

    private func decode<T: Decodable>(_ type: T.Type, from data: Data) throws -> T {
        do {
            return try JSONDecoder().decode(type, from: data)
        } catch {
            throw APIError(status: -2, message: "返回数据解析失败：\(error.localizedDescription)")
        }
    }

    private static func errorMessage(from data: Data, status: Int) -> String {
        if let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let message = object["error"] as? String,
           !message.isEmpty {
            return message
        }
        switch status {
        case 403: return "访问被拒绝：请确认服务端已配置 LEGADO_PUBLIC_ORIGIN 为当前访问地址"
        case 404: return "接口或资源不存在"
        case 409: return "数据已变化，请刷新后重试"
        case 422: return "书源规则无法解析该页面"
        case 429: return "请求过于频繁，请稍后重试"
        case 500: return "服务端处理失败，请查看服务端日志"
        default: return "服务器返回错误（HTTP \(status)）"
        }
    }

    private static func describe(_ error: URLError) -> String {
        switch error.code {
        case .notConnectedToInternet: return "网络未连接"
        case .cannotFindHost, .cannotConnectToHost: return "无法连接服务器，请检查地址与网络"
        case .timedOut: return "连接超时，书源可能较慢，请稍后重试"
        case .appTransportSecurityRequiresSecureConnection: return "系统拦截了明文 HTTP 请求"
        case .networkConnectionLost: return "网络连接中断"
        default: return "网络请求失败：\(error.localizedDescription)"
        }
    }

    // MARK: - 账号

    func health() async throws {
        let request = try makeRequest("/api/health")
        _ = try await perform(request)
    }

    func me() async throws -> AuthUser? {
        let request = try makeRequest("/api/auth/me")
        let data = try await perform(request)
        return try decode(MeResponse.self, from: data).user
    }

    struct LoginBody: Encodable {
        var username: String
        var password: String
    }

    func login(username: String, password: String) async throws -> AuthUser {
        let body = try jsonBody(LoginBody(username: username, password: password))
        let request = try makeRequest("/api/auth/login", method: "POST", body: body)
        let data = try await perform(request)
        let user = try decode(LoginResponse.self, from: data).user
        userId = user.id
        return user
    }

    func logout() async throws {
        let request = try makeRequest("/api/auth/logout", method: "POST", body: Data("{}".utf8))
        _ = try? await perform(request)
        clearSession()
    }

    // MARK: - 书架

    func shelf() async throws -> [Book] {
        let request = try makeRequest("/api/shelf")
        let data = try await perform(request)
        return try decode([Book].self, from: data)
    }

    func sources() async throws -> [BookSourceSummary] {
        let request = try makeRequest("/api/sources", query: ["summary": "1"])
        let data = try await perform(request)
        return try decode([BookSourceSummary].self, from: data)
    }

    func bookDetails(_ book: Book) async throws -> BookDetailsResult {
        let body = try jsonBody(book)
        let request = try makeRequest("/api/book/details", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(BookDetailsResult.self, from: data)
    }

    func saveBook(_ book: Book) async throws -> Book {
        let body = try jsonBody(book)
        let request = try makeRequest("/api/shelf", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(Book.self, from: data)
    }

    /// 把书架里的书换到另一个书源；服务端会校验新来源的目录与正文后再原子替换。
    func switchSource(bookUrl: String, target: Book) async throws -> SourceSwitchResult {
        struct Body: Encodable {
            var bookUrl: String
            var target: Book
        }
        let body = try jsonBody(Body(bookUrl: bookUrl, target: target))
        let request = try makeRequest("/api/shelf/source", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(SourceSwitchResult.self, from: data)
    }

    func removeBook(bookUrl: String) async throws {
        struct Body: Encodable { var bookUrl: String }
        let body = try jsonBody(Body(bookUrl: bookUrl))
        let request = try makeRequest("/api/shelf", method: "DELETE", body: body)
        _ = try await perform(request)
    }

    // MARK: - 搜索

    private var activeSearchTask: Task<Void, Never>?

    /// 主动停止当前增量搜索，服务端会因连接断开而停止派发。
    func cancelSearch() {
        activeSearchTask?.cancel()
        activeSearchTask = nil
    }

    /// 增量搜索：服务端逐源返回 NDJSON 事件，界面可以边搜边显示。
    func searchEvents(key: String, sourceUrl: String?, mode: String = "all", resume: Bool = false) -> AsyncThrowingStream<SearchEvent, Error> {
        activeSearchTask?.cancel()
        return AsyncThrowingStream<SearchEvent, Error> { continuation in
            let task = Task { [weak self] in
                guard let self else {
                    continuation.finish()
                    return
                }
                do {
                    var query = ["key": key, "media": "text", "page": "1", "mode": mode]
                    if resume { query["resume"] = "1" }
                    if let sourceUrl, !sourceUrl.isEmpty {
                        query["source"] = sourceUrl
                    }
                    let request = try self.makeRequest("/api/search/stream", query: query)
                    let (bytes, response) = try await self.session.bytes(for: request)
                    guard let http = response as? HTTPURLResponse else {
                        throw APIError(status: -1, message: "服务器响应异常")
                    }
                    if http.statusCode == 401 { self.onUnauthorized?() }
                    guard http.statusCode == 200 else {
                        throw APIError(
                            status: http.statusCode,
                            message: http.statusCode == 403
                                ? "访问被拒绝：请确认服务端 LEGADO_PUBLIC_ORIGIN 配置"
                                : "搜索失败（HTTP \(http.statusCode)）"
                        )
                    }
                    let decoder = JSONDecoder()
                    for try await line in bytes.lines {
                        if Task.isCancelled { break }
                        let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty, let data = trimmed.data(using: .utf8) else { continue }
                        if let event = try? decoder.decode(SearchEvent.self, from: data) {
                            continuation.yield(event)
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
            self.activeSearchTask = task
            continuation.onTermination = { _ in task.cancel() }
        }
    }

    // MARK: - 目录与正文

    func chapters(url: String, refresh: Bool = false) async throws -> [Chapter] {
        var query = ["url": url, "cached": refresh ? "0" : "1"]
        if refresh { query["refresh"] = "1" }
        let request = try makeRequest("/api/chapters", query: query)
        let data = try await perform(request)
        return try decode([Chapter].self, from: data)
    }

    func content(
        url: String,
        index: Int,
        origin: String?,
        sourceRevision: String?,
        chapterUrl: String?
    ) async throws -> BookContent {
        var query = ["url": url, "index": String(index)]
        if let origin { query["expectedOrigin"] = origin }
        if let sourceRevision { query["sourceRevision"] = sourceRevision }
        if let chapterUrl { query["expectedChapterUrl"] = chapterUrl }
        let request = try makeRequest("/api/content", query: query)
        let data = try await perform(request)
        return try decode(BookContent.self, from: data)
    }

    // MARK: - 书源与巡检

    func sourceHealthStatus() async throws -> SourceHealthStatus {
        let request = try makeRequest("/api/source-health")
        let data = try await perform(request)
        return try decode(SourceHealthStatus.self, from: data)
    }

    func sourceHealthScan() async throws -> SourceHealthStatus {
        let request = try makeRequest("/api/source-health/scan", method: "POST", body: Data("{}".utf8))
        let data = try await perform(request)
        return try decode(SourceHealthStatus.self, from: data)
    }

    func sourceHealthRestore(url: String) async throws -> SourceHealthStatus {
        struct Body: Encodable { var url: String }
        let body = try jsonBody(Body(url: url))
        let request = try makeRequest("/api/source-health/restore", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(SourceHealthStatus.self, from: data)
    }

    func fullSources() async throws -> [BookSource] {
        let request = try makeRequest("/api/sources")
        let data = try await perform(request)
        return try decode([BookSource].self, from: data)
    }

    func saveSources(_ sources: [BookSource]) async throws -> [BookSource] {
        let body = try jsonBody(sources)
        let request = try makeRequest("/api/sources", method: "POST", body: body)
        let data = try await perform(request)
        return try decode([BookSource].self, from: data)
    }

    func deleteSources(_ urls: [String]) async throws -> [BookSource] {
        struct Body: Encodable { var urls: [String] }
        let body = try jsonBody(Body(urls: urls))
        let request = try makeRequest("/api/sources", method: "DELETE", body: body)
        let data = try await perform(request)
        return try decode([BookSource].self, from: data)
    }

    /// 给单个书源测速 + 质量检测：按关键词搜索，记录耗时、错误、命中数量与简介字数。
    /// 独立请求，不占用搜索增量流，可并发。
    func probeSource(
        url: String,
        keyword: String = "测试",
        media: String = "text"
    ) async -> SourceProbeOutcome {
        let start = Date()
        do {
            let query = ["key": keyword, "media": media, "page": "1", "mode": "quick", "source": url]
            let request = try makeRequest("/api/search/stream", query: query)
            let (bytes, response) = try await session.bytes(for: request)
            guard let http = response as? HTTPURLResponse else {
                throw APIError(status: -1, message: "服务器响应异常")
            }
            if http.statusCode == 401 { onUnauthorized?() }
            guard http.statusCode == 200 else {
                throw APIError(status: http.statusCode, message: "HTTP \(http.statusCode)")
            }
            let decoder = JSONDecoder()
            var lastError: String?
            var matched: [Book] = []
            for try await line in bytes.lines {
                let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !trimmed.isEmpty, let data = trimmed.data(using: .utf8) else { continue }
                guard let event = try? decoder.decode(SearchEvent.self, from: data) else { continue }
                if let err = event.error { lastError = err.message }
                if let books = event.books, !books.isEmpty {
                    for book in books where Self.matches(book, keyword: keyword) {
                        if !matched.contains(where: { $0.bookUrl == book.bookUrl }) {
                            matched.append(book)
                        }
                    }
                }
                if event.type == "done" { break }
            }
            let longestIntro = matched
                .map { ($0.intro ?? "").trimmingCharacters(in: .whitespacesAndNewlines).count }
                .max() ?? 0
            return SourceProbeOutcome(
                milliseconds: Date().timeIntervalSince(start) * 1000,
                error: lastError,
                bookCount: matched.count,
                introLength: longestIntro
            )
        } catch {
            return SourceProbeOutcome(
                milliseconds: Date().timeIntervalSince(start) * 1000,
                error: error.localizedDescription,
                bookCount: 0,
                introLength: 0
            )
        }
    }

    /// 轻量探活：直接请求书源首页，只看能否连通，不解析、不搜索。
    /// 用独立的临时会话，避免把服务端 Cookie 带到第三方站点。
    func probeReachability(
        _ urlString: String,
        timeout: TimeInterval = 4
    ) async -> (ok: Bool, milliseconds: Double?, error: String?) {
        guard let url = URL(string: urlString), let scheme = url.scheme, !scheme.isEmpty else {
            return (false, nil, "地址无效")
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = timeout
        request.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue("text/html,*/*;q=0.8", forHTTPHeaderField: "Accept")
        let start = Date()
        do {
            let (_, response) = try await Self.probeSession.data(for: request)
            let ms = Date().timeIntervalSince(start) * 1000
            guard let http = response as? HTTPURLResponse else {
                return (false, ms, "站点无响应")
            }
            let ok = (200..<400).contains(http.statusCode)
            return (ok, ms, ok ? nil : "HTTP \(http.statusCode)")
        } catch {
            return (false, Date().timeIntervalSince(start) * 1000, error.localizedDescription)
        }
    }

    private static let probeSession: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 6
        config.timeoutIntervalForResource = 8
        config.httpMaximumConnectionsPerHost = 4
        return URLSession(configuration: config)
    }()

    private static func matches(_ book: Book, keyword: String) -> Bool {
        let key = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return true }
        if book.name.contains(key) { return true }
        if book.author.contains(key) { return true }
        // 部分站点会把书名改写（如「斗破苍穹（完结）」），用首两个字兜底匹配。
        if key.count >= 2, book.name.contains(String(key.prefix(2))) { return true }
        return false
    }

    // MARK: - 进度

    struct ProgressBody: Encodable {
        var bookUrl: String
        var origin: String
        var sourceRevision: String?
        var durChapterIndex: Int
        var durChapterPos: Int
        var durChapterTitle: String?
    }

    func saveProgress(
        bookUrl: String,
        origin: String,
        sourceRevision: String?,
        chapterIndex: Int,
        chapterOffset: Int,
        chapterTitle: String
    ) async throws {
        let body = try jsonBody(
            ProgressBody(
                bookUrl: bookUrl,
                origin: origin,
                sourceRevision: sourceRevision,
                durChapterIndex: chapterIndex,
                durChapterPos: max(0, chapterOffset),
                durChapterTitle: chapterTitle
            )
        )
        let request = try makeRequest("/api/progress", method: "POST", body: body)
        _ = try await perform(request)
    }
}

/// 单个书源的检测结果。
struct SourceProbeOutcome {
    var milliseconds: Double?
    var error: String?
    var bookCount: Int
    var introLength: Int

    /// 无错误、有命中、简介字数足够，才算可用书源。
    var isUsable: Bool {
        error == nil && bookCount > 0 && introLength >= 40
    }

    var failReason: String? {
        if let error, !error.isEmpty { return error }
        if bookCount == 0 { return "搜索无结果" }
        if introLength < 40 { return "结果字数过少（简介 \(introLength) 字）" }
        return nil
    }
}
