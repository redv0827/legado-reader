import Foundation

struct APIError: LocalizedError {
    let status: Int
    let message: String

    var errorDescription: String? { message }
    var isUnauthorized: Bool { status == 401 }
}

/// 留白·Legado Web 的原生客户端。
/// 只与自建服务端的 `/api` 交互，书源规则全部由服务端 Java 核心执行。
final class APIClient {
    private var baseURL: URL?
    private var userId: String?
    var onUnauthorized: (() -> Void)?

    private let session: URLSession
    private var cookie: StoredCookie?

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.httpShouldSetCookies = false
        configuration.httpCookieAcceptPolicy = .never
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 300
        // 书源检测是 14 路并发打到同一个 host，默认 6 条连接会把并发吞掉，提速白做。
        configuration.httpMaximumConnectionsPerHost = 20
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)
        cookie = CookieStore.load()
    }

    // MARK: - 配置

    func configure(baseURL: URL?, userId: String?) {
        self.baseURL = baseURL
        self.userId = userId
    }

    func clearSession() {
        cookie = nil
        CookieStore.save(nil)
    }

    var hasSessionCookie: Bool {
        guard let cookie else { return false }
        if let expires = cookie.expiresAt, expires < Date() { return false }
        return true
    }

    /// 把服务端返回的相对地址（封面、漫画页）解析为绝对地址。
    func resolve(_ path: String?) -> URL? {
        guard let path, !path.isEmpty else { return nil }
        if let absolute = URL(string: path), absolute.scheme?.hasPrefix("http") == true {
            return absolute
        }
        guard let base = baseURL else { return nil }
        if path.hasPrefix("/") {
            return URL(string: path, relativeTo: base)?.absoluteURL
        }
        return URL(string: path, relativeTo: base)?.absoluteURL
    }

    // MARK: - 底层请求

    private func makeRequest(
        _ path: String,
        method: String = "GET",
        query: [String: String] = [:],
        body: Data? = nil
    ) throws -> URLRequest {
        guard let base = baseURL else {
            throw APIError(status: -1, message: "还没有设置服务器地址")
        }
        guard var components = URLComponents(url: base, resolvingAgainstBaseURL: false) else {
            throw APIError(status: -1, message: "服务器地址无效")
        }
        var basePath = components.path
        if basePath.hasSuffix("/") { basePath.removeLast() }
        let targetPath = path.hasPrefix("/") ? path : "/" + path
        components.path = basePath + targetPath
        if !query.isEmpty {
            components.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        guard let url = components.url else {
            throw APIError(status: -1, message: "请求地址无效")
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let userId {
            request.setValue(userId, forHTTPHeaderField: "X-Legado-User-Id")
        }
        if let cookie, cookie.expiresAt.map({ $0 > Date() }) ?? true {
            request.setValue("\(cookie.name)=\(cookie.value)", forHTTPHeaderField: "Cookie")
        }
        if let body {
            request.httpBody = body
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return request
    }

    private func jsonBody<T: Encodable>(_ value: T) throws -> Data {
        let encoder = JSONEncoder()
        do {
            return try encoder.encode(value)
        } catch {
            throw APIError(status: -1, message: "请求数据编码失败")
        }
    }

    private func perform(_ request: URLRequest) async throws -> Data {
        let result: (Data, URLResponse)
        do {
            result = try await session.data(for: request)
        } catch let error as URLError {
            throw APIError(status: error.errorCode, message: Self.describe(error))
        }
        let data = result.0
        let response = result.1
        guard let http = response as? HTTPURLResponse else {
            throw APIError(status: -1, message: "服务器响应异常")
        }
        if let captured = CookieStore.capture(from: http) {
            cookie = captured
            CookieStore.save(captured)
        }
        if http.statusCode == 401 {
            onUnauthorized?()
        }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError(status: http.statusCode, message: Self.errorMessage(from: data, status: http.statusCode))
        }
        return data
    }

    private func decode<T: Decodable>(_ type: T.Type, from data: Data) throws -> T {
        do {
            return try JSONDecoder().decode(type, from: data)
        } catch {
            throw APIError(status: -2, message: "返回数据解析失败：\(error.localizedDescription)")
        }
    }

    private static func errorMessage(from data: Data, status: Int) -> String {
        if let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let message = object["error"] as? String,
           !message.isEmpty {
            return message
        }
        switch status {
        case 403: return "访问被拒绝：请确认服务端已配置 LEGADO_PUBLIC_ORIGIN 为当前访问地址"
        case 404: return "接口或资源不存在"
        case 409: return "数据已变化，请刷新后重试"
        case 422: return "书源规则无法解析该页面"
        case 429: return "请求过于频繁，请稍后重试"
        case 500: return "服务端处理失败，请查看服务端日志"
        default: return "服务器返回错误（HTTP \(status)）"
        }
    }

    private static func describe(_ error: URLError) -> String {
        switch error.code {
        case .notConnectedToInternet: return "网络未连接"
        case .cannotFindHost, .cannotConnectToHost: return "无法连接服务器，请检查地址与网络"
        case .timedOut: return "连接超时，书源可能较慢，请稍后重试"
        case .appTransportSecurityRequiresSecureConnection: return "系统拦截了明文 HTTP 请求"
        case .networkConnectionLost: return "网络连接中断"
        default: return "网络请求失败：\(error.localizedDescription)"
        }
    }

    // MARK: - 账号

    func health() async throws {
        let request = try makeRequest("/api/health")
        _ = try await perform(request)
    }

    func me() async throws -> AuthUser? {
        let request = try makeRequest("/api/auth/me")
        let data = try await perform(request)
        return try decode(MeResponse.self, from: data).user
    }

    struct LoginBody: Encodable {
        var username: String
        var password: String
    }

    func login(username: String, password: String) async throws -> AuthUser {
        let body = try jsonBody(LoginBody(username: username, password: password))
        let request = try makeRequest("/api/auth/login", method: "POST", body: body)
        let data = try await perform(request)
        let user = try decode(LoginResponse.self, from: data).user
        userId = user.id
        return user
    }

    func logout() async throws {
        let request = try makeRequest("/api/auth/logout", method: "POST", body: Data("{}".utf8))
        _ = try? await perform(request)
        clearSession()
    }

    // MARK: - 书架

    func shelf() async throws -> [Book] {
        let request = try makeRequest("/api/shelf")
        let data = try await perform(request)
        return try decode([Book].self, from: data)
    }

    func sources() async throws -> [BookSourceSummary] {
        let request = try makeRequest("/api/sources", query: ["summary": "1"])
        let data = try await perform(request)
        return try decode([BookSourceSummary].self, from: data)
    }

    func bookDetails(_ book: Book) async throws -> BookDetailsResult {
        let body = try jsonBody(book)
        let request = try makeRequest("/api/book/details", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(BookDetailsResult.self, from: data)
    }

    func saveBook(_ book: Book) async throws -> Book {
        let body = try jsonBody(book)
        let request = try makeRequest("/api/shelf", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(Book.self, from: data)
    }

    /// 只把这本书记进「可阅读」里，不进书架：点书源直接读时用这个，
    /// 服务端 saveBook(collect: false) 会把 inShelf 置为 false，书架不会多出一本。
    func prepareReading(_ book: Book) async throws -> Book {
        let body = try jsonBody(book)
        let request = try makeRequest("/api/reading/books", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(Book.self, from: data)
    }

    /// 把书架里的书换到另一个书源；服务端会校验新来源的目录与正文后再原子替换。
    func switchSource(bookUrl: String, target: Book) async throws -> SourceSwitchResult {
        struct Body: Encodable {
            var bookUrl: String
            var target: Book
        }
        let body = try jsonBody(Body(bookUrl: bookUrl, target: target))
        let request = try makeRequest("/api/shelf/source", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(SourceSwitchResult.self, from: data)
    }

    func removeBook(bookUrl: String) async throws {
        struct Body: Encodable { var bookUrl: String }
        let body = try jsonBody(Body(bookUrl: bookUrl))
        let request = try makeRequest("/api/shelf", method: "DELETE", body: body)
        _ = try await perform(request)
    }

    // MARK: - 搜索

    private var activeSearchTask: Task<Void, Never>?

    /// 主动停止当前增量搜索，服务端会因连接断开而停止派发。
    func cancelSearch() {
        activeSearchTask?.cancel()
        activeSearchTask = nil
    }

    /// 增量搜索：服务端逐源返回 NDJSON 事件，界面可以边搜边显示。
    /// `trackAsActive` 为 false 时不会取消、也不登记为当前搜索流，供「只搜启用源」的批量并发使用。
    func searchEvents(
        key: String,
        sourceUrl: String?,
        mode: String = "all",
        resume: Bool = false,
        trackAsActive: Bool = true
    ) -> AsyncThrowingStream<SearchEvent, Error> {
        if trackAsActive {
            activeSearchTask?.cancel()
        }
        return AsyncThrowingStream<SearchEvent, Error> { continuation in
            let task = Task { [weak self] in
                guard let self else {
                    continuation.finish()
                    return
                }
                do {
                    var query = ["key": key, "media": "text", "page": "1", "mode": mode]
                    if resume { query["resume"] = "1" }
                    if let sourceUrl, !sourceUrl.isEmpty {
                        query["source"] = sourceUrl
                    }
                    let request = try self.makeRequest("/api/search/stream", query: query)
                    let (bytes, response) = try await self.session.bytes(for: request)
                    guard let http = response as? HTTPURLResponse else {
                        throw APIError(status: -1, message: "服务器响应异常")
                    }
                    if http.statusCode == 401 { self.onUnauthorized?() }
                    guard http.statusCode == 200 else {
                        throw APIError(
                            status: http.statusCode,
                            message: http.statusCode == 403
                                ? "访问被拒绝：请确认服务端 LEGADO_PUBLIC_ORIGIN 配置"
                                : "搜索失败（HTTP \(http.statusCode)）"
                        )
                    }
                    let decoder = JSONDecoder()
                    for try await line in bytes.lines {
                        if Task.isCancelled { break }
                        let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty, let data = trimmed.data(using: .utf8) else { continue }
                        if let event = try? decoder.decode(SearchEvent.self, from: data) {
                            continuation.yield(event)
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
            if trackAsActive { self.activeSearchTask = task }
            continuation.onTermination = { _ in task.cancel() }
        }
    }

    // MARK: - 目录与正文

    func chapters(url: String, refresh: Bool = false) async throws -> [Chapter] {
        var query = ["url": url, "cached": refresh ? "0" : "1"]
        if refresh { query["refresh"] = "1" }
        let request = try makeRequest("/api/chapters", query: query)
        let data = try await perform(request)
        return try decode([Chapter].self, from: data)
    }

    func content(
        url: String,
        index: Int,
        origin: String?,
        sourceRevision: String?,
        chapterUrl: String?
    ) async throws -> BookContent {
        var query = ["url": url, "index": String(index)]
        if let origin { query["expectedOrigin"] = origin }
        if let sourceRevision { query["sourceRevision"] = sourceRevision }
        if let chapterUrl { query["expectedChapterUrl"] = chapterUrl }
        let request = try makeRequest("/api/content", query: query)
        let data = try await perform(request)
        return try decode(BookContent.self, from: data)
    }

    // MARK: - 书源与巡检

    func sourceHealthStatus() async throws -> SourceHealthStatus {
        let request = try makeRequest("/api/source-health")
        let data = try await perform(request)
        return try decode(SourceHealthStatus.self, from: data)
    }

    func sourceHealthScan() async throws -> SourceHealthStatus {
        let request = try makeRequest("/api/source-health/scan", method: "POST", body: Data("{}".utf8))
        let data = try await perform(request)
        return try decode(SourceHealthStatus.self, from: data)
    }

    func sourceHealthRestore(url: String) async throws -> SourceHealthStatus {
        struct Body: Encodable { var url: String }
        let body = try jsonBody(Body(url: url))
        let request = try makeRequest("/api/source-health/restore", method: "POST", body: body)
        let data = try await perform(request)
        return try decode(SourceHealthStatus.self, from: data)
    }

    func fullSources() async throws -> [BookSource] {
        let request = try makeRequest("/api/sources")
        let data = try await perform(request)
        return try decode([BookSource].self, from: data)
    }

    func saveSources(_ sources: [BookSource]) async throws -> [BookSource] {
        let body = try jsonBody(sources)
        let request = try makeRequest("/api/sources", method: "POST", body: body)
        let data = try await perform(request)
        return try decode([BookSource].self, from: data)
    }

    func deleteSources(_ urls: [String]) async throws -> [BookSource] {
        struct Body: Encodable { var urls: [String] }
        let body = try jsonBody(Body(urls: urls))
        let request = try makeRequest("/api/sources", method: "DELETE", body: body)
        let data = try await perform(request)
        return try decode([BookSource].self, from: data)
    }

    /// 给单个书源测速 + 质量检测：按关键词搜索，记录耗时、错误、命中数量与简介字数。
    /// 独立请求，不占用搜索增量流，可并发。
    /// 第一个关键词没命中时自动换一个备选关键词再试 —— 书源大多只收录部分书，
    /// 单本书搜不到不代表源坏了。
    func probeSource(
        url: String,
        keywords: [String] = ["测试"],
        media: String = "text"
    ) async -> SourceProbeOutcome {
        let cleaned = keywords.filter {
            !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        let plan = Array((cleaned.isEmpty ? ["测试"] : cleaned).prefix(2))
        var best: SourceProbeOutcome?
        for (index, keyword) in plan.enumerated() {
            let outcome = await probeOnce(
                url: url,
                keyword: keyword,
                media: media,
                timeout: index == 0 ? 12 : 10
            )
            if outcome.bookCount > 0, outcome.error == nil { return outcome }
            if let current = best {
                if outcome.bookCount > current.bookCount { best = outcome }
            } else {
                best = outcome
            }
            // 首个关键词就卡在网络层（连不上/超时），换关键词也救不回来。
            if index == 0, outcome.bookCount == 0, let err = outcome.error, Self.isNetworkError(err) {
                return outcome
            }
        }
        return best ?? SourceProbeOutcome(milliseconds: nil, error: "未检测", bookCount: 0, introLength: 0)
    }

    private func probeOnce(
        url: String,
        keyword: String,
        media: String,
        timeout: TimeInterval
    ) async -> SourceProbeOutcome {
        let start = Date()
        do {
            let query = ["key": keyword, "media": media, "page": "1", "mode": "quick", "source": url]
            var request = try makeRequest("/api/search/stream", query: query)
            // 两次数据之间超过 timeout 就断，避免慢源把整批拖住；总时长另有 20 秒硬上限。
            request.timeoutInterval = timeout
            let (bytes, response) = try await session.bytes(for: request)
            guard let http = response as? HTTPURLResponse else {
                throw APIError(status: -1, message: "服务器响应异常")
            }
            if http.statusCode == 401 { onUnauthorized?() }
            guard http.statusCode == 200 else {
                throw APIError(status: http.statusCode, message: "HTTP \(http.statusCode)")
            }
            let decoder = JSONDecoder()
            // 单个源的总时长硬上限：服务端一直吐心跳但迟迟不给 done 时，靠它兜底。
            let deadline = start.addingTimeInterval(max(20, timeout + 8))
            var lastError: String?
            var matched: [Book] = []
            for try await line in bytes.lines {
                if Date() > deadline {
                    // 已经抓到命中结果的话不算失败，只是没等到 done。
                    if matched.isEmpty { lastError = "响应超时（超过 20 秒未返回结果）" }
                    break
                }
                let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !trimmed.isEmpty, let data = trimmed.data(using: .utf8) else { continue }
                guard let event = try? decoder.decode(SearchEvent.self, from: data) else { continue }
                if let err = event.error { lastError = err.message }
                if let books = event.books, !books.isEmpty {
                    for book in books where Self.matches(book, keyword: keyword) {
                        if !matched.contains(where: { $0.bookUrl == book.bookUrl }) {
                            matched.append(book)
                        }
                    }
                }
                if event.type == "done" { break }
            }
            let longestIntro = matched
                .map { ($0.intro ?? "").trimmingCharacters(in: .whitespacesAndNewlines).count }
                .max() ?? 0
            // 命中书里最乱的那段当样本：有的源个别书的简介是从别处抄来的乱码。
            let garbled = matched
                .map { Self.garbledRatio($0.intro ?? "") }
                .max() ?? 0
            return SourceProbeOutcome(
                milliseconds: Date().timeIntervalSince(start) * 1000,
                error: matched.isEmpty ? lastError : nil,
                bookCount: matched.count,
                introLength: longestIntro,
                garbledRatio: garbled
            )
        } catch {
            return SourceProbeOutcome(
                milliseconds: Date().timeIntervalSince(start) * 1000,
                error: error.localizedDescription,
                bookCount: 0,
                introLength: 0
            )
        }
    }

    /// 粗判「错字/乱码」：只抓明显特征 —— 替换符 U+FFFD、方框、控制字符。
    /// 真正的错别字没法在客户端可靠识别，这里只能挡掉乱码成片的那种源。
    static func garbledRatio(_ text: String) -> Double {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 20 else { return 0 }
        var bad = 0
        for scalar in trimmed.unicodeScalars {
            switch scalar.value {
            case 0xFFFD, 0x25A1, 0x25A0, 0x25AF, 0x2610:
                bad += 1
            case 0x0000...0x0008, 0x000B, 0x000C, 0x000E...0x001F:
                bad += 1
            default:
                break
            }
        }
        return Double(bad) / Double(max(trimmed.count, 1))
    }

    /// 网络层错误（连不上、超时、断网）：这类失败换关键词没意义。
    private static func isNetworkError(_ message: String) -> Bool {
        let lower = message.lowercased()
        return lower.contains("timeout")
            || lower.contains("timed out")
            || lower.contains("offline")
            || lower.contains("internet")
            || lower.contains("connection")
            || lower.contains("host")
            || message.contains("超时")
            || message.contains("连接")
            || message.contains("网络")
    }

    /// 轻量探活：直接请求书源首页，只看能否连通，不解析、不搜索。
    /// 用独立的临时会话，避免把服务端 Cookie 带到第三方站点。
    /// 只把「根本连不上」判为失联：首页 403/404/5xx 多半是反爬或路径问题，
    /// 搜索接口往往还是通的，按状态码卡会大面积误杀。
    func probeReachability(
        _ urlString: String,
        timeout: TimeInterval = 6
    ) async -> (ok: Bool, milliseconds: Double?, error: String?) {
        guard let url = URL(string: urlString), let scheme = url.scheme, !scheme.isEmpty else {
            return (false, nil, "地址无效")
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = timeout
        request.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue("text/html,*/*;q=0.8", forHTTPHeaderField: "Accept")
        let start = Date()
        do {
            _ = try await Self.probeSession.data(for: request)
            return (true, Date().timeIntervalSince(start) * 1000, nil)
        } catch {
            return (false, Date().timeIntervalSince(start) * 1000, error.localizedDescription)
        }
    }

    private static let probeSession: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 6
        config.timeoutIntervalForResource = 8
        // 探活是 40 路并发，同一站点常有多个书源，连接池要放开。
        config.httpMaximumConnectionsPerHost = 16
        return URLSession(configuration: config)
    }()

    private static func matches(_ book: Book, keyword: String) -> Bool {
        let key = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return true }
        if book.name.contains(key) { return true }
        if book.author.contains(key) { return true }
        // 部分站点会把书名改写（如「斗破苍穹（完结）」），用首两个字兜底匹配。
        if key.count >= 2, book.name.contains(String(key.prefix(2))) { return true }
        return false
    }

    // MARK: - 进度

    struct ProgressBody: Encodable {
        var bookUrl: String
        var origin: String
        var sourceRevision: String?
        var durChapterIndex: Int
        var durChapterPos: Int
        var durChapterTitle: String?
    }

    func saveProgress(
        bookUrl: String,
        origin: String,
        sourceRevision: String?,
        chapterIndex: Int,
        chapterOffset: Int,
        chapterTitle: String
    ) async throws {
        let body = try jsonBody(
            ProgressBody(
                bookUrl: bookUrl,
                origin: origin,
                sourceRevision: sourceRevision,
                durChapterIndex: chapterIndex,
                durChapterPos: max(0, chapterOffset),
                durChapterTitle: chapterTitle
            )
        )
        let request = try makeRequest("/api/progress", method: "POST", body: body)
        _ = try await perform(request)
    }
}

/// 单个书源的检测结果。
struct SourceProbeOutcome {
    var milliseconds: Double?
    var error: String?
    var bookCount: Int
    var introLength: Int
    /// 简介文本里的乱码/异常字符占比，用来粗判「错字特别多」。
    var garbledRatio: Double = 0

    /// 能用：没有网络层错误。慢不慢、这本题材有没有，都不影响可用。
    var isUsable: Bool {
        guard let error else { return true }
        return error.isEmpty
    }

    /// 乱码明显：替换符、方框、控制字符占比过高。
    var isGarbled: Bool { garbledRatio >= 0.04 }

    /// 低质只有一个口径：打不开，或者正文乱得没法看。
    /// 搜索慢、样本书没收录都不再降级。
    var isPoor: Bool {
        if !isUsable { return true }
        return isGarbled
    }

    /// 优质：能用、有命中，且响应够快、结果里有像样的简介；或极快且命中多。
    var isPremium: Bool {
        guard isUsable, bookCount > 0, let milliseconds, milliseconds > 0 else { return false }
        if milliseconds <= 2500, introLength >= 60 { return true }
        return milliseconds <= 1200 && bookCount >= 5
    }

    var failReason: String? {
        if let error, !error.isEmpty { return error }
        if isGarbled { return "正文乱码偏多（异常字符 \(Int(garbledRatio * 100))%）" }
        return nil
    }
}
