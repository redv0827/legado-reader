import SwiftUI

@main
struct LegadoReaderApp: App {
    @StateObject private var session = AppSession()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .tint(Palette.accent)
                .preferredColorScheme(session.phase == .ready ? nil : .light)
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var session: AppSession

    var body: some View {
        ZStack {
            switch session.phase {
            case .checking:
                LaunchView()
                    .transition(.opacity)
            case .needLogin:
                LoginView()
                    .transition(.opacity)
            case .ready:
                MainTabView()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.22), value: session.phase)
        .task {
            if session.phase == .checking {
                await session.bootstrap()
            }
        }
    }
}

struct LaunchView: View {
    var body: some View {
        ZStack {
            Palette.paper.ignoresSafeArea()
            VStack(spacing: 18) {
                SealMark(size: 64)
                Text("留白")
                    .font(.system(size: 30, weight: .semibold, design: .serif))
                    .foregroundStyle(Palette.ink)
                Text("正在连接阅读服务…")
                    .font(.footnote)
                    .foregroundStyle(Palette.secondaryInk)
                ProgressView()
                    .tint(Palette.accent)
                    .padding(.top, 4)
            }
        }
    }
}

/// 印章风格的 App 标记。
struct SealMark: View {
    var size: CGFloat = 44
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.18, style: .continuous)
                .fill(Palette.accent)
            RoundedRectangle(cornerRadius: size * 0.10, style: .continuous)
                .stroke(Color.white.opacity(0.45), lineWidth: 1)
                .padding(size * 0.09)
            Text("留")
                .font(.system(size: size * 0.5, weight: .semibold, design: .serif))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
    }
}

struct MainTabView: View {
    var body: some View {
        TabView {
            ShelfView()
                .tabItem { Label("书架", systemImage: "books.vertical") }
            SearchView()
                .tabItem { Label("找书", systemImage: "magnifyingglass") }
            SettingsView()
                .tabItem { Label("我的", systemImage: "person.crop.circle") }
        }
    }
}
