import os, zipfile, sys

SRC = r"C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\LegadoReader"
OUT = r"C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\build-out\LegadoReader-iOS.zip"

SKIP_DIRS = {"xcuserdata", "build", ".git"}

os.makedirs(os.path.dirname(OUT), exist_ok=True)
if os.path.exists(OUT):
    os.remove(OUT)

entries = []
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        rel_root = os.path.relpath(root, SRC)
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.normpath(os.path.join("LegadoReader", rel_root, f))
            name = rel.replace(os.sep, "/")
            z.write(full, name)
            entries.append(name)

bad = [e for e in entries if "\\" in e]
lines = []
lines.append("entries=%d" % len(entries))
lines.append("backslash=%d" % len(bad))
lines.append("size=%d" % os.path.getsize(OUT))
lines.append("has_theme=%s" % any(e.endswith("Support/Theme.swift") for e in entries))
lines.append("has_pbxproj=%s" % any(e.endswith("LegadoReader.xcodeproj/project.pbxproj") for e in entries))

# 校验 Theme.swift 里是否已是回绕乘法
with zipfile.ZipFile(OUT) as z:
    theme = z.read("LegadoReader/LegadoReader/Support/Theme.swift").decode("utf-8")
lines.append("wrapping_mul=%s" % ("&* 1099511628211" in theme))

with open(r"C:\Users\Administrator\AppData\Local\Temp\zipcheck.txt", "w", encoding="utf-8") as fh:
    fh.write("\n".join(lines))
