﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

function New-RoundRect([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $d = $r * 2
    $p = [System.Drawing.Drawing2D.GraphicsPath]::new()
    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc(($x + $w - $d), $y, $d, $d, 270, 90)
    $p.AddArc(($x + $w - $d), ($y + $h - $d), $d, $d, 0, 90)
    $p.AddArc($x, ($y + $h - $d), $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}

$paper = [System.Drawing.Color]::FromArgb(250, 246, 238)
$red = [System.Drawing.Color]::FromArgb(184, 54, 44)

$bmp = [System.Drawing.Bitmap]::new(1024, 1024, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$g.Clear($paper)

# 极轻的纸纹
$grain = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(5, 120, 102, 84))
$rnd = [System.Random]::new(7)
for ($i = 0; $i -lt 6000; $i++) {
    $g.FillRectangle($grain, $rnd.Next(0, 1024), $rnd.Next(0, 1024), 2, 2)
}

# 朱红印章
$stampPath = New-RoundRect 238 238 548 548 44
$redBrush = [System.Drawing.SolidBrush]::new($red)
$g.FillPath($redBrush, $stampPath)

# 印章内圈细线
$innerPath = New-RoundRect 276 276 472 472 26
$paperPen = [System.Drawing.Pen]::new($paper, [float]9)
$g.DrawPath($paperPen, $innerPath)

# 白色开卷：左右两页，中间留出红色书脊
$left = [System.Drawing.Drawing2D.GraphicsPath]::new()
$left.AddLine(352, 392, 500, 356)
$left.AddLine(500, 356, 500, 652)
$left.AddBezier(500, 652, 450, 692, 402, 700, 352, 700)
$left.CloseFigure()

$right = [System.Drawing.Drawing2D.GraphicsPath]::new()
$right.AddLine(672, 392, 524, 356)
$right.AddLine(524, 356, 524, 652)
$right.AddBezier(524, 652, 574, 692, 622, 700, 672, 700)
$right.CloseFigure()

$whiteBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
$g.SetClip($stampPath)
$g.FillPath($whiteBrush, $left)
$g.FillPath($whiteBrush, $right)
$g.ResetClip()

# 书页上沿的纸色细边，让开卷更轻
$edgePen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(120, 250, 246, 238), [float]6)
$g.DrawLine($edgePen, 356, 390, 498, 358)
$g.DrawLine($edgePen, 668, 390, 526, 358)

$out = "C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\LegadoReader\LegadoReader\Assets.xcassets\AppIcon.appiconset\AppIcon.png"
New-Item -ItemType Directory -Force -Path (Split-Path $out) | Out-Null
$bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose()
$bmp.Dispose()

$check = [System.Drawing.Image]::FromFile($out)
"$($check.Width)x$($check.Height)  $((Get-Item $out).Length) bytes"
$check.Dispose()