from PIL import Image
import urllib.request, io, os

url = "https://aka.doubaocdn.com/s/4a3qGcXXAU"
out = r"C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\LegadoReader\LegadoReader\Assets.xcassets\AppIcon.appiconset\AppIcon.png"
os.makedirs(os.path.dirname(out), exist_ok=True)
data = urllib.request.urlopen(url, timeout=60).read()
image = Image.open(io.BytesIO(data)).convert("RGB")
image = image.resize((1024, 1024), Image.LANCZOS)
image.save(out, "PNG")
print(image.size, os.path.getsize(out))
