import glob, io, os, re

root = r"C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\LegadoReader\LegadoReader"


def strip_code(src):
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    src = re.sub(r"//[^\n]*", "", src)
    src = re.sub(r'"(?:\\.|[^"\\])*"', '""', src)
    return src


lines = []
for path in sorted(glob.glob(os.path.join(root, "**", "*.swift"), recursive=True)):
    text = io.open(path, encoding="utf-8").read()
    code = strip_code(text)
    pairs = [("{", "}"), ("(", ")"), ("[", "]")]
    bad = []
    for left, right in pairs:
        a = code.count(left)
        b = code.count(right)
        if a != b:
            bad.append("%s%s %d/%d" % (left, right, a, b))
    name = os.path.relpath(path, root).replace("\\", "/")
    lines.append("%-48s %s" % (name, "OK" if not bad else "BAD " + " ".join(bad)))

io.open(r"C:\Users\Administrator\AppData\Local\Temp\swiftcheck.txt", "w", encoding="utf-8").write("\n".join(lines))
