#!/usr/bin/env python3
"""生成 LegadoReader.xcodeproj（显式文件引用，兼容 Xcode 14+）。"""
import hashlib
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_DIR = "LegadoReader"
APP_NAME = "LegadoReader"
BUNDLE_ID = "com.liubai.reader"
DEPLOYMENT_TARGET = "16.0"

SWIFT_FILES = [
    (None, "LegadoReaderApp.swift"),
    ("Core", "Models.swift"),
    ("Core", "APIClient.swift"),
    ("Core", "AppSession.swift"),
    ("Core", "CookieStore.swift"),
    ("Core", "LocalBookStore.swift"),
    ("Support", "Theme.swift"),
    ("Support", "Primitives.swift"),
    ("Features/Auth", "LoginView.swift"),
    ("Features/Shelf", "ShelfView.swift"),
    ("Features/Search", "SearchView.swift"),
    ("Features/Detail", "BookDetailView.swift"),
    ("Features/Reader", "ReaderView.swift"),
    ("Features/Reader", "ReaderController.swift"),
    ("Features/Reader", "ChapterTextView.swift"),
    ("Features/Reader", "PagedTextView.swift"),
    ("Features/Reader", "PagedCurlReader.swift"),
    ("Features/Reader", "ReaderSettingsSheet.swift"),
    ("Features/Reader", "SourceSwitchSheet.swift"),
    ("Features/Reader", "ChapterListView.swift"),
    ("Features/Settings", "SettingsView.swift"),
    ("Features/Settings", "SourceHealthView.swift"),
]


def uid(key: str) -> str:
    return hashlib.md5(key.encode("utf-8")).hexdigest()[:24].upper()


def q(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


GROUP_IDS = {}
GROUP_IDS["main"] = uid("group:main")
GROUP_IDS["products"] = uid("group:products")
GROUP_IDS["app"] = uid("group:app")


def group_id(path: str) -> str:
    if not path:
        return GROUP_IDS["app"]
    key = "group:" + path
    if key not in GROUP_IDS:
        GROUP_IDS[key] = uid(key)
    return GROUP_IDS[key]


for folder, _ in SWIFT_FILES:
    if folder:
        parts = folder.split("/")
        for i in range(len(parts)):
            group_id("/".join(parts[: i + 1]))

TARGET_ID = uid("target:app")
PROJECT_ID = uid("project:app")
PRODUCT_REF = uid("product:app")
ASSETS_REF = uid("file:Assets.xcassets")
PLIST_REF = uid("file:Info.plist")
PROJECT_CONFIG_LIST = uid("configlist:project")
TARGET_CONFIG_LIST = uid("configlist:target")

file_refs = []      # (id, name, path)
build_files = []    # (id, fileRefId, name)
for folder, name in SWIFT_FILES:
    path = f"{folder}/{name}" if folder else name
    file_refs.append((uid("file:" + path), name, path))
    build_files.append((uid("build:" + path), uid("file:" + path), name))

swift_refs_by_folder = {}
for folder, name in SWIFT_FILES:
    path = f"{folder}/{name}" if folder else name
    swift_refs_by_folder.setdefault(folder, []).append((uid("file:" + path), name))

lines = []
lines.append("// !$*UTF8*$!")
lines.append("{")
lines.append("\tarchiveVersion = 1;")
lines.append("\tclasses = {")
lines.append("\t};")
lines.append("\tobjectVersion = 56;")
lines.append("\tobjects = {")

lines.append("")
lines.append("/* Begin PBXBuildFile section */")
for bid, ref, name in build_files:
    lines.append(f"\t\t{bid} /* {name} in Sources */ = {{isa = PBXBuildFile; fileRef = {ref} /* {name} */; }};")
assets_build = uid("build:Assets.xcassets")
lines.append(
    f"\t\t{assets_build} /* Assets.xcassets in Resources */ = {{isa = PBXBuildFile; fileRef = {ASSETS_REF} /* Assets.xcassets */; }};"
)
lines.append("/* End PBXBuildFile section */")
lines.append("")

lines.append("/* Begin PBXFileReference section */")
lines.append(
    f"\t\t{PRODUCT_REF} /* {APP_NAME}.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = {APP_NAME}.app; sourceTree = BUILT_PRODUCTS_DIR; }};"
)
for ref, name, path in file_refs:
    lines.append(
        f"\t\t{ref} /* {name} */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {q(name)}; sourceTree = \"<group>\"; }};"
    )
lines.append(
    f"\t\t{ASSETS_REF} /* Assets.xcassets */ = {{isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = Assets.xcassets; sourceTree = \"<group>\"; }};"
)
lines.append(
    f"\t\t{PLIST_REF} /* Info.plist */ = {{isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = Info.plist; sourceTree = \"<group>\"; }};"
)
lines.append("/* End PBXFileReference section */")
lines.append("")

lines.append("/* Begin PBXFrameworksBuildPhase section */")
frameworks_phase = uid("phase:frameworks")
lines.append(f"\t\t{frameworks_phase} /* Frameworks */ = {{")
lines.append("\t\t\tisa = PBXFrameworksBuildPhase;")
lines.append("\t\t\tbuildActionMask = 2147483647;")
lines.append("\t\t\tfiles = (")
lines.append("\t\t\t);")
lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
lines.append("\t\t};")
lines.append("/* End PBXFrameworksBuildPhase section */")
lines.append("")

lines.append("/* Begin PBXGroup section */")
lines.append(f"\t\t{GROUP_IDS['main']} = {{")
lines.append("\t\t\tisa = PBXGroup;")
lines.append("\t\t\tchildren = (")
lines.append(f"\t\t\t\t{GROUP_IDS['app']} /* {SRC_DIR} */,")
lines.append(f"\t\t\t\t{GROUP_IDS['products']} /* Products */,")
lines.append("\t\t\t);")
lines.append("\t\t\tsourceTree = \"<group>\";")
lines.append("\t\t};")

lines.append(f"\t\t{GROUP_IDS['products']} /* Products */ = {{")
lines.append("\t\t\tisa = PBXGroup;")
lines.append("\t\t\tchildren = (")
lines.append(f"\t\t\t\t{PRODUCT_REF} /* {APP_NAME}.app */,")
lines.append("\t\t\t);")
lines.append("\t\t\tname = Products;")
lines.append("\t\t\tsourceTree = \"<group>\";")
lines.append("\t\t};")


def emit_group(path: str, name: str, children: list) -> None:
    lines.append(f"\t\t{group_id(path)} /* {name} */ = {{")
    lines.append("\t\t\tisa = PBXGroup;")
    lines.append("\t\t\tchildren = (")
    for child_id, child_name in children:
        lines.append(f"\t\t\t\t{child_id} /* {child_name} */,")
    lines.append("\t\t\t);")
    lines.append(f"\t\t\tpath = {q(name)};")
    lines.append("\t\t\tsourceTree = \"<group>\";")
    lines.append("\t\t};")


# 目录树（按层级从深到浅不需要，Xcode 无所谓）
emit_group(
    "",
    SRC_DIR,
    [
        *swift_refs_by_folder.get(None, []),
        (group_id("Core"), "Core"),
        (group_id("Support"), "Support"),
        (group_id("Features"), "Features"),
        (ASSETS_REF, "Assets.xcassets"),
        (PLIST_REF, "Info.plist"),
    ],
)

for folder in ["Core", "Support", "Features", "Features/Auth", "Features/Shelf",
               "Features/Search", "Features/Detail", "Features/Reader", "Features/Settings"]:
    name = folder.split("/")[-1]
    children = list(swift_refs_by_folder.get(folder, []))
    if folder == "Features":
        children = [
            (group_id("Features/Auth"), "Auth"),
            (group_id("Features/Shelf"), "Shelf"),
            (group_id("Features/Search"), "Search"),
            (group_id("Features/Detail"), "Detail"),
            (group_id("Features/Reader"), "Reader"),
            (group_id("Features/Settings"), "Settings"),
        ]
    emit_group(folder, name, children)

lines.append("/* End PBXGroup section */")
lines.append("")

lines.append("/* Begin PBXNativeTarget section */")
lines.append(f"\t\t{TARGET_ID} /* {APP_NAME} */ = {{")
lines.append("\t\t\tisa = PBXNativeTarget;")
lines.append(f"\t\t\tbuildConfigurationList = {TARGET_CONFIG_LIST} /* Build configuration list for PBXNativeTarget \"{APP_NAME}\" */;")
lines.append("\t\t\tbuildPhases = (")
lines.append(f"\t\t\t\t{uid('phase:sources')} /* Sources */,")
lines.append(f"\t\t\t\t{frameworks_phase} /* Frameworks */,")
lines.append(f"\t\t\t\t{uid('phase:resources')} /* Resources */,")
lines.append("\t\t\t);")
lines.append("\t\t\tbuildRules = (")
lines.append("\t\t\t);")
lines.append("\t\t\tdependencies = (")
lines.append("\t\t\t);")
lines.append(f"\t\t\tname = {APP_NAME};")
lines.append(f"\t\t\tproductName = {APP_NAME};")
lines.append(f"\t\t\tproductReference = {PRODUCT_REF} /* {APP_NAME}.app */;")
lines.append("\t\t\tproductType = \"com.apple.product-type.application\";")
lines.append("\t\t};")
lines.append("/* End PBXNativeTarget section */")
lines.append("")

lines.append("/* Begin PBXProject section */")
lines.append(f"\t\t{PROJECT_ID} /* Project object */ = {{")
lines.append("\t\t\tisa = PBXProject;")
lines.append("\t\t\tattributes = {")
lines.append("\t\t\t\tBuildIndependentTargetsInParallel = 1;")
lines.append("\t\t\t\tLastSwiftUpdateCheck = 1600;")
lines.append("\t\t\t\tLastUpgradeCheck = 1600;")
lines.append("\t\t\t\tTargetAttributes = {")
lines.append(f"\t\t\t\t\t{TARGET_ID} = {{")
lines.append("\t\t\t\t\t\tCreatedOnToolsVersion = 16.0;")
lines.append("\t\t\t\t\t};")
lines.append("\t\t\t\t};")
lines.append("\t\t\t};")
lines.append(f"\t\t\tbuildConfigurationList = {PROJECT_CONFIG_LIST} /* Build configuration list for PBXProject \"{APP_NAME}\" */;")
lines.append("\t\t\tcompatibilityVersion = \"Xcode 14.0\";")
lines.append("\t\t\tdevelopmentRegion = en;")
lines.append("\t\t\thasScannedForEncodings = 0;")
lines.append("\t\t\tknownRegions = (")
lines.append("\t\t\t\ten,")
lines.append("\t\t\t\tBase,")
lines.append("\t\t\t\t\"zh-Hans\",")
lines.append("\t\t\t);")
lines.append(f"\t\t\tmainGroup = {GROUP_IDS['main']};")
lines.append("\t\t\tminimizedProjectReferenceProxies = 1;")
lines.append("\t\t\tpreferredProjectObjectVersion = 56;")
lines.append(f"\t\t\tproductRefGroup = {GROUP_IDS['products']} /* Products */;")
lines.append("\t\t\tprojectDirPath = \"\";")
lines.append("\t\t\tprojectRoot = \"\";")
lines.append("\t\t\ttargets = (")
lines.append(f"\t\t\t\t{TARGET_ID} /* {APP_NAME} */,")
lines.append("\t\t\t);")
lines.append("\t\t};")
lines.append("/* End PBXProject section */")
lines.append("")

lines.append("/* Begin PBXResourcesBuildPhase section */")
lines.append(f"\t\t{uid('phase:resources')} /* Resources */ = {{")
lines.append("\t\t\tisa = PBXResourcesBuildPhase;")
lines.append("\t\t\tbuildActionMask = 2147483647;")
lines.append("\t\t\tfiles = (")
lines.append(f"\t\t\t\t{assets_build} /* Assets.xcassets in Resources */,")
lines.append("\t\t\t);")
lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
lines.append("\t\t};")
lines.append("/* End PBXResourcesBuildPhase section */")
lines.append("")

lines.append("/* Begin PBXSourcesBuildPhase section */")
lines.append(f"\t\t{uid('phase:sources')} /* Sources */ = {{")
lines.append("\t\t\tisa = PBXSourcesBuildPhase;")
lines.append("\t\t\tbuildActionMask = 2147483647;")
lines.append("\t\t\tfiles = (")
for bid, ref, name in build_files:
    lines.append(f"\t\t\t\t{bid} /* {name} in Sources */,")
lines.append("\t\t\t);")
lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
lines.append("\t\t};")
lines.append("/* End PBXSourcesBuildPhase section */")
lines.append("")

COMMON_PROJECT_SETTINGS = {
    "ALWAYS_SEARCH_USER_PATHS": "NO",
    "CLANG_ANALYZER_NONNULL": "YES",
    "CLANG_ANALYZER_NUMBER_OBJECT_CONVERSION": "YES_AGGRESSIVE",
    "CLANG_CXX_LANGUAGE_STANDARD": "\"gnu++20\"",
    "CLANG_ENABLE_MODULES": "YES",
    "CLANG_ENABLE_OBJC_ARC": "YES",
    "CLANG_ENABLE_OBJC_WEAK": "YES",
    "CLANG_WARN_BLOCK_CAPTURE_AUTORELEASING": "YES",
    "CLANG_WARN_BOOL_CONVERSION": "YES",
    "CLANG_WARN_COMMA": "YES",
    "CLANG_WARN_CONSTANT_CONVERSION": "YES",
    "CLANG_WARN_DEPRECATED_OBJC_IMPLEMENTATIONS": "YES",
    "CLANG_WARN_DIRECT_OBJC_ISA_USAGE": "YES_ERROR",
    "CLANG_WARN_DOCUMENTATION_COMMENTS": "YES",
    "CLANG_WARN_EMPTY_BODY": "YES",
    "CLANG_WARN_ENUM_CONVERSION": "YES",
    "CLANG_WARN_INFINITE_RECURSION": "YES",
    "CLANG_WARN_INT_CONVERSION": "YES",
    "CLANG_WARN_NON_LITERAL_NULL_CONVERSION": "YES",
    "CLANG_WARN_OBJC_IMPLICIT_RETAIN_SELF": "YES",
    "CLANG_WARN_OBJC_LITERAL_CONVERSION": "YES",
    "CLANG_WARN_OBJC_ROOT_CLASS": "YES_ERROR",
    "CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER": "YES",
    "CLANG_WARN_RANGE_LOOP_ANALYSIS": "YES",
    "CLANG_WARN_STRICT_PROTOTYPES": "YES",
    "CLANG_WARN_SUSPICIOUS_MOVE": "YES",
    "CLANG_WARN_UNGUARDED_AVAILABILITY": "YES_AGGRESSIVE",
    "CLANG_WARN_UNREACHABLE_CODE": "YES",
    "CLANG_WARN__DUPLICATE_METHOD_MATCH": "YES",
    "COPY_PHASE_STRIP": "NO",
    "ENABLE_STRICT_OBJC_MSGSEND": "YES",
    "ENABLE_USER_SCRIPT_SANDBOXING": "YES",
    "GCC_C_LANGUAGE_STANDARD": "gnu17",
    "GCC_NO_COMMON_BLOCKS": "YES",
    "GCC_WARN_64_TO_32_BIT_CONVERSION": "YES",
    "GCC_WARN_ABOUT_RETURN_TYPE": "YES_ERROR",
    "GCC_WARN_UNDECLARED_SELECTOR": "YES",
    "GCC_WARN_UNINITIALIZED_AUTOS": "YES_AGGRESSIVE",
    "GCC_WARN_UNUSED_FUNCTION": "YES",
    "GCC_WARN_UNUSED_VARIABLE": "YES",
    "IPHONEOS_DEPLOYMENT_TARGET": DEPLOYMENT_TARGET,
    "LOCALIZATION_PREFERS_STRING_CATALOGS": "YES",
    "MTL_FAST_MATH": "YES",
    "SDKROOT": "iphoneos",
}

DEBUG_SETTINGS = {
    "DEBUG_INFORMATION_FORMAT": "dwarf",
    "ENABLE_TESTABILITY": "YES",
    "GCC_DYNAMIC_NO_PIC": "NO",
    "GCC_OPTIMIZATION_LEVEL": "0",
    "GCC_PREPROCESSOR_DEFINITIONS": "(\n\t\t\t\t\t\"DEBUG=1\",\n\t\t\t\t\t\"$(inherited)\",\n\t\t\t\t)",
    "MTL_ENABLE_DEBUG_INFO": "INCLUDE_SOURCE",
    "ONLY_ACTIVE_ARCH": "YES",
    "SWIFT_ACTIVE_COMPILATION_CONDITIONS": "\"DEBUG $(inherited)\"",
    "SWIFT_OPTIMIZATION_LEVEL": "\"-Onone\"",
}

RELEASE_SETTINGS = {
    "DEBUG_INFORMATION_FORMAT": "\"dwarf-with-dsym\"",
    "ENABLE_NS_ASSERTIONS": "NO",
    "MTL_ENABLE_DEBUG_INFO": "NO",
    "SWIFT_COMPILATION_MODE": "wholemodule",
    "SWIFT_OPTIMIZATION_LEVEL": "\"-O\"",
    "VALIDATE_PRODUCT": "YES",
}

TARGET_SETTINGS = {
    "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon",
    "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME": "AccentColor",
    "CODE_SIGN_STYLE": "Automatic",
    "CURRENT_PROJECT_VERSION": "16",
    "ENABLE_PREVIEWS": "YES",
    "GENERATE_INFOPLIST_FILE": "NO",
    "INFOPLIST_FILE": f"{SRC_DIR}/Info.plist",
    "INFOPLIST_KEY_LSApplicationCategoryType": "\"public.app-category.books\"",
    "INFOPLIST_KEY_UILaunchScreen_Generation": "NO",
    "IPHONEOS_DEPLOYMENT_TARGET": DEPLOYMENT_TARGET,
    "LD_RUNPATH_SEARCH_PATHS": "(\n\t\t\t\t\t\"$(inherited)\",\n\t\t\t\t\t\"@executable_path/Frameworks\",\n\t\t\t\t)",
    "MARKETING_VERSION": "1.14",
    "PRODUCT_BUNDLE_IDENTIFIER": BUNDLE_ID,
    "PRODUCT_NAME": "\"$(TARGET_NAME)\"",
    "SWIFT_EMIT_LOC_STRINGS": "YES",
    "SWIFT_VERSION": "5.0",
    "TARGETED_DEVICE_FAMILY": "\"1,2\"",
}


def emit_config(config_id: str, name: str, settings: dict) -> None:
    lines.append(f"\t\t{config_id} /* {name} */ = {{")
    lines.append("\t\t\tisa = XCBuildConfiguration;")
    lines.append("\t\t\tbuildSettings = {")
    for key in sorted(settings):
        lines.append(f"\t\t\t\t{key} = {settings[key]};")
    lines.append("\t\t\t};")
    lines.append(f"\t\t\tname = {name};")
    lines.append("\t\t};")


lines.append("/* Begin XCBuildConfiguration section */")
emit_config(uid("config:project:debug"), "Debug", {**COMMON_PROJECT_SETTINGS, **DEBUG_SETTINGS})
emit_config(uid("config:project:release"), "Release", {**COMMON_PROJECT_SETTINGS, **RELEASE_SETTINGS})
emit_config(uid("config:target:debug"), "Debug", TARGET_SETTINGS)
emit_config(uid("config:target:release"), "Release", TARGET_SETTINGS)
lines.append("/* End XCBuildConfiguration section */")
lines.append("")

lines.append("/* Begin XCConfigurationList section */")
lines.append(f"\t\t{PROJECT_CONFIG_LIST} /* Build configuration list for PBXProject \"{APP_NAME}\" */ = {{")
lines.append("\t\t\tisa = XCConfigurationList;")
lines.append("\t\t\tbuildConfigurations = (")
lines.append(f"\t\t\t\t{uid('config:project:debug')} /* Debug */,")
lines.append(f"\t\t\t\t{uid('config:project:release')} /* Release */,")
lines.append("\t\t\t);")
lines.append("\t\t\tdefaultConfigurationIsVisible = 0;")
lines.append("\t\t\tdefaultConfigurationName = Release;")
lines.append("\t\t};")
lines.append(f"\t\t{TARGET_CONFIG_LIST} /* Build configuration list for PBXNativeTarget \"{APP_NAME}\" */ = {{")
lines.append("\t\t\tisa = XCConfigurationList;")
lines.append("\t\t\tbuildConfigurations = (")
lines.append(f"\t\t\t\t{uid('config:target:debug')} /* Debug */,")
lines.append(f"\t\t\t\t{uid('config:target:release')} /* Release */,")
lines.append("\t\t\t);")
lines.append("\t\t\tdefaultConfigurationIsVisible = 0;")
lines.append("\t\t\tdefaultConfigurationName = Release;")
lines.append("\t\t};")
lines.append("/* End XCConfigurationList section */")

lines.append("\t};")
lines.append(f"\trootObject = {PROJECT_ID} /* Project object */;")
lines.append("}")

project_dir = os.path.join(ROOT, f"{APP_NAME}.xcodeproj")
os.makedirs(project_dir, exist_ok=True)
with open(os.path.join(project_dir, "project.pbxproj"), "w", encoding="utf-8", newline="\n") as handle:
    handle.write("\n".join(lines) + "\n")

scheme_dir = os.path.join(project_dir, "xcshareddata", "xcschemes")
os.makedirs(scheme_dir, exist_ok=True)
scheme = f"""<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion = "1600" version = "1.7">
   <BuildAction parallelizeBuildables = "YES" buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry buildForTesting = "YES" buildForRunning = "YES" buildForProfiling = "YES" buildForArchiving = "YES" buildForAnalyzing = "YES">
            <BuildableReference
               BuildableIdentifier = "primary"
               BlueprintIdentifier = "{TARGET_ID}"
               BuildableName = "{APP_NAME}.app"
               BlueprintName = "{APP_NAME}"
               ReferencedContainer = "container:{APP_NAME}.xcodeproj">
            </BuildableReference>
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction buildConfiguration = "Debug" selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv = "YES">
      <Testables>
      </Testables>
   </TestAction>
   <LaunchAction buildConfiguration = "Debug" selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB" launchStyle = "0" useCustomWorkingDirectory = "NO" ignoresPersistentStateOnLaunch = "NO" debugDocumentVersioning = "YES" debugServiceExtension = "internal" allowLocationSimulation = "YES">
      <BuildableProductRunnable runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{TARGET_ID}"
            BuildableName = "{APP_NAME}.app"
            BlueprintName = "{APP_NAME}"
            ReferencedContainer = "container:{APP_NAME}.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </LaunchAction>
   <ProfileAction buildConfiguration = "Release" shouldUseLaunchSchemeArgsEnv = "YES" savedToolIdentifier = "" useCustomWorkingDirectory = "NO" debugDocumentVersioning = "YES">
      <BuildableProductRunnable runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{TARGET_ID}"
            BuildableName = "{APP_NAME}.app"
            BlueprintName = "{APP_NAME}"
            ReferencedContainer = "container:{APP_NAME}.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </ProfileAction>
   <AnalyzeAction buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction buildConfiguration = "Release" revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>
"""
with open(os.path.join(scheme_dir, f"{APP_NAME}.xcscheme"), "w", encoding="utf-8", newline="\n") as handle:
    handle.write(scheme)

workspace_dir = os.path.join(project_dir, "project.xcworkspace")
os.makedirs(workspace_dir, exist_ok=True)
with open(os.path.join(workspace_dir, "contents.xcworkspacedata"), "w", encoding="utf-8", newline="\n") as handle:
    handle.write(
        '<?xml version="1.0" encoding="UTF-8"?>\n<Workspace\n   version = "1.0">\n'
        '   <FileRef\n      location = "self:">\n   </FileRef>\n</Workspace>\n'
    )

# 一致性校验：所有被引用的 24 位 ID 都必须在 objects 中定义
text = "\n".join(lines)
defined = set(re.findall(r"^\t\t([0-9A-F]{24})\s", text, re.MULTILINE))
referenced = set(re.findall(r"[ =({,]\s*([0-9A-F]{24})\s", text)) | set(
    re.findall(r"^\t\t\t\t([0-9A-F]{24})", text, re.MULTILINE)
)
missing = sorted(referenced - defined)
brace_balance = text.count("{") - text.count("}")
print(f"objects defined: {len(defined)}")
print(f"missing definitions: {missing}")
print(f"brace balance: {brace_balance}")
print(f"swift files: {len(SWIFT_FILES)}")

# 同步 Info.plist 里的版本号为硬编码值，避免 xcodebuild 的 $(MARKETING_VERSION) 替换失效
info_plist_path = os.path.join(ROOT, SRC_DIR, "Info.plist")
with open(info_plist_path, "r", encoding="utf-8") as handle:
    plist_text = handle.read()
plist_text = re.sub(
    r"(<key>CFBundleShortVersionString</key>\s*<string>)[^<]*(</string>)",
    lambda m: m.group(1) + TARGET_SETTINGS["MARKETING_VERSION"] + m.group(2),
    plist_text,
)
plist_text = re.sub(
    r"(<key>CFBundleVersion</key>\s*<string>)[^<]*(</string>)",
    lambda m: m.group(1) + TARGET_SETTINGS["CURRENT_PROJECT_VERSION"] + m.group(2),
    plist_text,
)
with open(info_plist_path, "w", encoding="utf-8", newline="\n") as handle:
    handle.write(plist_text)
print(f"Info.plist version: {TARGET_SETTINGS['MARKETING_VERSION']} / {TARGET_SETTINGS['CURRENT_PROJECT_VERSION']}")
