import os, zipfile, shutil, hashlib, plistlib

ZIP = r"C:\Users\Administrator\Downloads\LegadoReader-unsigned-ipa (1).zip"
OUTDIR = r"C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\build-out\v2"
SHARE = r"C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\留白阅读-修复版-待签名.ipa"

os.makedirs(OUTDIR, exist_ok=True)
zpath = os.path.join(OUTDIR, "artifact.zip")
shutil.copyfile(ZIP, zpath)

with zipfile.ZipFile(zpath) as z:
    names = z.namelist()
    z.extractall(OUTDIR)

ipa = os.path.join(OUTDIR, "LegadoReader-unsigned.ipa")
if not os.path.exists(ipa):
    ipa = None
    for n in names:
        p = os.path.join(OUTDIR, n)
        if p.lower().endswith(".ipa"):
            ipa = p
            break

report = []
report.append("artifact_entries=%d" % len(names))
report.append("artifact_zip_size=%d" % os.path.getsize(zpath))
report.append("ipa_path=%s" % ipa)

if ipa:
    report.append("ipa_size=%d" % os.path.getsize(ipa))
    with zipfile.ZipFile(ipa) as z2:
        inames = z2.namelist()
        report.append("ipa_entries=%d" % len(inames))
        report.append("has_payload=%s" % any(n.startswith("Payload/LegadoReader.app/") for n in inames))
        report.append("has_exe=%s" % ("Payload/LegadoReader.app/LegadoReader" in inames))
        info = z2.read("Payload/LegadoReader.app/Info.plist")
        pl = plistlib.loads(info)
        report.append("bundle_id=%s" % pl.get("CFBundleIdentifier"))
        report.append("version=%s" % pl.get("CFBundleShortVersionString"))
        report.append("bundle_version=%s" % pl.get("CFBundleVersion"))
        report.append("min_os=%s" % pl.get("MinimumOSVersion"))
        exe = z2.read("Payload/LegadoReader.app/LegadoReader")
        report.append("exe_bytes=%d magic=%s" % (len(exe), exe[:4].hex()))
    shutil.copyfile(ipa, SHARE)
    report.append("share_copy=%s" % SHARE)
    report.append("sha256=%s" % hashlib.sha256(open(ipa, "rb").read()).hexdigest().upper())

with open(r"C:\Users\Administrator\AppData\Local\Temp\ipa2check.txt", "w", encoding="utf-8") as fh:
    fh.write("\n".join(report))
