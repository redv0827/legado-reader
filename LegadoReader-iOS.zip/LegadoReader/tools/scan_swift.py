import glob, io, os

root = r"C:\Users\Administrator\Doubao\chats\2026-11-25\new-chat\LegadoReader\LegadoReader"


def scan(path):
    text = io.open(path, encoding="utf-8").read()
    n = len(text)
    i = 0
    stack = []          # (char, line)
    # 状态：code / line / block / str / multi / interp
    state = "code"
    block_depth = 0
    interp_base = 0
    line = 1
    while i < n:
        c = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if c == "\n":
            line += 1
        if state == "code":
            if c == "/" and nxt == "/":
                state = "line"; i += 2; continue
            if c == "/" and nxt == "*":
                state = "block"; block_depth = 1; i += 2; continue
            if text.startswith('"""', i):
                state = "multi"; i += 3; continue
            if c == '"':
                state = "str"; i += 1; continue
            if c in "([{":
                stack.append((c, line)); i += 1; continue
            if c in ")]}":
                if not stack:
                    return "多出的 %s 在第 %d 行" % (c, line)
                (op, ln) = stack.pop()
                if "([{".index(op) != ")]}".index(c):
                    return "第 %d 行的 %s 与第 %d 行的 %s 不配对" % (line, c, ln, op)
                i += 1; continue
            i += 1; continue
        if state == "line":
            if c == "\n":
                state = "code"
            i += 1; continue
        if state == "block":
            if c == "/" and nxt == "*":
                block_depth += 1; i += 2; continue
            if c == "*" and nxt == "/":
                block_depth -= 1; i += 2
                if block_depth == 0:
                    state = "code"
                continue
            i += 1; continue
        if state in ("str", "multi"):
            if c == "\\":
                if nxt == "(":
                    state = "interp"; interp_base = len(stack); i += 2; continue
                i += 2; continue
            if state == "str" and c == '"':
                state = "code"; i += 1; continue
            if state == "multi" and text.startswith('"""', i):
                state = "code"; i += 3; continue
            i += 1; continue
        if state == "interp":
            if c == "/" and nxt == "/":
                state = "line"; i += 2; continue
            if text.startswith('"""', i):
                state = "multi"; i += 3; continue
            if c == '"':
                state = "str"; i += 1; continue
            if c in "([{":
                stack.append((c, line)); i += 1; continue
            if c in ")]}":
                if c == ")" and len(stack) == interp_base:
                    state = "str"
                    i += 1
                    continue
                if not stack:
                    return "插值里多出的 %s 在第 %d 行" % (c, line)
                (op, ln) = stack.pop()
                if "([{".index(op) != ")]}".index(c):
                    return "第 %d 行的 %s 与第 %d 行的 %s 不配对" % (line, c, ln, op)
                i += 1; continue
            i += 1; continue
    if stack:
        return "结尾未闭合 %s（第 %d 行）" % (stack[-1][0], stack[-1][1])
    if state in ("str", "multi", "block", "interp"):
        return "结尾状态异常：%s" % state
    return "OK"


lines = []
for path in sorted(glob.glob(os.path.join(root, "**", "*.swift"), recursive=True)):
    name = os.path.relpath(path, root).replace("\\", "/")
    lines.append("%-48s %s" % (name, scan(path)))

io.open(r"C:\Users\Administrator\AppData\Local\Temp\swiftscan.txt", "w", encoding="utf-8").write("\n".join(lines))
