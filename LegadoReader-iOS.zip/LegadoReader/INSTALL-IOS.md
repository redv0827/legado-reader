# 把「留白阅读」装到 iPhone

iPhone 只能安装**经过签名**的 iOS App。Swift 源码不能直接丢进手机，必须先编译成 app / ipa，再用你的 Apple ID 签名。下面几条路，差别只在「用哪台机器编译、用谁签名」。

三条路都需要一个 Apple ID：免费账号就能用，但有效期 7 天；付费开发者账号 99 美元/年，有效期 1 年。

## 0. 无论走哪条路，iPhone 上都要做的两件事

① 打开开发者模式（iOS 16 及以上必须）

设置 → 隐私与安全性 → 开发者模式 → 打开 → 按提示重启 → 重启后再次确认打开。

② 信任签名证书

装完第一次点开若提示「未受信任的开发者」：设置 → 通用 → VPN 与设备管理 → 「开发者 App」下找到你的 Apple ID → 信任。

## 路线 A：身边有 Mac（最省事，约 10 分钟）

要求：任意一台 Mac，装 Xcode（App Store 免费，约 12GB）。

1. 把整个 LegadoReader 文件夹拷到 Mac，双击 LegadoReader.xcodeproj。
2. 左上角蓝色工程图标 → TARGETS 里的 LegadoReader → Signing & Capabilities：
   - 勾选 Automatically manage signing；
   - Team 选你的 Apple ID（没有就先 Xcode → Settings → Accounts 添加）；
   - 提示 Bundle ID 被占用时，把 com.liubai.reader 改成 com.你的名字.legado。
3. iPhone 数据线连 Mac，手机上点「信任此电脑」。
4. Xcode 顶部设备栏选你的 iPhone，按 Command + R。
5. 手机出现「留白阅读」后，按第 0 步信任证书打开。

免费账号限制：安装后 7 天失效，到期回 Xcode 再按一次 Command + R 即可，数据不丢。

## 路线 B：只有 Windows 也能装（GitHub Actions 编译 + Sideloadly 签名）

思路：GitHub 的免费 macOS 机器编译出**未签名 ipa**，再在 Windows 用 Sideloadly 拿你的 Apple ID 签名装进 iPhone。全程不碰 Mac，免费。

工程里已带好工作流文件 .github/workflows/build-ios-ipa.yml，不用你写代码。

### B1. 把工程传到 GitHub

1. 登录 github.com。
2. 右上角 + → New repository，名字随意（如 legado-reader），选 Private（私有仓库也能免费跑 Actions），Create。
3. 上传工程。**推荐 GitHub Desktop**，网页上传会漏掉 .github 这种隐藏文件夹：
   - 装 GitHub Desktop → File → Add local repository → 选 LegadoReader 文件夹 → 提示创建仓库点 create；
   - 左下填提交信息 → Commit to main → 右上 Publish repository。

### B2. 让 GitHub 编出 ipa

1. 仓库页面 → Actions 标签（首次提示启用，点启用）。
2. 左侧选 Build unsigned IPA → 右侧 Run workflow → 分支 main → 绿色 Run workflow。
3. 等 3 到 8 分钟，状态变绿。
4. 点进这次运行，页面底部 Artifacts 下载 LegadoReader-unsigned-ipa（zip），解压得到 LegadoReader-unsigned.ipa。

这一步同时就是真正的编译验证。如果日志里出现红色报错，把报错内容发我，我照着改工程。

### B3. 在 Windows 用 Sideloadly 装进 iPhone

1. 装两样东西：
   - iTunes（Apple 官网 64 位版，或 Microsoft Store 的「Apple 设备」App），提供 iPhone 驱动；
   - Sideloadly 的 Windows 版（sideloadly.io）。
2. iPhone 数据线连电脑，解锁，点「信任此电脑」。
3. 打开 Sideloadly：
   - IPA：拖入刚解压的 LegadoReader-unsigned.ipa；
   - Apple ID：填你的 Apple ID 邮箱；
   - Password：填 **App 专用密码**，不是账号密码。获取：打开 appleid.apple.com → 登录 → 登录与安全 → App 专用密码 → 生成，得到 xxxx-xxxx-xxxx-xxxx 一串。
   - 勾选自动识别设备，选中 iPhone，点 Start。
4. 手机可能弹「是否允许」，点允许。完成后按第 0 步信任证书即可打开。
5. 想换 Bundle ID，Sideloadly 的 Bundle ID 一栏填 com.你的名字.legado。

7 天到期：打开 Sideloadly，把同一个 ipa 再拖进去点 Start 即可重签，不用重新下载。

也可以用 AltStore（Windows 上跑 AltServer）实现自动续签，原理相同，配置更麻烦，先跑通 Sideloadly。

## 路线 C：租一台云 Mac

不想装 GitHub、也借不到电脑，可以按小时租 macOS：MacinCloud、MacStadium、AWS EC2 Mac、Scaleway Apple Silicon。远程桌面进去后流程和路线 A 完全一样。

## 路线 D：想长期用、还要给家人装

加入 Apple Developer Program（99 美元/年，国内约 688 元）：签名 1 年有效，可走 TestFlight 分发，家人点链接就能装，90 天一个版本。

## 装好之后第一次打开要填什么

1. 服务器地址：http://你服务器的局域网IP:3001，例如 http://192.168.1.20:3001。先在 iPhone Safari 打开同一地址，能看到留白登录页，说明网络通。
2. 账号密码：服务端首次启动生成的 data/bootstrap-admin.txt 里的账号，密码 12 位以上。
3. 登录后去网页端导入书源 JSON，App 里就能搜到书。

## 卡点排查

- App 里提示「访问被拒绝」（403）：服务端 .env 的 LEGADO_PUBLIC_ORIGIN 没写手机访问用的地址，改成 http://192.168.1.20:3001 后重启服务端。
- 提示「无法连接服务器」：iPhone 和服务器不在同一 Wi-Fi；服务器防火墙没放行 3001；地址写错（末尾不要加斜杠）。
- 装完点开闪退或提示未受信任：没做第 0 步的信任证书或开发者模式。
- Sideloadly 卡在 Installing：换 USB 口或原装线；iPhone 重启后重试；确认 iTunes（Apple 设备）已装。
- 7 天后图标变灰打不开：免费账号到期，用 Sideloadly 重签一次。
- Xcode 报 Bundle ID 冲突：Signing 里把 com.liubai.reader 改成 com.你的名字.legado。
- GitHub Actions 编译失败：把 Actions 日志里的红色报错发我，我改源码。
